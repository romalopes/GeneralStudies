import ClassesGeral.ObjetoEnviado;
import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;
	
//Para liberar o Servidor para receber novas mensagens,
public class Serv_Delegado extends Thread
{
	Processador m_Processador;
//	String m_Nome,m_Mensagem;
	Mensagem m_mensagem;
	public Serv_Delegado(Processador p)
	{
		m_Processador = p;
	}

	//recebe a mensagem do Cliente que passou pelo Servidor, e no futuro vai para o Processador.
	public synchronized void processa(Mensagem Msg)
	{
//		m_Mensagem = Mensagem;
//		m_Nome = Nome;
		m_mensagem = Msg;
	}

	//executa... Apenas chama o ProcessaMensagem do Processador.
	public synchronized void run()
	{
		
		ObjetoEnviado obj;
//		try{
//			sleep(2000);
//		}catch (InterruptedException ex) {return;}

			System.out.println("\nComecou a rodar Serv_Delegado ");			
		try{
			boolean reply = m_mensagem.reply();
			obj = m_Processador.ProcessaMensagem(m_mensagem);

			if (reply == true)
			{
				if(m_mensagem.tipo().equalsIgnoreCase("Agente"))
					Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,obj);
				else	
					if(m_mensagem.tipo().equalsIgnoreCase("Site"))
						Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoClienteProcessador,obj);
					else
						if(m_mensagem.tipo().equalsIgnoreCase("Ambos"))
						{
							Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoClienteProcessador,obj);
							Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,obj);					
						}
			}
		}				
		catch (Exception e) 
		{
			System.err.println("Erro no Serv_Delegado Exception:" + e);
		}

		System.out.println("Terminou de rodar Serv_Delegado");

 	}   
}
/*
c
c1
p
l
pr
i
o1
o
o2
*/
