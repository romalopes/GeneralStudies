import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;

import ClassesGeral.Enviador;

final public class Leil_Ingles extends Leiloeiro
{

	private int m_iNumOfertas;
	
	
	/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	{
		try
		{	
			out.writeInt(m_iNumOfertas);
			out.flush();
		}	
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do Leil_Ingles" );
		}			
	}
	
/****************************** readObject **********************************/		
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_iNumOfertas = in.readInt();
		}
		catch(IOException e)
		{
			System.err.println(e+" Erro no read do Leil_Ingles" );
		}
	 }

	public Leil_Ingles(Produto p)
	{
		super(p);
		m_tipo = "Ingles";
	}

	public boolean AnalisaRestricoes(Participante pPartic,double Valor)
	{
		if( (Valor - m_iValorAtual) < menorDiferencaOferta() && participanteAtual()!=null)
		{
			System.out.println("Valor entre ofertas muito pequeno. ValorOferta:"+ Valor+" ValorAtual:"+m_iValorAtual+" MenorDiferenca:"+menorDiferencaOferta());
			return false;
		}
		System.out.println(Valor+" "+m_iValorAtual+" "+menorDiferencaOferta());

		return true;
	}

	public String printCaracteristicas()
	{
		StringBuffer buffer = new StringBuffer();
		try
		{
			buffer.append(produto().nome());
			buffer.append(tipo());
//			buffer.append(String.valueOf(menorDiferencaOferta()));
		
		}
		catch (Exception e)
		{
			System.err.println("erro no print caracteristicas do Leil_Ingles "+ e);
		}
		return buffer.toString();
	}
/********************* recebeOferta ****************************************/
//chamado pelo processador la de fora
	public synchronized String recebeOferta(Participante pPartic,double iValor)
	{
		try
		{
			System.out.println("Recebendo oferta de:"+pPartic.nome()+" valor:"+iValor);		
			m_bMensagem = true;
			
			if(pPartic == null)
				System.out.println("Erro");
			
			m_ParticipanteAtual = pPartic;
			m_iValorAtual = iValor;

			if(findParticipante(pPartic.nome())== null)
				listOfertantes.addElement(pPartic);
			String bValorReserva = vetorCaracteristica.getValorCarac("bValorReserva");
			
			double valorReserva = vetorCaracteristica.getValorCaracDouble("ValorReserva");
			
			m_iNumOfertas++;
			
			valorReserva = valorReserva+valorReserva;
			if (bValorReserva.equals("true") && m_iValorAtual >= valorReserva)
			{
				System.out.println("fecha porque o valor j� satisfez com o valor:"+String.valueOf(m_iValorAtual)+" Valor Reserva+1/2:"+String.valueOf(valorReserva));
				fechaLeilao();
			}
			notifyAll();
		}
		catch(Exception e)
		{
			System.err.println("Erro no Recebe Oferta do Leilao Ingles"+ e);		
		}
		return pPartic.nome();
	}
	

/********************* processaOferta ****************************************/
// N�o est� sendo chamado
	public synchronized void processaOferta()
	{
		System.out.println("Processa oferta");

		//por enquato so pega esse valor e joga como o maior valor.

		m_ParticipanteVencedor = m_ParticipanteAtual;
		m_iValorVencedor = m_iValorAtual;
		
		
//		System.out.println("Oferta atual e = "+String.valueOf(m_iValorAtual) + " Vinda de " + m_ParticipanteAtual.nome());

	}
	
	public boolean decrementaPrazo()
	{
	
		Integer valor = new Integer(Integer.parseInt(vetorCaracteristica.getValorCarac("prazo"),10));
		int prazo = (int)valor.intValue();

		prazo--;

		vetorCaracteristica.setValorCarac("prazo",String.valueOf(prazo));		
		if (prazo <= 0 )
		{
			fechaLeilao();
			return false;
		}
		return true;
	}
	
	public synchronized void recebeAvisoRelogio()
	{
		try
		{
			String nomeAtual = null;
			if(m_ParticipanteAtual != null)
				nomeAtual = m_ParticipanteAtual.nome();
			
			if(m_bRodando)
			{
				System.out.println(produto().codigo()+" "+produto().nome() + " Inicio:"+Enviador.getStringData(data())+" Ingles. Faltam " + prazo() + " min. ValorInicial: "+valorInicial()+" Valor Vencedor:" + String.valueOf(m_iValorAtual)+" Vencedor:"+nomeAtual);				
				if(!decrementaPrazo())
					m_bRodando=false;
			}
			else
				System.out.println(produto().codigo()+" "+produto().nome() + " Ingles. Fechado. V.Inic:"+valorInicial()+" V.Venc:" + String.valueOf(m_iValorAtual)+" Venc:"+nomeAtual+" Inicio:"+Enviador.getStringData(data()));				
			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no recebe AvisoRelogio");
		}
		
		
	}

	
	
}

