import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;


import ClassesGeral.ObjetoEnviado;

public class Produto extends ObjetoEnviado implements Serializable
{
	String m_nome,m_detalhes;
	Participante m_Dono;
	Leiloeiro m_leiloeiro;
	String m_codigo;
	boolean m_bconfirmacaoCompra,m_bconfirmacaoVenda;
	
	/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
			out.writeObject(m_nome);
			out.writeObject(m_detalhes);
			out.writeObject(m_Dono);
			out.writeObject(m_leiloeiro);
			out.writeObject(m_codigo);			
			out.writeBoolean(m_bconfirmacaoCompra);
			out.writeBoolean(m_bconfirmacaoVenda);
			
			out.flush();
		}	
		catch(IOException e)
		{
			System.out.println(e+ " Erro no write do Produto" );
		}			
	}
	
/****************************** readObject **********************************/		
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_nome = (String)in.readObject();
			m_detalhes = (String)in.readObject();
			m_Dono = (Participante)in.readObject();
			m_leiloeiro = (Leiloeiro)in.readObject();			
			m_codigo = (String)in.readObject();
						
			m_bconfirmacaoCompra = in.readBoolean();
			m_bconfirmacaoVenda = in.readBoolean();
		 }
		 catch(IOException e)
		 {
		 	System.out.println(e+" Erro no read do Produto" );
		 }
	 }
	
	public void fazVendido()
	{
	
		if(m_leiloeiro != null)
			m_leiloeiro.setRodando(false);
	}
	
	
	public Produto (String nome) 
	{ 
		m_nome  = nome; 
		m_detalhes = " ";
		m_codigo = "0";
		m_bconfirmacaoCompra = false;
		m_bconfirmacaoVenda = false;
	}

	protected void Finalize()
	{
		
	}

	public boolean confirmacaoCompra()
	{
		return m_bconfirmacaoCompra;
	}
	public void setConfirmacaoCompra(boolean c)
	{
		m_bconfirmacaoCompra = c;
	}
	
	public boolean confirmacaoVenda()
	{
		return m_bconfirmacaoVenda;
	}
	public void setConfirmacaoVenda(boolean v)
	{
		m_bconfirmacaoVenda = v;
	}

	public void setCodigo(String id)
	{
		m_codigo = id;
	}
	public String codigo()
	{
		return m_codigo;
	}

	public String nome() {
		return m_nome;
	}
	
	public void setDetalhes(String dt)
	{
		m_detalhes = dt;
	}
	public String detalhes()
	{
		return m_detalhes;
	}	
	
	public void setDono(Participante Partic) {
		m_Dono = Partic;
	}

	public Participante dono() {
		return m_Dono;
	}
	public void setLeiloeiro(Leiloeiro l) {
		m_leiloeiro = l;
	}

	public Leiloeiro leiloeiro() {
		return m_leiloeiro;
	}
	public String temLeiloeiro() 
	{
		if(m_leiloeiro != null)
			return "Sim";
		else
			return "N�o";	
	}
	public String temLeiloeiroRodando() 
	{
		if (m_leiloeiro != null)
		{
			if(leiloeiro().rodando())
				return "Sim";
		}
		return "N�o";	
	}

	public synchronized void recebeAvisoRelogio()
	{
		try
		{
			//Escrever a Data.
			if(m_leiloeiro != null)
				m_leiloeiro.recebeAvisoRelogio();
			else	
				System.err.println( "Problemas no recebe AvisoRelogio Leiroeiro=Null"+nome());
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no recebe AvisoRelogio");
		}
		
		
	}


/******************** appendBufferProduto ******************************/
	public String appendBufferProduto()
	{
		StringBuffer stringBuffer = new StringBuffer(500);
		try
		{
			Leiloeiro l;
			l = this.leiloeiro();
		
			stringBuffer.append("nomeDono&"+this.dono().nome()+"&");//0					
			stringBuffer.append("nomeProduto&"+this.nome() +"&");//2					
			stringBuffer.append("codigo&"+this.codigo() +"&");//1
			stringBuffer.append("detalhes&"+this.detalhes() +"&");//3
			stringBuffer.append("nomePagina&AKRM&");//3													
			if (l.tipo().equalsIgnoreCase("Ingles"))
			{
				stringBuffer.append("tipoLeilao&Ingles&");//3										
				Leil_Ingles lp = (Leil_Ingles)l;					
				stringBuffer.append("bValorReserva&"+l.vetorCaracteristica.getValorCarac("bValorReserva")+"&");//5					
				stringBuffer.append("ValorReserva&"+l.vetorCaracteristica.getValorCarac("ValorReserva") +"&");//6
			}
			else						
			{
				stringBuffer.append("tipoLeilao&Holandes&");//3															
				Leil_Holandes lh = (Leil_Holandes)l;					
				stringBuffer.append("bValorreserva&false&");//4
				stringBuffer.append("Valorreserva&0&");//5
			}
			stringBuffer.append("menordiferenca&"+l.vetorCaracteristica.getValorCarac("menorDiferenca")+"&");//5					
			stringBuffer.append("valorInicial&"+l.vetorCaracteristica.getValorCarac("ValorInicial") +"&");//6
			stringBuffer.append("valorAtual&"+l.valorAtual() +"&");//7
			stringBuffer.append("valorvencedor&"+l.valorVencedor() +"&");//8
			stringBuffer.append("dataInicio&"+l.vetorCaracteristica.getValorCarac("dataInicio") +"&");
			stringBuffer.append("prazo&"+l.vetorCaracteristica.getValorCarac("prazo") +"&");//9
			stringBuffer.append("participanteAtual&"+l.printParticipanteAtual() +"&");
			stringBuffer.append("pagina&AKRM&");			
			stringBuffer.append("numeroEstrelasVendedor&"+this.dono().numeroEstrelas()+"&");
			if (l.participanteAtual()!=null)
				stringBuffer.append("numeroEstrelasVencedor&"+String.valueOf(l.participanteAtual().numeroEstrelas())+"&");
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em apendBufferProduto");
		}
	
		return stringBuffer.toString();
	}



	
	public void Init(){}
}