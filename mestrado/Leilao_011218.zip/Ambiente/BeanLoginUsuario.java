//import java.io.*;
//import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

public class BeanLoginUsuario	
{
	private String nomeUsuario;
	private String passWord;

	public void setNomeUsuario(String u)
	{
		nomeUsuario = u;
	}
	
	public String getNomeUsuario()
	{
		return nomeUsuario;
	}
	public void setPassWord(String p)
	{
		passWord = p;
	}
	
	public String getPassWord()
	{
		return passWord;
	}
	
	public boolean processa()
	{
		System.out.println("Procesando BeanLoginUsuario");
		Mensagem Msg = new Mensagem("FALHA","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(nomeUsuario,Inet.toString());
			//AINDA n�o estou passando o password.
			Msg.setMensagem("LOGIN");
			Msg.setMensagemAux(passWord);
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);
			Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
		
			System.out.println("receve msg em BeanLoginUsuario "	+Msg.mensagemRetorno());
			return Msg.mensagemRetorno();			
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanNovoUsuario Exception:  " + e);
		}
		return true;		
		
	}
}
