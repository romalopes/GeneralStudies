/*import ClassesGeral.ObjetoEnviado;
import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;


//Para liberar o Servidor para receber novas mensagens,
public class ServidorDelegado extends Thread
{
	Processador m_Processador;
	Mensagem m_mensagem;
	public ServidorDelegado(Processador p)
	{
		m_Processador = p;
	}

	//recebe a mensagem do Cliente que passou pelo Servidor, e no futuro vai para o Processador.
	public synchronized void processa(Mensagem mensagem)
	{
		m_mensagem = mensagem;
	}

	//executa... Apenas chama o ProcessaMensagem do Processador.
	public synchronized void run()
	{

		ObjetoEnviado obj;
	//		try{
	//			sleep(2000);
	//		}catch (InterruptedException ex) {return;}

			System.out.println("\nComecou a rodar Serv_Delegado");			
		try{
			obj = m_Processador.ProcessaMensagem(m_mensagem);
		}catch (Exception e) {return;}

		System.out.println("Terminou de rodar Serv_Delegado");

		try
		{
			Enviador.EnviaMensagem(Processador.nomeHost,Processador.PortaRecebimentoCliente,obj);
		}				
		catch (Exception e) 
		{
			System.err.println("Erro no Serv_Delegado Exception:" + e);
		}

	}
}
/*
c
c1
p
l
pr
i
o1
o
o2
*/
