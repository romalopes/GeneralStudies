

import java.io.*;    //Package de classes para manipulacao de E/S
import java.net.*;   //Package de classes para manipulacao de Sockets, IP, etc.
//import java.util.*;

import ClassesGeral.Enviador;
import ClassesGeral.Mensagem;
import ClassesGeral.Recebedor;


public class Servidor 
{
    public Servidor(){}

    public static void main(String[] args) throws IOException {

		Processador m_Proc = new Processador();
		m_Proc.startRelogio();
		
		try
		{
			while (true)
			{
		
				//ainda assumindo que a Msg est� com valores.
				Mensagem Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoServidorProcessador);
		        System.out.println("Recebi "+Msg.nome()+ " mensagem "+Msg.mensagem()+ "IP "+Msg.ip()); 		
			    //cria uma thread para liberar o Servidor para novas mensagens...
			    Serv_Delegado sd;
			    sd = new Serv_Delegado(m_Proc);
			    sd.processa(Msg);	
			    sd.start();
			}//while true  
								  
	     } catch (Exception e) 
		 {System.out.println("Erro"); }
      }//main
}//class


    