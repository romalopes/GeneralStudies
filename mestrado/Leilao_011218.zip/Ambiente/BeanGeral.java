import java.io.*;
import java.util.*;
import java.net.*;

public class BeanGeral 
{
	private String nomeUsuario;
	private String nomeAgente;
	private String ip;

	public void setNomeUsuario(String u)
	{
		nomeUsuario = u;
	}
	
	public String getNomeUsuario()
	{
		return nomeUsuario;
	}
	public void setNomeAgente(String n)
	{
		nomeAgente = n;
	}
	
	public String getNomeAgente()
	{
		return nomeAgente;
	}
	
	public void setIP(String l)
	{
		ip = l;
	}
	
	public String getIP()
	{
		return ip;
	}


}
