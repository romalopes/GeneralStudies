//import java.io.*;
//import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

public class BeanTrataProdutos
{
	private String nomeUsuario;
	private String nomeProduto;
	private String funcao;	
	private String caracteristicas;
	

	public void setNomeUsuario(String u)
	{
		nomeUsuario = u;
	}
	
	public String getNomeUsuario()
	{
		return nomeUsuario;
	}

	public void setnomeProduto(String p)
	{
		nomeProduto = p;
		}
	public String getnomeProduto()
	{
		return nomeProduto;
	}
	
	public void setFuncao(String f)
	{
		funcao = f;
	}
	public String getFuncao()
	{
		return funcao;
	}
	
	public void cleanCaracteristicas()
	{
		caracteristicas = "";
	}
	public void appendCaracteristica(String c)
	{
		if(caracteristicas.length() <= 0)
			caracteristicas = c;
		else
			caracteristicas += ","+c;	
	}
		
	
	public boolean processa()
	{
		System.out.println("Procesando BeanTrataProdutos");
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(nomeUsuario,Inet.toString());
			//AINDA n�o estou passando o password.
			Msg.setMensagem(funcao);
			Msg.setMensagemAux(nomeProduto);
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);
			Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
					
			String valor = Msg.mensagemAux();
			System.out.println("\nRetornou "+funcao+" *********" + valor);
			if ((valor != null) && (valor.equals("OK")))
				return true;
			else
				return false;
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanNovoUsuario Exception:  " + e);
		}
		return true;		
		
	}
	
	public boolean processaComRetorno()
	{
		System.out.println("Procesando BeanTrataProdutos");
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(nomeUsuario,Inet.toString());
			//AINDA n�o estou passando o password.
			Msg.setMensagem(funcao);
			Msg.setMensagemAux(nomeProduto);
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);
			Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
					
			String valor = Msg.mensagemAux();
			System.out.println("\nRetornou "+funcao+" *********" + valor);
			if (Msg.mensagemRetorno())
				return true;
			else
				return false;
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanNovoUsuario Exception:  " + e);
		}
		return true;		
		
	}
	
	public boolean processaCriaProdLeilao()
	{
		System.out.println("Procesando BeanTrataProdutos processaCriaProdLeilao");
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(nomeUsuario,Inet.toString());
			//AINDA n�o estou passando o password.
			Msg.setMensagem(funcao);
			Msg.setMensagemAux(caracteristicas);
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);
			Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
					
			String valor = Msg.mensagemAux();
			System.out.println("\nRetornou "+funcao+" *********" + valor);
			if ((valor != null) && (valor.equals("OK")))
				return true;
			else
				return false;
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanNovoUsuario Exception:  " + e);
		}
		return true;		
		
	}

	public boolean processaOferta()
	{
		System.out.println("Procesando BeanTrataProdutos processaCriaProdLeilao");
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(nomeUsuario,Inet.toString());
			System.out.println(" ********* " + nomeUsuario);
			//AINDA n�o estou passando o password.
			Msg.setMensagem(funcao);
			Msg.setReply(true);
			Msg.setMensagemAux(caracteristicas);
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);
			Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
					
			String valor = Msg.mensagemAux();
			System.out.println("\nRetornou "+funcao+" *********" + valor);
			if (Msg.mensagemRetorno())
				return true;
			else
				return false;
		}
		catch (UnknownHostException e) 
		{
			System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println(e+ " Erro no processaOferta()");
		}
		return true;		
	}


	public boolean processaFecha()
	{
		System.out.println("Procesando BeanTrataProdutos processaCriaProdLeilao");
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(nomeUsuario,Inet.toString());
			System.out.println(" ********* " + nomeUsuario);
			//AINDA n�o estou passando o password.
			Msg.setMensagem(funcao);
//			Msg.setReply(true);
			Msg.setMensagemAux(caracteristicas);
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);
			Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
					
			String valor = Msg.mensagemAux();
			System.out.println("\nRetornou "+funcao+" *********" + valor);
			if (Msg.mensagemRetorno())
				return true;
			else
				return false;
		}
		catch (UnknownHostException e) 
		{
			System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println(e+ " Erro no processaOferta()");
		}
		return true;		
	}
	
}
