import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;

public class Relogio extends Thread implements Serializable
{
	Processador m_proc;
	boolean m_bRodando;

	/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
			out.writeObject(m_proc);
			out.writeBoolean(m_bRodando);
			
			out.flush();
		}	
		catch(IOException e)
		{
			System.out.println(e+ " Erro no write do Relogio" );
		}			
	}
	
/****************************** readObject **********************************/		
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_proc = (Processador)in.readObject();
			m_bRodando = in.readBoolean();
						
		 }
		 catch(IOException e)
		 {
		 	System.out.println(e+" Erro no read do Relogio" );
		 }
	 }
	
	

	public Relogio(Processador p)
	{
		m_proc = p;
	}

	public Processador processador()
	{
		return m_proc;
	}
	public boolean isRodando()
	{
		return m_bRodando;
	}

	public void SetRodando(boolean r)
	{
		m_bRodando = r;
	}


	public synchronized void termina()
	{
		m_bRodando = false;
		notifyAll();
	}

	public synchronized void run()
	{
		long i;

		m_bRodando = true;
//o relogio vai ficar no for enquanto o leiloeiro estiver na atividade.
		while(true )
		{

			try{
				wait(60000);//espera meio minuto
			}catch (InterruptedException e) {return;}
			
			if(!m_bRodando)
			{	
				System.out.println("\nMandaram o relogio parar de rodar ");
			}
			else//aviso de que se passaram 60 segundos.
			{
				m_proc.recebeAvisoRelogio();
			}
		}
	}


	public void Init(){}
}

