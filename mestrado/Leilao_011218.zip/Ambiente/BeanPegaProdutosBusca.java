//import java.io.*;
//import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

public class BeanPegaProdutosBusca
{
	private String m_resultadoBusca;
	private String nomeUsuario;
	private String nomeProduto;

	public void setNomeUsuario(String u)
	{
		nomeUsuario = u;
	}
	
	public String getNomeUsuario()
	{
		return nomeUsuario;
	}

	public void setNomeProduto(String p)
	{
		nomeProduto = p;
	}
	
	public String getNomeProduto()
	{
		return nomeProduto;
	}
	


//a mensagem recebida possui uma String onde o '&' indica modificacao de um produto e o '#' indica a modificacao de uma parte do produto
	public String imprimeProdutosBusca()
	{
		String descricaoProduto;
		StringBuffer stringBuffer = new StringBuffer();
		int i,j;
		
		try
		{
			stringBuffer.append("<div id=\"Layer1\" style=\"position:absolute; width:200px; height:115px; z-index:1; left: 165px; top: 148px\">"); 
			stringBuffer.append("<table width=\"63%\" border=\"2\">");
			stringBuffer.append("<tr>"); 
		    stringBuffer.append("<td width=\"21%\" height=\"43\">"); 
		    stringBuffer.append("<div align=\"left\">Produto</div></td>");
		    stringBuffer.append("<td width=\"21%\" height=\"43\">"); 
		    stringBuffer.append("<div align=\"left\">Dono</div></td>");
		    stringBuffer.append("<td width=\"37%\" height=\"43\">Existe Leil�o</td>");
		    stringBuffer.append("<td width=\"37%\" height=\"43\">Funcionando</td>");
			
			stringBuffer.append("</tr>");
			
			i=0;
			descricaoProduto = Enviador.pegaParte(m_resultadoBusca,0,'&');
			
			String nomeProduto,nomeDono,prazo,tipoLeilao,nomeVencedor;
			while (!descricaoProduto.equals(""))
			{
				nomeProduto = Enviador.pegaParte(descricaoProduto,0,'#');
				nomeDono = Enviador.pegaParte(descricaoProduto,1,'#');
				prazo = Enviador.pegaParte(descricaoProduto,2,'#');								
				tipoLeilao = Enviador.pegaParte(descricaoProduto,3,'#');												
				nomeVencedor = Enviador.pegaParte(descricaoProduto,4,'#');																
				
				
				stringBuffer.append("<tr>\n");
				stringBuffer.append("<td width=\"18%\" height=\"31\">\n");			
				stringBuffer.append("<div align=\"left\"> <a href=\"/leilao/jsp/ProdutoIndividual.jsp?nomeUsuario="+nomeDono+"&nomeProduto="+nomeProduto+"\">"+nomeProduto+"</a></div></td>\n");
				stringBuffer.append("<div align=\"left\"> <a href=\"/leilao/jsp/PerfilUsuario.jsp?nomeUsuario="+nomeDono+"\">"+nomeDono+"</a></div></td>\n");				
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+prazo+"</td>\n");			
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+tipoLeilao+"</td>\n");							
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+nomeVencedor+"</td>\n");							
				stringBuffer.append("</tr>\n");						
				stringBuffer.append("\n");						
	
				i++;
				descricaoProduto = Enviador.pegaParte(m_resultadoBusca,i,'&');
			}
			stringBuffer.append("</table>");
			stringBuffer.append("</div>");
		}
		catch (Exception e) 
		{
			System.err.println("Erro o imprimeAgentes do BeanPegaAgentes Exception:  " + e);
			return stringBuffer.toString();
		}


			return stringBuffer.toString();
	}

	public boolean processa()
	{
		System.out.println("Procesando BeanPegaProdutosBusca");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Mensagem msg = new Mensagem(nomeUsuario,Inet.toString());
			//AINDA n�o estou passando o password.
//			Msg.setMensagem("PEGPARTPOS");
			msg.setMensagem("PEGAPRODUTOSS");
			
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,msg);
			msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
			
			if(msg.mensagemRetorno())
				m_resultadoBusca = "OK";
	
				
			System.out.println("\nRetornou PEGPARTPOS *********" );
		}
		catch (UnknownHostException e) 
		{
			System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanPegaProdutosBusca Exception:  " + e);
			return false;
		}
		return true;		
		
	}
}
