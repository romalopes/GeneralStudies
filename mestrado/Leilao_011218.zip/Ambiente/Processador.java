
import java.io.*;    //Package de classes para manipulacao de E/S
import java.net.*;   //Package de classes para manipulacao de Sockets, IP, etc.
import java.util.*;

import ClassesGeral.ObjetoEnviado;
import ClassesGeral.Enviador;
import ClassesGeral.Mensagem;
import ClassesGeral.Caracteristica;
import ClassesGeral.VetorCaracteristica;


public class Processador 
{
//final static int PortaRecebimentoServidor = 8184;
//final static int PortaRecebimentoCliente = 8183;
//final static String nomeHost = "192.168.0.12";
	Mensagem m_mensagem;
	
 /*Listas de Participantes do leilao e produtos*/
	Vector m_listLeiloeiros;
	Vector m_listProdutos;
	Vector m_listParticipantes;
	Vector m_ParticLogados;
	Relogio m_relogio;
	int m_numProdutos;
	int numeroOferta;
 /*Listas de Participantes do leilao e produtos*/

	public Processador()
	{
	
		Enviador.nomeHostProcessador = /*"neylpride.addlabs.uff.br";//*/"192.168.0.25";	
		Enviador.nomeHostGerente = /*"neylpride.addlabs.uff.br";/*/"192.168.0.25";
	
		numeroOferta = 0;
	/*Listas de Participantes do leilao e produtos*/
		m_listLeiloeiros = new Vector();
		m_ParticLogados = new Vector();
		m_listProdutos = new Vector();
		m_listParticipantes = new Vector();
		m_numProdutos = 0;
	/*Listas de Participantes do leilao e produtos*/
		scriptInicial();
	}

	public void	startRelogio()
	{
		if (m_relogio == null)
		{
			m_relogio = new Relogio(this);
			m_relogio.start();//come�ou buscar... 
		}
	}
/********************* scriptInicial *************************************/
//vai criar um usuario, produto etc...
	public void scriptInicial()
	{
		try
		{
			Mensagem msg = new Mensagem("","");
			
			msg.setNome("roma");
			msg.setMensagem("RGPART");		
			msg.setMensagemAux("lopes,roma@bol.com.br");
			ProcessaMensagem(msg);
			
			msg.setNome("maria");
			msg.setMensagem("RGPART");		
			msg.setMensagemAux("lopes,maria@bol.com.br");
			ProcessaMensagem(msg);
	//		RegistraParticipante("roma","lopes");
/*
			msg.setNome("roma");
			msg.setMensagem("RGPROD");
			msg.setMensagemAux("carro,Carro Bom pra Caramba");
			ProcessaMensagem(msg);
			//		RegistraProduto("roma","carro,Carro Bom pra Caramba");
			
			Produto prod = findProduto("carro");
			String a = "nomeProduto&carro&codigo&"+prod.ID()+"&detalhes&Carro Bom pra Caramba&tipoLeilao&Ingles&prazo&7&valorInicial&10&menordiferenca&10&bValorReserva&false";
			msg.setNome("roma");
			msg.setMensagem("TRATAL");
			msg.setMensagemAux(a);
			ProcessaMensagem(msg);
	//		TrataLeilao("roma",a);//nome,tipo,prazo,valorinicial,menorincremento,bvalorreserva,valorreserva

			
			msg.setNome("roma");
			msg.setMensagem("RGPROD");
			msg.setMensagemAux("relogio 2,Relogio Faz tudo");
			ProcessaMensagem(msg);
	//		RegistraProduto("roma","relogio,Relogio Faz tudo");


			prod = findProduto("relogio 2");
			a =  "nomeProduto&relogio 2&codigo&"+prod.ID()+"&detalhes&Relogio Faz tudo&tipoleilao&Holandes&prazo&50&valorInicial&30&menordiferenca&5&bValorReserva&true&valorReserva&5";
			msg.setNome("roma");
			msg.setMensagem("TRATAL");
			msg.setMensagemAux(a);
			ProcessaMensagem(msg);		
*/	//		TrataLeilao("roma",a);//nome,tipo,prazo, valorinicial,valorDecremento
		}
		catch(Exception e)
		{
			System.err.println("Erro no Script inicial");
		}
	}
	
	
/********************* findParticipante *************************************/
	public Participante findParticipante(String nome)
	{
		Participante p;
		for(int i=0;i<m_listParticipantes.size();i++)
		{
			p = (Participante)m_listParticipantes.elementAt(i);
			if(p.nome().equals(nome))
				return p;
		}
		return null;
	}

/********************* PegaParticipante *************************************/
	public Participante PegaParticipante(int pos)
	{
		if(pos < m_listParticipantes.size())
		{
			return (Participante)m_listParticipantes.elementAt(pos);
		}
		return null;
	}
/********************* participanteLogado *************************************/
	public Participante participanteLogado(String nome)
	{

		for(int i=0;i<m_ParticLogados.size();i++)
		{
			Participante part = (Participante)m_ParticLogados.elementAt(i);
			if(part.nome().equals(nome))
			   return part;
		}
		return null;
	}



/********************* findProduto ****************************************/
	public Produto findProduto(String nome)
	{
		Produto p;
		for(int i=0;i<m_listProdutos.size();i++)
		{
			p = (Produto)m_listProdutos.elementAt(i);
			if(p.nome().equalsIgnoreCase(nome))
				   return p;
		}
		return null;
	}

/********************* findProdutoID ****************************************/
	public Produto findProdutoID(String id)
	{
		Produto p;
		for(int i=0;i<m_listProdutos.size();i++)
		{
			p = (Produto)m_listProdutos.elementAt(i);
			if(id.equalsIgnoreCase(String.valueOf(p.codigo())))
				   return p;
		}
		return null;
	}

/********************* findDonoID ****************************************/
	public Participante findDonoID(String codProd)
	{
		Participante Partic;
		Produto prod = findProdutoID(codProd);
		if( prod == null)
		{
			System.out.println("IsDono - Produto nao existe "+ codProd);
			return null;
		}
		if( prod.dono() == null)
		{
			System.out.println("IsDono - Partic dono do Produto nao Existe para o prod:"+ prod.nome());
			return null;
		}
		return prod.dono();
		
	}
/********************* IsDono ****************************************/
	public boolean IsDono(String nome,String nomeProd)
	{
		Participante Partic = findParticipante(nome);
		if( Partic == null)
		{
			System.out.println("IsDono - Partic dono do Produto nao Existe "+ nome);
			return false;
		}
		Produto pProduto = findProduto(nomeProd);
		if( pProduto == null)
		{
			System.out.println("IsDono - Produto nao existe "+ nomeProd);
			return false;
		}

		if(!Partic.isDono(pProduto.nome()))
		{
			System.out.println("IsDono - Partic "+Partic.nome()+" nao e dono do Produto "+ nomeProd);
			return false;
		}
//		System.out.println("IsDono - Participante "+Partic.nome()+" e dono do Produto "+ nomeProd);
		return true;
	}
/********************* IsDonoID ****************************************/
	public boolean IsDonoID(String nome,String ID)
	{
		Participante Partic = findParticipante(nome);
		if( Partic == null)
		{
			System.out.println("IsDonoID - Partic dono do Produto nao Existe "+ nome+ "  " +ID);
			return false;
		}
		Produto pProduto = findProdutoID(ID);
		if( pProduto == null)
		{
			System.out.println("IsDonoID - Produto nao existe "+ ID);
			return false;
		}

		if(!Partic.isDonoID(pProduto.codigo()))
		{
			System.out.println("IsDono - Partic "+Partic.nome()+" nao e dono do Produto "+ ID+ ": " +pProduto.nome());
			return false;
		}
//		System.out.println("IsDono - Participante "+Partic.nome()+" e dono do Produto "+ nomeProd);
		return true;
	}



/********************* findLeiloeiro ****************************************/
	public Leiloeiro findLeiloeiro(String id)
	{
	
		Leiloeiro l;
		for(int i=0; i<m_listLeiloeiros.size();i++)
		{
			l = (Leiloeiro)m_listLeiloeiros.elementAt(i);
			if(id.equals(l.produto().codigo()))
				return l;
		}
		return null;
	}

/********************* findLeiloeiro ****************************************/
	public Leiloeiro findLeiloeiro(Produto p)
	{
		Leiloeiro l;
		for(int i=0; i<m_listLeiloeiros.size();i++)
		{
			l = (Leiloeiro)m_listLeiloeiros.elementAt(i);
			if(l.produto() == p)
				return l;
		}
		return null;
	}



/*********************  ****************************************/
//Se o participante nao existir cria e insere na lista de participantes
//Nao temos diferenca entre comprador ou vendedor(pelo menos por enquanto)
	public Mensagem RegistraParticipante(String nome,String string)
	{
		Mensagem msg = new Mensagem("site","");
		try
		{
			msg.setOrigem("site");
			msg.setDestino(nome);
			msg.setReply(false);
			msg.setMensagem("recebeReplyRegistroAKRM");
			msg.setMensagemRetorno(false);
			msg.setMensagemAux("OK");
			msg.setTipo("Agente");
			String email,passWord;
			
			passWord = Enviador.pegaParte(string,0,',');
			email = Enviador.pegaParte(string,1,',');
			
			System.out.println("nome:"+ nome+" password:"+passWord+" email:"+email);
			Participante p = findParticipante(nome);
			if( p != null)
			{
				System.out.println("Participante Ja Existe "+ nome);
				return msg;
			}

			p = new Participante(nome);
			m_listParticipantes.addElement(p);
			p.setSenha(passWord);
			p.setEmail(email);

			if (LoginParticipante(nome,passWord))
			{
				msg.setMensagem("recebeReplyRegistroAKRM");		
				msg.setMensagemRetorno(true);
			}			
		}
		
		catch(Exception e)
		{
			System.err.println(e+ " Erro em RegistraParticipante "+ nome);
		}
		return msg;		
	}

	public boolean LoginParticipante(String nome,String passWord)
	{
		Participante partic = findParticipante(nome);
		if( partic == null)
		{
			System.out.println("Participante N�o Existe "+ nome);
			return false;
		}
		if (partic.senha().equals(passWord))
		{
			System.out.println("Participante Logado "+ nome);
			if(participanteLogado(nome) == null)
				m_ParticLogados.addElement(partic);
			return true;
		}
		return false;
	}


	public boolean LogOutParticipante(String nome)
	{
		Participante partic = findParticipante(nome);
		if( partic == null)
		{
			System.out.println("Participante N�o Existe "+ nome);
			return false;
		}
		if (participanteLogado(nome) != null)
		{
			System.out.println("LogOut do Participante "+ nome);
			m_ParticLogados.removeElement(partic);
		}
	
		return true;
	}

/********************* RemoveUsuario ****************************************/
	public boolean RemoveUsuario(String nome,String passWord)
	{
		try
		{
			System.out.println("Passando por Retira Participante");

			Participante p;
			for(int i=0;i<m_listParticipantes.size();i++)
			{
				p = (Participante)m_listParticipantes.elementAt(i);
				if(p.nome().equals(nome) && p.senha().equals(passWord))
				{
					System.out.println("Participante Retirado "+ p.nome());
					p.Finalize();
					
					LogOutParticipante(nome);
					
					return true;
				}
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em RemoveUsuario "+nome);
		}
		
		System.out.println("Participante Nao Existe ou Senha incorreta"+ nome);
		return false;		
	}

/******************** buscaParticipanteIndiviual ***************************/
//resultado: prod.ID()&prod.nome()&prod.detalhes()&prod.bValorReserva()&prod.ValorReserva()&
//true ou false&l.valorInicial()&l.valorAtual()&l.valorVencedor()&l.valorVencedor()&
	public Mensagem buscaParticipanteIndividual(Mensagem msg)
	{				
		msg.setMensagemRetorno(true);
		msg.setReply(false);
		msg.setMensagem("recebeReplyBuscaParticipanteIndividual");
		StringBuffer buffer = new StringBuffer(1000);
		String string = new String();
		try
		{
		
			String nomeUsuarioAgente = msg.origem();
			String nome = msg.nome();
			String nomeParticipanteBuscado = msg.mensagemAux();
		
			System.out.println("Passando por BuscaParticipantendividual:"+nomeParticipanteBuscado);
			Produto prod;
			
			Participante partic = findParticipante(nomeParticipanteBuscado);
			
			if (partic != null)
			{
				buffer.append("nomeParticipante&"+partic.nome() +"&");//2					
				buffer.append("estrelas&"+partic.numeroEstrelas()+"&");
			}
			msg.setDestino(nomeUsuarioAgente);
			msg.setMensagemAux(buffer.toString());					
			msg.setMensagemRetorno(true);
					
			return msg;
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em buscaParticipanteIndividual");
		}
		return msg;
	}


/********************* RegistraProduto *************************************/
	public Mensagem RegistraProduto(String nome,String Parte)
	{
		Mensagem msg = new Mensagem("","");
		System.out.println("Passando por RegistraProduto");

		try
		{
		
			msg.setOrigem("site");
			msg.setDestino(nome);
			msg.setReply(false);
			msg.setMensagem("recebeReplyInsereProduto");
			msg.setMensagemRetorno(false);
			msg.setTipo("Agente");
			
			String nomeProd = Enviador.pegaParte(Parte,0,',');
			String detalhes = Enviador.pegaParte(Parte,1,',');

			Produto pProduto;
			Participante Partic = findParticipante(nome);
			if( Partic == null)
			{
				System.out.println("Participante dono do Produto nao Existe "+ nome);
				return msg;
			}

			pProduto = Partic.findProduto(nomeProd);
			if(pProduto != null)
			{
				System.out.println("Produto ja existe "+ nomeProd+" em nome de"+pProduto.dono().nome());
				return msg;
			}

			pProduto = new Produto(nomeProd);
			m_listProdutos.addElement(pProduto);
			m_numProdutos++;
			pProduto.setCodigo(String.valueOf(m_numProdutos));
			pProduto.setDono(Partic);
			pProduto.setDetalhes(detalhes);
			Partic.addProduto(pProduto);
			System.out.println("Produto registrado "+pProduto.nome() + " em nome de "+Partic.nome());

			msg.setMensagemAux(pProduto.codigo()+",AKRM");

			msg.setMensagemRetorno(true);

		}
		catch(Exception e)
		{
			System.err.println(e+ " Erro em RegistraProduto");
		}
		return msg;
	}






/********************* RegistraProdutoLeilao ***************************/
//nomeProd,tipoLeilao,
//					prazo,valorInicial,menordiferenca
//					valorInicial,tempoDecremento,valorDecremento
	public Mensagem RegistraProdutoLeilao(Mensagem mensagem)
	{
		Mensagem msg = new Mensagem("","");
		
		String smensagemAux,string;
		int i;
		
		
		smensagemAux = mensagem.mensagemAux();
		String nome = mensagem.nome();
		try
		{
			String nomeProd = Enviador.pegaParte(smensagemAux,1,',');		
			String detalhes = nomeProd+","+Enviador.pegaParte(smensagemAux,7,',');		
			msg = RegistraProduto(nome,detalhes);

			msg.setOrigem("site");
			msg.setDestino(nome);
			msg.setReply(false);
			msg.setMensagem("recebeReplyRegistraProdutoLeilao");

			if(!msg.mensagemRetorno())
				return msg;

			//pega o codigo.
			String codigo = Enviador.pegaParte(msg.mensagemAux(),0,',');//recebido do RegistraProduto

			smensagemAux = Enviador.pegaParte(mensagem.mensagemAux(),0,',');		
			smensagemAux += "&"+Enviador.pegaParte(mensagem.mensagemAux(),1,',');		
			smensagemAux += "&"+Enviador.pegaParte(mensagem.mensagemAux(),2,',');		
			smensagemAux += "&"+codigo;		
			
			i=4;
			string = Enviador.pegaParte(mensagem.mensagemAux(),i,',');		
			while (!string.equalsIgnoreCase(""))
			{

				smensagemAux += "&"+string;			
				i++;		
				string = Enviador.pegaParte(mensagem.mensagemAux(),i,',');						
			}
			
			
			msg.setMensagemRetorno(false);
			
			msg = TrataLeilaoID(nome,smensagemAux);
			msg.setMensagem("recebeReplyRegistraProdutoLeilao");			
			msg.setMensagemAux("OK");						
		}
		catch(Exception e)
		{
			System.err.println(" Erro no RegistraProdutoLeilao "+ e );
		}
		return msg;
	}
/********************* RetiraProduto *************************************/
	public boolean RetiraProduto(String nome,String nomeProd)
	{
		try
		{
			System.out.println("Passando por RetiraProduto");
			if(!IsDono(nome,nomeProd))
			{
				return false;
			}
			Participante Partic = findParticipante(nome);
			Produto prod;
			for(int i=0;i<m_listProdutos.size();i++)
			{
				prod = (Produto)m_listProdutos.elementAt(i);
				if(prod.nome().equals(nomeProd))
				{
					RetiraLeilao(nome, nomeProd);//retira o leilao se ele estiver vivo nao pode.

					System.out.println("Produto Retirado "+ prod.nome());
					prod.Finalize();
					Partic.retiraProduto(prod);
					return true;
				}
			}
			System.out.println("Produto nao pode retirado "+ nomeProd + " em nome de "+nome);
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em RetiraProduto");
		}
		return false;	
	}
		

/********************* RetiraProdutoID *************************************/
	public boolean RetiraProdutoID(String nome,String codigoProd)
	{
		try
		{
			System.out.println("Passando por RetiraProduto");
			if(!IsDonoID(nome,codigoProd))
			{
				return false;
			}
			Participante Partic = findParticipante(nome);
			Produto prod;
			for(int i=0;i<m_listProdutos.size();i++)
			{
				prod = (Produto)m_listProdutos.elementAt(i);
				if(prod.codigo().equals(codigoProd))
				{
					RetiraLeilaoID(nome, codigoProd);//retira o leilao se ele estiver vivo nao pode.

					System.out.println("Produto Retirado "+ prod.nome());
					prod.Finalize();
					Partic.retiraProduto(prod);
					return true;
				}
			}
			System.out.println("Produto nao pode retirado "+ codigoProd + " em nome de "+nome);
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em RetiraProduto");
		}
		return false;	
	}
		


		
/********************* BuscaProdutos *************************************/
//resultado: prod.ID()&prod.nome()&prod.detalhes()&prod.bValorReserva()&prod.valorReserva()&
//true ou false&l.valorInicial()&l.valorAtual()&l.valorVencedor()&l.valorVencedor()&
	public Mensagem BuscaProdutos(Mensagem msg)
	{
		msg.setMensagemRetorno(true);
		msg.setReply(false);
		StringBuffer buffer = new StringBuffer(1000);
		String string = new String();
		try
		{
		
			String nomeUsuario = msg.origem();
			String nome = msg.nome();
			String nomeProd	 = msg.mensagemAux();
		
			System.out.println("Passando por BuscaProdutos "+nomeUsuario+" "+nomeProd);
			Produto prod;
			System.out.println(nomeUsuario+ " "+nome);
			for(int i=0;i<m_listProdutos.size();i++)
			{
				prod = (Produto)m_listProdutos.elementAt(i);
				

//				if(i!=null && l.isRodando() 
				Leiloeiro l;
				
				//v� se a string1 est� dentro da string2	
				if(Enviador.encontraRelacaoPalavras(nomeProd,prod.nome()) && !IsDono(nome,prod.nome()))
				{	
					l = prod.leiloeiro();
					
					if(!l.rodando())
						continue;
					
					buffer.append(prod.appendBufferProduto());
					buffer.append(",");											
				}			
			}
			msg.setDestino(nomeUsuario);
			msg.setMensagem("recebeReplyBuscaProdutos");
//			System.out.println("Lista: "+buffer.toString());
			msg.setMensagemAux(buffer.toString());					
			msg.setMensagemRetorno(true);
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em BuscaProdutos");
		}
		return msg;
	}








/******************** apendBufferProduto ******************************
	private String apendBufferProduto(Produto pProduto)
	{
		StringBuffer stringBuffer = new StringBuffer(500);
		try
		{
			Leiloeiro l;
			l = pProduto.leiloeiro();
		
			stringBuffer.append("dono&"+pProduto.dono().nomeUsuarioPagina()+"&");//0					
			stringBuffer.append("nomeProduto&"+pProduto.nome() +"&");//2					
			stringBuffer.append("codigo&"+pProduto.codigo() +"&");//1
			stringBuffer.append("detalhes&"+pProduto.detalhes() +"&");//3
			stringBuffer.append("nomePagina&AKRM&");//3										
			if (l.tipo().equalsIgnoreCase("Ingles"))
			{
				stringBuffer.append("tipoLeilao&Ingles&");//3										
				Leil_Ingles lp = (Leil_Ingles)l;					
				stringBuffer.append("bValorReserva&"+l.vetorCaracteristica.getValorCarac("bValorReserva")+"&");//5					
				stringBuffer.append("ValorReserva&"+l.vetorCaracteristica.getValorCarac("ValorReserva") +"&");//6
			}
			else						
			{
				stringBuffer.append("tipoLeilao&Holandes&");//3															
				Leil_Holandes lh = (Leil_Holandes)l;					
				stringBuffer.append("bValorreserva&false&");//4
				stringBuffer.append("Valorreserva&0&");//5
			}
			stringBuffer.append("menordiferenca&"+l.vetorCaracteristica.getValorCarac("menorDiferenca")+"&");//5					
			stringBuffer.append("valorInicial&"+l.vetorCaracteristica.getValorCarac("ValorInicial") +"&");//6
			stringBuffer.append("valorAtual&"+l.valorAtual() +"&");//7
			stringBuffer.append("valorvencedor&"+l.valorVencedor() +"&");//8
			stringBuffer.append("dataInicio&"+l.vetorCaracteristica.getValorCarac("dataInicio") +"&");
			stringBuffer.append("prazo&"+l.vetorCaracteristica.getValorCarac("prazo") +"&");//9
			stringBuffer.append("participanteAtual&"+l.printParticipanteAtual() +"&");
			stringBuffer.append("pagina&AKRM&");			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em apendBufferProduto");
		}
	
		return stringBuffer.toString();
	}

/******************** buscaProdutoIndividual ******************************/
//resultado: prod.ID()&prod.nome()&prod.detalhes()&prod.bValorReserva()&prod.ValorReserva()&
//true ou false&l.valorInicial()&l.valorAtual()&l.valorVencedor()&l.valorVencedor()&
	public Mensagem buscaProdutoIndividual(Mensagem msg)
	{
		msg.setMensagemRetorno(true);
		msg.setReply(false);
		msg.setMensagem("recebeReplyBuscaProdutoIndividual");
		StringBuffer buffer = new StringBuffer(1000);
		String string = new String();
		try
		{
		
			String nomeUsuario = msg.origem();
			String nome = msg.nome();
			String codProd = msg.mensagemAux();
		
			msg.setDestino(nomeUsuario);
				
			Produto pProduto;
			
			for(int i=0;i<m_listProdutos.size();i++)
			{
				pProduto = (Produto)m_listProdutos.elementAt(i);
				
				Leiloeiro l;
				if(codProd.equalsIgnoreCase(pProduto.codigo()) )//&& !IsDonoID(nomeUsuario,pProduto.ID()))
				{
					l = pProduto.leiloeiro();
					
					if(l== null || !l.rodando())
						continue;
						
					buffer.append(pProduto.appendBufferProduto());
					
					buffer.append(",");											
					
					msg.setDestino(nomeUsuario);
					msg.setMensagem("recebeReplyBuscaProdutoIndividual");
					msg.setMensagemAux(buffer.toString());					
					msg.setMensagemRetorno(true);
					
					return msg;
				}			
				
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em BuscaProdutoIndividual");
		}
		return msg;
	}


/********************* buscaProdutosNegociados ****************************/
	public Mensagem buscaProdutosNegociados(Mensagem msg)
	{
		try
		{
			String nome = msg.nome();
			StringBuffer buffer = new StringBuffer(500);
			
			Participante pParticipante = findParticipante(nome);
			
			msg.setMensagemRetorno(false);
			msg.setDestino(msg.origem());
			
			//se o participante n�o existir sai			
			if(pParticipante == null)
				return msg;
				

			Produto pProduto;
			Leiloeiro l;
							
//			m_listProdutosComprados
			for(int i=0;i<pParticipante.m_listProdutosComprados.size();i++)
			{
				pProduto = (Produto)pParticipante.m_listProdutosComprados.elementAt(i);
				
				l = pProduto.leiloeiro();
					
				if(!l.rodando())
					continue;
						
				buffer.append(pProduto.appendBufferProduto());
					
				buffer.append(",");											
					
			
			}
			
			buffer.append("#");						
//			m_listProdutosOferta
			for(int i=0;i<pParticipante.m_listProdutosOferta.size();i++)
			{
				pProduto = (Produto)pParticipante.m_listProdutosOferta.elementAt(i);
				
				l = pProduto.leiloeiro();
					
				if(!l.rodando())
					continue;
						
				buffer.append(pProduto.appendBufferProduto());
					
				buffer.append(",");											
					
			
			}

			buffer.append("#");			
			//m_listProdutosVendidos			
			for(int i=0;i<pParticipante.m_listProdutos.size();i++)
			{
				pProduto = (Produto)pParticipante.m_listProdutos.elementAt(i);
				
				l = pProduto.leiloeiro();
					
				if(!l.rodando())
					continue;
						
				buffer.append(pProduto.appendBufferProduto());
					
				buffer.append(",");											
			}
			
			
			msg.setMensagem("recebeReplyBuscaProdutoIndividual");
			msg.setMensagemAux(buffer.toString());					
			msg.setMensagemRetorno(true);
					
			return msg;
			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em buscaProdutosNegociados");
		}
		return msg;
	}



/********************* RetiraLeilao *************************************/
	public boolean RetiraLeilao(String nome,String nomeProd)
	{
		System.out.println("Passando por MataLeilao");
		if(!IsDono(nome,nomeProd))
		{
			return false;
		}
		Participante Partic = findParticipante(nome);
		Produto p = findProduto(nomeProd);
		Leiloeiro pLeiloeiro = findLeiloeiro(p.codigo());
		if(pLeiloeiro == null)
		{
			System.out.println("Leiloeiro nao foi criado para o pProdutouto "+ nomeProd);
			return false;

		}
		Produto pProduto = findProduto(nomeProd);
		if(pLeiloeiro.isAlive())
		{
			System.out.println("Leiloeiro esta rodando e nao pode ser apagado para o produto "+ nomeProd);
			return false;
		}		

		Leiloeiro l;
		for(int i=0; i<m_listLeiloeiros.size();i++)
		{
			l = (Leiloeiro)m_listLeiloeiros.elementAt(i);
			if(l == pLeiloeiro)
			{
				pProduto.setLeiloeiro(null);
				m_listLeiloeiros.removeElementAt(i);
				System.out.println("Leiloeiro retirado para o produto "+ pProduto.nome() );
				return true;

			}
		}
		System.out.println("Nao foi possivel retirar o leiloeiro para o produto "+ pProduto.nome() );
		return false;


	}
/********************* RetiraLeilaoID *************************************/
	public boolean RetiraLeilaoID(String nome,String codigoProd)
	{
		System.out.println("Passando por MataLeilao");
		if(!IsDono(nome,codigoProd))
		{
			return false;
		}
		Participante Partic = findParticipante(nome);
		Produto p = findProdutoID(codigoProd);
		if(p == null)
		{
			System.out.println("Produto n�o encontrado "+ codigoProd);
			return false;
		}
		
		Leiloeiro pLeiloeiro = findLeiloeiro(p.codigo());
		if(pLeiloeiro == null)
		{
			System.out.println("Leiloeiro nao foi criado para o produto "+ p.nome());
			return false;
		}

		
		if(pLeiloeiro.isAlive())
		{
			System.out.println("Leiloeiro esta rodando e nao pode ser apagado para o produto "+ p.nome());
			return false;
		}		

		Leiloeiro l;
		for(int i=0; i<m_listLeiloeiros.size();i++)
		{
			l = (Leiloeiro)m_listLeiloeiros.elementAt(i);
			if(l == pLeiloeiro)
			{
				p.setLeiloeiro(null);
				m_listLeiloeiros.removeElementAt(i);
				System.out.println("Leiloeiro retirado para o produto "+ p.nome() );
				return true;

			}
		}
		System.out.println("Nao foi possivel retirar o leiloeiro para o produto "+ p.nome() );
		return false;
	}

/********************* TrataLeilaoID *************************************/
//nomeProd,detalhes,tipoLeilao,
//					prazo,valorInicial,menordiferenca
//					valorInicial,tempoDecremento,valorDecremento
	public Mensagem TrataLeilaoID(String nome,String smensagemAux)
	{
		Mensagem msg = new Mensagem("","");
		try
		{
		
		
			msg.setOrigem("site");
			msg.setDestino(nome);
			msg.setReply(false);
			msg.setMensagem("recebeReplyCriaLeilaoAKRM");
			msg.setMensagemRetorno(false);
			msg.setTipo("Agente");
			
			System.out.println("Passando por TrataLeilaoID");
			String Parte;
			String CodProd = Enviador.pegaParte(smensagemAux,3,'&');
			
			System.out.println("MensagemAux "+ smensagemAux);
			
			if(!IsDonoID(nome,CodProd))
			{
				return msg;
			}
			Participante Partic = findParticipante(nome);
			Produto pProduto = findProdutoID(CodProd);
			Leiloeiro pLeiloeiro = findLeiloeiro(pProduto.codigo());

			if(pLeiloeiro != null)
			{
				if(pLeiloeiro.isAlive())
				{
					System.out.println("Leiloeiro ja esta rodando"+ pLeiloeiro.produto().nome());
				}
				else
					System.out.println("Leiloeiro j� foi criado para o produto "+ pProduto.nome());
				return msg;
			}
			Parte = Enviador.pegaParte(smensagemAux,5,'&');
			String detalhes = Enviador.pegaParte(smensagemAux,7,'&');
			Integer valor;
			int i;
			if (Parte.equalsIgnoreCase("Ingles"))
			{//crialeilaoingles
			
				pLeiloeiro = CriaLeilao_Ingles(Partic,pProduto);
				Leil_Ingles pl = (Leil_Ingles)pLeiloeiro; 

			}else if (Parte.equalsIgnoreCase("Holandes"))
			{//crialeilaoHolandes
			
				pLeiloeiro = CriaLeilao_Holandes(Partic,pProduto);
				Leil_Holandes pl = (Leil_Holandes)pLeiloeiro; 

			}
			else
			{
				System.out.println("N�o conseguiu criar o leilao");
				return msg;
			}			
		
			pLeiloeiro.vetorCaracteristica.setCaracteristicas(smensagemAux);
			pLeiloeiro.setValorInicial(pLeiloeiro.vetorCaracteristica.getValorCarac("valorInicial"));
			if(pLeiloeiro.vetorCaracteristica.getValorCarac("bValorReserva").equals("true"))
				pLeiloeiro.setValorReserva(pLeiloeiro.vetorCaracteristica.getValorCarac("valorReserva"));			
			//Comeca a rodar a thread do leiloeiro.	
			pLeiloeiro.start();
		
			
//Aqui seta as caracteristicas do Leil�o
			if(pLeiloeiro.isAlive())
				System.out.println("Esta viva "+ pLeiloeiro.produto().nome());
			else
				System.out.println("Esta morta "+ pLeiloeiro.produto().nome());

			msg.setMensagemRetorno(true);
			
			
//Preenche os valores para retornar as informa��es sobre o leilao
			StringBuffer buffer = new StringBuffer(1000);
			buffer.append(pProduto.appendBufferProduto());
			msg.setMensagemAux(buffer.toString());
		}
		catch(Exception e)
		{
			System.err.println(" Erro no TrataLeilaoID "+ e );
		}
		return msg;
	}



/********************* fechaLeilaoAKRM ********************************/
//O leil�o � fechado pelo site.  Devemos retornar para o site naturalmente e tamb�m
//enviar para todos a mensagem de fechamento
	public synchronized Mensagem fechaLeilaoAKRM(Mensagem msg)
	{
		try
		{
			String nome = msg.nome();
			String codProd = msg.mensagemAux();
			Produto pProduto;
			

			
			msg.setOrigem("site");
			msg.setReply(false);
			msg.setMensagemRetorno(false);
			
			String Parte;
			System.out.println(nome+ "  "+codProd);
			if(!IsDonoID(nome,codProd))
			{
				return msg;
			}
			pProduto = findProdutoID(codProd);
			Participante Partic = findParticipante(nome);
			Leiloeiro pLeiloeiro = pProduto.leiloeiro();//findLeiloeiro(codProd);

			if(pLeiloeiro != null)
			{
//				pLeiloeiro.fechaLeilao();
				pLeiloeiro.setRodando(false);
								
				msg.setMensagemRetorno(true);
				
				//avisa ao dono que vendeu o produto
				pProduto.dono().vendeuProduto(codProd);			
				
				msg.setNome("do Processador fechaLeilaoAKRM");
				msg.setOrigem("site");
				msg.setDestino(pProduto.leiloeiro().retornaListParticipantes()+pProduto.dono().nome());
				msg.setReply(false);
				msg.setMensagem("recebeReplyFechaLeilaoAKRM");
				
				msg.setMensagemAux(pProduto.codigo()+","+pLeiloeiro.printParticipanteAtual()+","+pLeiloeiro.participanteAtual().email()+","+String.valueOf(pLeiloeiro.valorAtual()));

				System.out.println(msg.mensagemAux());  

				msg.setMensagemRetorno(true);
				msg.setTipo("Agente");
				Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,msg);
				
			}
			msg.setDestino(nome);//para retornar par ao local site.
		}
		catch(Exception e)
		{
			System.err.println(e+"Erro no fechaLeilaoAKRM do Leiloeiro");		
			return msg;
		}
		return msg;
	
	}


/********************* AgentefechaLeilao ********************************/
	public Mensagem AgentefechaLeilao(String nome,String smensagemAux)
	{
		Mensagem msg = new Mensagem("","");
		try
		{
			System.out.println("Passando por AgenteFechaLeilao");
			String codProd = Enviador.pegaParte(smensagemAux,0,',');
		
		
			Participante Partic = findParticipante(nome);
			Produto pProduto = findProdutoID(codProd);
			Leiloeiro pLeiloeiro = findLeiloeiro(pProduto.codigo());
			
			msg.setNome("do Processador AgentefechaLeilao");
			msg.setOrigem("site");
			msg.setDestino(pProduto.leiloeiro().retornaListParticipantes()+pProduto.dono().nome());
			msg.setReply(false);
			msg.setMensagem("recebeReplyFechaLeilaoAKRM");
			msg.setMensagemRetorno(false);
			msg.setTipo("Agente");
			msg.setMensagemAux(codProd+","+pProduto.leiloeiro().printParticipanteAtual()+","+pLeiloeiro.participanteAtual().email()+","+String.valueOf(pLeiloeiro.valorAtual()));

			
			System.out.println(msg.mensagemAux());  
			
			if(!IsDonoID(nome,codProd))
			{
				return msg;
			}

			if(pLeiloeiro != null)
			{
				pLeiloeiro.fechaLeilao();
								
				msg.setMensagemRetorno(true);
				
				//avisa ao dono que vendeu o produto
				pProduto.dono().vendeuProduto(pProduto.codigo());			
			}
		}
		catch(Exception e)
		{
			System.err.println(" Erro no fechaLeilao "+ e );
		}
		return msg;		
		
	}
	

/********************* IniciaLeilao *************************************/
	public boolean IniciaLeilao(String nome,String nomeProd)
	{
		System.out.println("Passando por IniciaLeilao");
		if(!IsDono(nome,nomeProd))
		{
			return false;
		}
		Participante Partic = findParticipante(nome);
		Produto p = findProduto(nomeProd);
		Leiloeiro pLeiloeiro = findLeiloeiro(p.codigo());
		if(pLeiloeiro == null)
		{
			System.out.println("Leiloeiro nao foi criado para o produto "+ nomeProd);
			return false;

		}

		if(pLeiloeiro.isAlive())
		{
			System.out.println("Leiloeiro ja esta rodando"+ pLeiloeiro.produto().nome());
			return false;
		}
		else
			System.out.println("Leiloeiro esta inativo "+ pLeiloeiro.produto().nome());

		//Comeca a rodar a thread do leiloeiro.	
		pLeiloeiro.start();

		if(pLeiloeiro.isAlive())
			System.out.println("Esta viva "+ pLeiloeiro.produto().nome());
		else
			System.out.println("Esta morta "+ pLeiloeiro.produto().nome());
		
		return true;
	}


/********************* Salva *************************************/
//Salva o Arquivo
	public boolean Salva(String nome,String nomeArq) throws IOException
	{
		try
		{	
		
			if(!nome.equalsIgnoreCase("ADMINISTRADOR"))
			{
				System.out.println("Usu�rio n�o � o administrador"+ nome);
				return false;
			}	

			nomeArq = nomeArq+".lag";	
			FileOutputStream out = new FileOutputStream(nomeArq);
			ObjectOutputStream s = new ObjectOutputStream(out);

			s.write(m_numProdutos);
			
			//salva os leiloeiros.
			int i,num = m_listLeiloeiros.size();
			s.write(num);

			for(i=0;i<num;i++)
			{
				s.writeObject(m_listLeiloeiros.elementAt(i));
			}
			
			//salva os participantes
			num = m_listParticipantes.size();
			s.write(num);
			for(i=0;i<num;i++)
			{
				s.writeObject(m_listParticipantes.elementAt(i));
			}
			
			//salva os produtos.
			num = m_listProdutos.size();
			s.write(num);
			for(i=0;i<num;i++)
			{
				s.writeObject(m_listProdutos.elementAt(i));
			}
		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no Salva do Processador" );
		}			
	
		return true;
	}	


/********************* Abre *************************************/
//Abre o Arquivo
	public boolean Abre(String nome,String nomeArq) throws IOException, ClassNotFoundException
	{
		try
		{
			if(!nome.equalsIgnoreCase("ADMINISTRADOR"))
			{
				System.out.println("Usu�rio n�o � o administrador"+ nome);
				return false;
			}	

			m_listProdutos = new Vector();
			m_listLeiloeiros = new Vector();
			m_listParticipantes = new Vector();
			nomeArq = nomeArq+".agl";	
			FileInputStream in = new FileInputStream(nomeArq);
			ObjectInputStream s = new ObjectInputStream(in);
			//abre os leiloeiros.
			
			m_numProdutos = s.read();
			int num = s.read();
			int i;
			for( i=0;i<num;i++)
			{
				m_listLeiloeiros.addElement((Leiloeiro)s.readObject());
			}

			
			//salva os participantes
			num = s.read();
			for(i=0;i<num;i++)
			{
				m_listParticipantes.addElement(s.readObject());
			}

			
			//abre os produtos.
			num = s.read();
			for(i=0;i<num;i++)
			{
				m_listProdutos.addElement(s.readObject());
				
			}
		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no Salva do Processador" );
		}			
		return true;
	}


/********************* CriaLeilao_Inlges *************************************/
	public Leiloeiro CriaLeilao_Ingles(Participante Partic,Produto pProduto)
	{
		System.out.println("Passando por CriaLeilao_Ingles");

		Leiloeiro l = new Leil_Ingles(pProduto);
		m_listLeiloeiros.addElement(l);
		pProduto.setLeiloeiro(l);
		System.out.println("Leiloeiro Criado para o produto "+ pProduto.nome() + "\n Em nome de "+Partic.nome()+"com o tipo =>Ingles" );
		return l;
}

/********************* CriaLeilao_Holandes *************************************/
	public Leiloeiro CriaLeilao_Holandes(Participante Partic,Produto pProduto)
	{
		System.out.println("Passando por CriaLeilao_Holandes");

		Leiloeiro l = new Leil_Holandes(pProduto);
		m_listLeiloeiros.addElement(l);
		pProduto.setLeiloeiro(l);

		System.out.println("Leiloeiro Criado para o produto "+ pProduto.nome() + "\n Em nome de "+Partic.nome()+"com o tipo =>Holandes" );
		return l;
}


/********************* CriaLeilao *************************************/
	public boolean CriaLeilao(String nome,String nomeProd,String Tipo)
	{

		System.out.println("Passando por CriaLeilao");
		if(!IsDono(nome,nomeProd))
			return false;

		Participante Partic = findParticipante(nome);
		Produto pProduto = findProduto(nomeProd);
		Leiloeiro pLeiloeiro = findLeiloeiro(pProduto.codigo());

		if(pLeiloeiro != null)
		{
			System.out.println("Leiloeiro ja existe "+ nomeProd);
			return false;
		}
		
		if(Tipo.equalsIgnoreCase("1"))
			if(CriaLeilao_Ingles(Partic,pProduto)!=null)
				return true;
		else
		if(Tipo.equalsIgnoreCase("2"))
			if(CriaLeilao_Holandes(Partic,pProduto)!=null)
				return true;
		else
			System.out.println("Erro em CriaLeilao "+ nomeProd + " em nome de"+nome);

		return false;
		
	}

/********************* vendedorDesisteLeilao *****************************/
	public Mensagem vendedorDesisteLeilao(Mensagem mensagem)
	{
		Mensagem msg = new Mensagem("","");
		try
		{
			String nome = msg.nome();
			String codProd = msg.mensagemAux();
			Produto pProduto;
			
			pProduto = findProdutoID(codProd);
			
			msg.setOrigem("site");
			msg.setDestino(nome);
			msg.setReply(false);
			msg.setMensagem("recebeReplyVendedorDesisteLeilaoAKRM");
			msg.setMensagemRetorno(false);
			
			String Parte;
			System.out.println(nome+ "  "+codProd);
			if(!IsDonoID(nome,codProd))
			{
				return msg;
			}
			Participante Partic = findParticipante(nome);
			Leiloeiro pLeiloeiro = findLeiloeiro(codProd);

			if(pLeiloeiro != null)
			{
	//				pLeiloeiro.fechaLeilao();
				pLeiloeiro.setRodando(false);
								
				msg.setMensagemRetorno(true);
				
				//avisa ao dono que vendeu o produto
//				pProduto.dono().vendeuProduto(codProd);			
			}
		}
		catch(Exception e)
		{
			System.err.println(e+"Erro no fechaLeilaoAKRM do Leiloeiro");		
			return msg;
		}
		return msg;
		
	
	}

/********************* ofertaLeilao *************************************/
	public Mensagem ofertaLeilao(Mensagem mensagem)
	{
		Mensagem msg = new Mensagem("","");
		try
		{
			numeroOferta++;
			String nome,IDProd,valor;
			nome = mensagem.nome();
			IDProd = Enviador.pegaParte(mensagem.mensagemAux(),0,',');
			valor = Enviador.pegaParte(mensagem.mensagemAux(),1,',');			
			
			double dValor = 0;

			System.out.println("Passando por OfertaLeilao num:"+numeroOferta+" nomeProd:"+IDProd+" valor:"+valor);
			if(IsDonoID(nome,IDProd))
			{
				System.out.println("O proprio dono nao pode fazer oferta "+ nome + " -> "+ IDProd);

				return msg;
			}
			Participante pPartic = findParticipante(nome);
			Produto pProduto = findProdutoID(IDProd);
			Leiloeiro pLeiloeiro = findLeiloeiro(pProduto.codigo());

			if (pPartic == null)
			{
				System.out.println("Participante nao existe "+ nome);
				return msg;
		
			}

			if(pLeiloeiro == null)
			{
				System.out.println("Leiloeiro nao existe "+ IDProd);
				return msg;
			}

			msg.setReply(false);
			msg.setTipo("Ambos");
			msg.setOrigem("site");
			msg.setMensagemRetorno(false);
			msg.setMensagem("recebeReplyOferta");			

			dValor = Enviador.pegaParteDouble(valor,0,',');
//			Double pl = new Double(Double.parseDouble(valor));


			if (!pLeiloeiro.rodando())//
			{
				msg.setDestino(nome);
				msg.setMensagemAux(pLeiloeiro.printParticipanteAtual()+","+IDProd+","+String.valueOf(pLeiloeiro.valorAtual())+",fechado");
				
			}
			else
			//Restricoes do leiloeiro sobre o participante.
			if (!pLeiloeiro.AnalisaRestricoes(pPartic,dValor))//Oferta nao aceita.
			{
				msg.setDestino(nome);
				msg.setMensagemRetorno(false);
				msg.setMensagemAux(pLeiloeiro.printParticipanteAtual()+","+IDProd+","+String.valueOf(pLeiloeiro.valorAtual())+",restricoes");
			
				return msg;
			}
			else
			{
				pLeiloeiro.recebeOferta(pPartic,dValor);//retorna a lista de usuarios.

				pPartic.addProdutoOferta(pProduto);
				
				//primeiro avisa aos outros que a oferta foi realizada		
				msg.setDestino(pLeiloeiro.retornaListParticipantes()+pProduto.dono().nome());
				System.out.println("Destino:"+pLeiloeiro.retornaListParticipantes());
					
				//NomeUsuario,IDProd,ValorOferta,perfil do usu�rio que est� enviando a mensagem.
				msg.setMensagemAux(pPartic.nome()+","+IDProd+","+String.valueOf(pLeiloeiro.valorAtual())+","+String.valueOf(pPartic.numeroEstrelas()));
				System.out.println(msg.mensagemAux());
				msg.setMensagemRetorno(true);
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em ofertaLeilao");
		}
		return msg;
	}

	public  synchronized void recebeAvisoRelogio()
	{
		try
		{
			// create a GregorianCalendar 
			System.out.println("\n\nProcessador foi avisado em : "+ Enviador.getStringData(new GregorianCalendar()));//calendar.get(Calendar.SECOND)+"/"+calendar.get(Calendar.MINUTE)+"/"+calendar.get(Calendar.HOUR_OF_DAY)+"/"+calendar.get(Calendar.MONTH)+"/"+ calendar.get(Calendar.YEAR) );	

			int size = m_listParticipantes.size();
			Participante part;
			for(int i = 0;i<size;i++)
			{
				part = (Participante)m_listParticipantes.elementAt(i);
				part.recebeAvisoRelogio();
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no recebe AvisoRelogio");
		}
	
	}


/********************* ProcessaMensagem *************************************/
	public  synchronized ObjetoEnviado ProcessaMensagem(Mensagem msg) throws IOException
	{
		String nome,sMensagem,sMensagemAux;
		
		m_mensagem = msg;
		boolean bOk = false;
		nome = m_mensagem.nome();
		sMensagem = m_mensagem.mensagem();
		sMensagemAux = m_mensagem.mensagemAux();
		
		try{

		
			int index=0,i=0;
			Participante Partic;
			String Parte1,Parte2,Parte3;
			
			Parte1 = Enviador.pegaParte(sMensagemAux,0,',');
			Parte2 = Enviador.pegaParte(sMensagemAux,1,',');
			Parte3 = Enviador.pegaParte(sMensagemAux,2,',');

			Partic = findParticipante(nome);
						
			if(Partic == null)
			     System.out.println("Participante nao existe "+ nome); 
			else 
			     System.out.println("Participante encontrado "+ nome ); 

			//um operador
			if(sMensagem.equalsIgnoreCase("PEGPART"))//j
				return Partic;
			if (sMensagem.equalsIgnoreCase("PEGPARTPOS"))//j
			{
				Integer valor;
				valor = Integer.decode(Parte1);
				System.out.println("valor "+ String.valueOf(valor.intValue()) ); 
				int ivalor = (int)valor.intValue();
				return PegaParticipante(ivalor);
			}	
			if(sMensagem.equalsIgnoreCase("RGPART"))//j
				return RegistraParticipante(nome,sMensagemAux);
			else if(sMensagem.equalsIgnoreCase("LOGIN"))//j
				bOk = LoginParticipante(nome,Parte1);
			if(sMensagem.equalsIgnoreCase("LOGOUT"))//j
				bOk = LogOutParticipante(nome);
			else if(sMensagem.equalsIgnoreCase("REMOVEUSUARIO"))
				bOk = RemoveUsuario(nome,Parte1);
			else if(sMensagem.equalsIgnoreCase("RGPROD"))//j
				return RegistraProduto(nome,sMensagemAux);
			else if(sMensagem.equalsIgnoreCase("RETIRAPROD"))
				bOk = RetiraProduto(nome,Parte1);//j
			else if(sMensagem.equalsIgnoreCase("RegistraProdutoLeilao"))
				return RegistraProdutoLeilao(msg);//j
			else if(sMensagem.equalsIgnoreCase("BUSCAPRODUTOS"))
				return BuscaProdutos(msg);
			else if(sMensagem.equalsIgnoreCase("buscaProdutoIndividual"))
				return buscaProdutoIndividual(msg);	
			else if(sMensagem.equalsIgnoreCase("buscaProdutosNegociados"))
				return buscaProdutosNegociados(msg);	
			else if(sMensagem.equalsIgnoreCase("buscaParticipanteIndividual"))
				return buscaParticipanteIndividual(msg);	
			else if(sMensagem.equalsIgnoreCase("MATAL"))
				bOk = RetiraLeilao(nome,Parte1);
			else if(sMensagem.equalsIgnoreCase("INICIAL"))
				bOk = IniciaLeilao(nome,sMensagemAux);
			else if(sMensagem.equalsIgnoreCase("TRATAL"))
				return TrataLeilaoID(nome,sMensagemAux);
			else if(sMensagem.equalsIgnoreCase("AgenteFechaLeilao"))
				return AgentefechaLeilao(nome,sMensagemAux);
			else if(sMensagem.equalsIgnoreCase("SALVA"))
				bOk = Salva(nome,Parte1);
			else if(sMensagem.equalsIgnoreCase("ABRE"))	
				bOk = Abre(nome,Parte1);
			else if (sMensagem.equalsIgnoreCase("CRIAL"))
				bOk = CriaLeilao(nome,Parte1,Parte2);				
			else if(sMensagem.equalsIgnoreCase("vendedorDesisteLeilao"))
				return vendedorDesisteLeilao(msg);
			else if(sMensagem.equalsIgnoreCase("OFERTA"))
				return ofertaLeilao(msg);
			else if(sMensagem.equalsIgnoreCase("fechaLeilaoAKRM"))
				return fechaLeilaoAKRM(msg);
			else
			{
				System.out.println("\nMensagem n�o reconhecida "+msg.mensagem());			
			}


//			else if(sMensagem.equalsIgnoreCase("PRAZOL"))
//				bOk = setaPrazo(nome,Parte1,Parte2);
//			else if(sMensagem.equalsIgnoreCase("VALORINIC"))
//				bOk = setValorInicial(nome,Parte1,Parte2);
//			else if(sMensagem.equalsIgnoreCase("MENORDIFERENCAOFERTA"))
//				bOk = setMenorDiferencaOferta(nome,Parte1,Parte2);
//			else if(sMensagem.equalsIgnoreCase("VALORDECREMENTO"))
//				bOk = setValorDecremento(nome,Parte1,Parte2);
//			if(bOk == false)
//				System.out.println ("\nErro em Processamento n�o encontrou mensagem:"+sMensagem);
	
		}//try
		catch (Exception e) {
				System.out.println ("\nErro no Processa Mensagem\n");
		}     
		msg.setMensagemRetorno(bOk);
		return msg;
	}//int ProcessaMensagem

}
