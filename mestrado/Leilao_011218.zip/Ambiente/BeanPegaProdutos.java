//import java.io.*;
//import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;


public class BeanPegaProdutos
{
	private Participante m_participante;
	private Produto m_prod;
	private int m_posicao;
	private String nomeUsuario;
	private String nomeProduto;
	private StringBuffer listProdutos = new StringBuffer(500);
	

	public void setNomeUsuario(String u)
	{
		nomeUsuario = u;
	}
	
	public String getNomeUsuario()
	{
		return nomeUsuario;
	}

	public void setNomeProduto(String u)
	{
		nomeProduto = u;
	}
	
	public String getNomeProduto()
	{
		return nomeProduto;
	}

	public void SetPrimeiro()
	{
		m_posicao = 0;
	}
	
	public int PegaProximoProduto()
	{
		m_prod = m_participante.getAtProduto(m_posicao);
		m_posicao++;
		if (m_prod == null)
			return -1;
		return m_posicao;
	}
	public String imprimeProdutosInteressantes()
	{
//		StringBuffer stringBuffer = new StringBuffer();
		try
		{
//			stringBuffer.append("<table width=\"63%\" border=\"2\">");
//			stringBuffer.append("<tr>"); 
//		    stringBuffer.append("<td width=\"21%\" height=\"43\">"); 
//		    stringBuffer.append("<div align=\"left\">Produto</div>");
//		    stringBuffer.append("</td>");
//		    stringBuffer.append("<td width=\"37%\" height=\"43\">Existe Leil�o</td>");
//		    stringBuffer.append("<td width=\"37%\" height=\"43\">Funcionando</td>");
//			stringBuffer.append("</tr>");
		
		}
		catch (Exception e) 
		{
			System.err.println("Erro o imprimeProdutosInteressantes do BeanPegaProdutos Exception:  " + e);
		}
		return listProdutos.toString();
		
	}
	
	public String imprimeProdutosUsuario()
	{
		StringBuffer stringBuffer = new StringBuffer();
		try
		{
			stringBuffer.append("<table width=\"63%\" border=\"2\">");
			stringBuffer.append("<tr>"); 
		    stringBuffer.append("<td width=\"21%\" height=\"43\">"); 
		    stringBuffer.append("<div align=\"left\">Produto</div>");
		    stringBuffer.append("</td>");
		    stringBuffer.append("<td width=\"37%\" height=\"43\">Codigo</td>");
		    stringBuffer.append("<td width=\"37%\" height=\"43\">Funcionando</td>");
			stringBuffer.append("</tr>");
				
			if (m_participante == null)					
				System.out.println("usuario Null");
			else
				System.out.println("achou usuario em imprimeProdutos "+m_participante.nome());
			
			int i=0;
			Produto prod;
			prod = m_participante.getAtProduto(i);
			while ( prod != null)
			{
				stringBuffer.append("<tr>\n");
				stringBuffer.append("<td width=\"21%\" height=\"31\">\n");			
				stringBuffer.append("<div align=\"left\"> <a href=\"/leilao/jsp/ProdutoIndividual.jsp?nomeUsuario="+m_participante.nome()+"&nomeProduto="+prod.nome()+"&codProd="+prod.codigo()+"&trabalhando="+prod.temLeiloeiroRodando()+"\">"+prod.nome()+"</a></div></td>\n");
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+prod.codigo()+"</td>\n");			
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+prod.temLeiloeiroRodando()+"</td>\n");							
				stringBuffer.append("</tr>\n");						
				stringBuffer.append("\n");						
				
				i++;
				prod = m_participante.getAtProduto(i);
			}
			stringBuffer.append("</table>");

		}
		catch (Exception e) 
		{
			System.err.println("Erro o imprimeProdutosUsuario do BeanPegaProdutos Exception:  " + e);
		}

		return stringBuffer.toString();
	}
	

	/***************** processaUsuario() *****************************/
	//retorna o usu�rio
	public boolean processaUsuario()
	{
		System.out.println("Procesando processaUsuario do BeanPegaProdutos");
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(nomeUsuario,Inet.toString());
			//AINDA n�o estou passando o password.
			Msg.setMensagem("PEGPART");
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);
			m_participante = (Participante)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
	
			if (m_participante != null) 
			{
				System.out.println("\nRetornou PEGPART ********* Participante:"+m_participante.nome() );
				return true;
			}
			else
			{
				System.out.println("\nRetornou PEGPART ********* Participante: null" );
				return false;
			}
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanNovoUsuario Exception:  " + e);
		}
		return true;		
	}




	public String imprimeProdutoIndividual()
	{
//		StringBuffer stringBuffer = new StringBuffer();
		try
		{
/*			stringBuffer.append("<div id=\"Layer1\" style=\"position:absolute; width:200px; height:115px; z-index:1; left: 165px; top: 148px\">"); 
			stringBuffer.append("<table width=\"63%\" border=\"2\">");
			stringBuffer.append("<tr>"); 
		    stringBuffer.append("<td width=\"21%\" height=\"43\">"); 
		    stringBuffer.append("<div align=\"left\">Produto</div>");
		    stringBuffer.append("</td>");
		    stringBuffer.append("<td width=\"37%\" height=\"43\">Existe Leil�o</td>");
		    stringBuffer.append("<td width=\"37%\" height=\"43\">Funcionando</td>");
			stringBuffer.append("</tr>");
				
			if (m_participante == null)					
				System.out.println("usuario Null");
			else
				System.out.println("achou usuario em imprimeProdutos "+m_participante.nome());
			
			int i=0;
			Produto prod;
			prod = m_participante.getAtProduto(i);
			while ( prod != null)
			{
				stringBuffer.append("<tr>\n");
				stringBuffer.append("<td width=\"21%\" height=\"31\">\n");			
				stringBuffer.append("<div align=\"left\"> <a href=\"/agile/jsp/ProdutoIndividual.jsp?nomeUsuario="+m_participante.nome()+"&nomeProduto="+prod.nome()+"&temLeiloeiro="+prod.temLeiloeiro()+"&trabalhando="+prod.temLeiloeiroRodando()+"\">"+prod.nome()+"</a></div></td>\n");
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+prod.temLeiloeiro()+"</td>\n");			
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+prod.temLeiloeiroRodando()+"</td>\n");							
				stringBuffer.append("</tr>\n");						
				stringBuffer.append("\n");						
				
				i++;
				prod = m_participante.getAtProduto(i);
			}
			stringBuffer.append("</table>");
			stringBuffer.append("</div>");*/
		}
		catch (Exception e) 
		{
			System.err.println("Erro o imprimeAgentes do BeanPegaAgentes Exception:  " + e);
//			return stringBuffer.toString();
		}


		return listProdutos.toString();
	}


	public String idProduto()
	{
		return "Sem ID";//m_participante.
	
	}
	
	
	
	public boolean processaProdutoIndividual(String idProd)
	{
		System.out.println("Procesando BeanPegaProdutos");
		Mensagem msg,mensagem;
		String stringProduto,stringAtual;
		int i,j;
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			msg = new Mensagem(nomeUsuario,Inet.toString());
			//AINDA n�o estou passando o password.
			
			listProdutos.setLength(0);
			
			msg.setMensagem("buscaProdutoIndividual");
			msg.setMensagemAux(idProd);
			
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,msg);
			mensagem = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
			
			System.out.println("Carac:"+mensagem.printCaracteristicas());
			
			listProdutos.append("<table width=\"63%\" border=\"2\">");
			listProdutos.append("<tr>"); 
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Dono</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Produto</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Codigo</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Detalhes</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Nome Pagina</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Tipo Leil�o</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Menor Diferen�a</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Valor Inicial</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Valor Atual</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">valor Vencedor</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Data Inicio</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Prazo</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Participante Atual</div></td>");

			listProdutos.append("</tr>");

			j=0;
			stringProduto = Enviador.pegaParte(mensagem.mensagemAux(),j,',');
			while (!stringProduto.equals(""))
			{
			
				System.out.println("*************** entrou aqui ***************");
			
				i=1;	stringAtual = Enviador.pegaParte(stringProduto,i,'&');
				String dono = stringAtual;
				String nomeProd;
				i=i+2;	nomeProd = Enviador.pegaParte(stringProduto,i,'&');//nomeProd
				String codProd;
				i=i+2;	codProd = Enviador.pegaParte(stringProduto,i,'&');//nomeProd

				
				listProdutos.append("<tr>\n");
				listProdutos.append("<td width=\"37%\" height=\"31\">"+dono+"</td>\n");//dono							

//				listProdutos.append("<a href=\"/leilao/jsp/Oferta.jsp?dono="+dono+"&nomeProd="+nomeProd+"&codProd="+codProd+"\">"+nomeProd+"</a></td>\n");//nomeProd
				listProdutos.append("<td width=\"37%\" height=\"31\">"+nomeProd+"</td>\n");//nomeProd

				listProdutos.append("<td width=\"37%\" height=\"31\">"+codProd+"</td>\n");//codigo			
				
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//detalhes							
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//nomePagina							
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//TipoLeilao							
				i=i+6; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//Menor Diferen�a							
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//Valor Inicial							
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//Valor Atual							
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//Valor Vencedor							
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//Data Inicio
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//Prazo
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//Participante Atual
				
				
				
				listProdutos.append("</tr>\n");						
				listProdutos.append("\n");						
		
				j++;
				stringProduto = Enviador.pegaParte(mensagem.mensagemAux(),j,',');
			}
			listProdutos.append("</table>");
			if (listProdutos.length() >0) 
			{
				System.out.println("Lista de produtos com valores" );
				return true;
			}
			else
			{
				System.out.println("Lista de produtos vazia" );
				return false;
			}
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanNovoUsuario Exception:  " + e);
		}
		return false;		
		
	}

	public String historicoLeilao(String codProd)
	{
		return "Por enquanto n�o estamos imprimindo o hist�rico do leil�o";
	}
	
	
	/***********************processa()*********************/
	//Retorna uma lista de produtos que o leil�o possui
	public boolean processa()
	{
		System.out.println("Procesando BeanPegaProdutos");
		Mensagem msg,mensagem;
		String stringProduto,stringAtual;
		int i,j;
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			msg = new Mensagem(nomeUsuario,Inet.toString());
			//AINDA n�o estou passando o password.
			
			listProdutos.setLength(0);
			
			msg.setMensagem("BUSCAPRODUTOS");
			msg.setMensagemAux("");
			
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,msg);
			mensagem = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
			
			System.out.println("Carac:"+mensagem.printCaracteristicas());
			
			listProdutos.append("<table width=\"63%\" border=\"2\">");
			listProdutos.append("<tr>"); 
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Dono</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Produto</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Codigo</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Detalhes</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Nome Pagina</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Tipo Leil�o</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Menor Diferen�a</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Valor Inicial</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Valor Atual</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Data Inicio</div></td>");
			listProdutos.append("<td width=\"21%\" height=\"43\">"); 
			listProdutos.append("<div align=\"left\">Participante Atual</div></td>");
			
			listProdutos.append("</tr>");
			
			j=0;
			stringProduto = Enviador.pegaParte(mensagem.mensagemAux(),j,',');
			while (!stringProduto.equals(""))
			{
				
				System.out.println("*******************Passou por aqui processa do BeanPegaProdutos "+String.valueOf(j));
						
				i=1;	stringAtual = Enviador.pegaParte(stringProduto,i,'&');
				String dono = stringAtual;
				String nomeProd;
				i=i+2;	nomeProd = Enviador.pegaParte(stringProduto,i,'&');//nomeProd
				String codProd;
				i=i+2;	codProd = Enviador.pegaParte(stringProduto,i,'&');//nomeProd

				
				listProdutos.append("<tr>\n");
				listProdutos.append("<td width=\"37%\" height=\"31\">"+dono+"</td>\n");//dono							

				listProdutos.append("<td width=\"37%\" height=\"31\">");
				listProdutos.append("<a href=\"/leilao/jsp/Oferta.jsp?dono="+dono+"&nomeProd="+nomeProd+"&codProd="+codProd+"\">"+nomeProd+"</a></td>\n");//nomeProd
//				listProdutos.append("<td width=\"37%\" height=\"31\">"+nomeProd+"</td>\n");//nomeProd

				listProdutos.append("<td width=\"37%\" height=\"31\">"+codProd+"</td>\n");//codigo			
				
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//detalhes							
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//nomePagina							
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//TipoLeilao							
				i=i+6; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//Menor Diferen�a							
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');								
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//Valor Inicial							
				i=i+2; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//Valor Atual							
				i=i+4; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//Data Inicio							
				i=i+4; stringAtual = Enviador.pegaParte(stringProduto,i,'&');				
				listProdutos.append("<td width=\"37%\" height=\"31\">"+stringAtual+"</td>\n");//Participante Atual							
				
				listProdutos.append("</tr>\n");						
				listProdutos.append("\n");						
		
				j++;
				stringProduto = Enviador.pegaParte(mensagem.mensagemAux(),j,',');
			}
			listProdutos.append("</table>");
			if (listProdutos.length() >0) 
			{
				System.out.println("Lista de produtos com valores" );
				return true;
			}
			else
			{
				System.out.println("Lista de produtos vazia" );
				return false;
			}
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanNovoUsuario Exception:  " + e);
		}
		return false;		
		
	}
	
	
	public boolean processaProdutosNegociados()
	{
		System.out.println("Procesando processaUsuario do BeanPegaProdutos");
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(nomeUsuario,Inet.toString());
			//AINDA n�o estou passando o password.
			Msg.setMensagem("PEGPART");
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);
			m_participante = (Participante)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
	
			if (m_participante != null) 
			{
				System.out.println("\nRetornou PEGPART ********* Participante:"+m_participante.nome() );
				return true;
			}
			else
			{
				System.out.println("\nRetornou PEGPART ********* Participante: null" );
				return false;
			}
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanNovoUsuario Exception:  " + e);
		}
		return true;		
		
	}

	public String imprimeProdutosNegociados()
	{
		StringBuffer stringBuffer = new StringBuffer();
		try
		{
			Produto pProduto;
			int i;
//			m_participante.m_listProdutos.size();

			stringBuffer.append("<table width=\"63%\" border=\"2\">");
			stringBuffer.append("<tr>"); 
		    stringBuffer.append("<td width=\"37%\" height=\"43\">Codigo</td>");
		    stringBuffer.append("<td width=\"37%\" height=\"43\">Nome</td>");
		    stringBuffer.append("<td width=\"37%\" height=\"43\">Dono</td>");			
		    stringBuffer.append("<td width=\"37%\" height=\"43\">Estado</td>");
			stringBuffer.append("</tr>");

			if (m_participante == null)					
				System.out.println("*********************usuario Null");
			else
				System.out.println("achou usuario em imprimeProdutosNegociados "+m_participante.nome());
			
			
			
//			m_listProdutosComprados			
			for(i=0;i<m_participante.m_listProdutosComprados.size();i++)
			{
				pProduto = (Produto)m_participante.m_listProdutosComprados.elementAt(i);
				
				stringBuffer.append("<tr>\n");
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+pProduto.codigo()+"</td>\n");			
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+pProduto.nome()+"</td>\n");							
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+pProduto.dono().nome()+"</td>\n");											

				if(pProduto.confirmacaoCompra() == true)
					stringBuffer.append("<td width=\"37%\" height=\"31\">Comprado</td>\n");							
				else	
					stringBuffer.append("<td width=\"37%\" height=\"31\"><div align=\"left\"> <a href=\"/leilao/jsp/ConfirmaCompra.jsp?nomeUsuario="+m_participante.nome()+"&nomeProduto="+pProduto.nome()+"&codProd="+pProduto.codigo()+"\">N�o comprado</a></div></td>\n");
				
				stringBuffer.append("</tr>\n");						
				stringBuffer.append("\n");						
				
			
			}
			

//			m_listProdutosOferta
			for( i=0;i<m_participante.m_listProdutosOferta.size();i++)
			{
				pProduto = (Produto)m_participante.m_listProdutosOferta.elementAt(i);
				
				stringBuffer.append("<tr>\n");
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+pProduto.codigo()+"</td>\n");			
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+pProduto.nome()+"</td>\n");							
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+pProduto.dono().nome()+"</td>\n");											

				Leiloeiro l = pProduto.leiloeiro();
				if(l==null ||  !l.rodando())
					continue;

				if(l.participanteAtual() == m_participante)
					stringBuffer.append("<td width=\"37%\" height=\"31\">Estou Vencendo</td>\n");							
				else
					stringBuffer.append("<td width=\"37%\" height=\"31\">Estou Perdendo</td>\n");								

				stringBuffer.append("</tr>\n");						
				stringBuffer.append("\n");						
					
			}

			//m_listProdutosVendidos			
			for( i=0;i<m_participante.m_listProdutosVendidos.size();i++)
			{
				pProduto = (Produto)m_participante.m_listProdutosVendidos.elementAt(i);
				
				stringBuffer.append("<tr>\n");
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+pProduto.codigo()+"</td>\n");			
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+pProduto.nome()+"</td>\n");							
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+pProduto.dono().nome()+"</td>\n");											

				if(pProduto.confirmacaoVenda() == true)
					stringBuffer.append("<td width=\"37%\" height=\"31\">Vendido</td>\n");							
				else	
					stringBuffer.append("<td width=\"37%\" height=\"31\"><div align=\"left\"> <a href=\"/leilao/jsp/ConfirmaCompra.jsp?nomeUsuario="+m_participante.nome()+"&nomeProduto="+pProduto.nome()+"&codProd="+pProduto.codigo()+"\">N�o Vendido</a></div></td>\n");

				stringBuffer.append("</tr>\n");						
				stringBuffer.append("\n");						
			}
		
			
			stringBuffer.append("</table>");

		}
		catch (Exception e) 
		{
			System.err.println("Erro o imprimeProdutosUsuario do BeanPegaProdutos Exception:  " + e);
		}

		return stringBuffer.toString();
	}
	

	
}



