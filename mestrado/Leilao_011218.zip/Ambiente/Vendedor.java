import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
/*
public class Vendedor extends Participante
{
	
	public Vendedor (String Nome) 
	{
//		super(Nome,"Vendedor");
		m_Nome = Nome;
		m_TipoParticipante = "Vendedor";

	}


	public void Init()
	{
	}
	

}
*/
