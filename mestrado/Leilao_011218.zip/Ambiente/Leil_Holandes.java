import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;

final public class Leil_Holandes extends Leiloeiro
{

//	int m_itempoDecremento,m_iTempoIntermediario;
//	int m_imenorValor;
	boolean m_bAvisoRelogio;

	/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
	
//			out.writeInt(m_itempoDecremento);
//			out.writeInt(m_iTempoIntermediario);
//			out.writeInt(m_imenorValor);
			out.writeBoolean(m_bAvisoRelogio);
			out.flush();
		}	
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do Leil_Holandes" );
		}			
	}
	
/****************************** readObject **********************************/		
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
//			m_itempoDecremento = in.readInt();
//			m_iTempoIntermediario = in.readInt();
//			m_imenorValor = in.readInt();
			m_bAvisoRelogio =  in.readBoolean();
		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read do Leil_Holandes" );
		 }
	 }


	public Leil_Holandes(Produto p)
	{
		super(p);
		m_tipo = "Holandes";
//		setMenorDiferencaOferta(10);
		vetorCaracteristica.setValorCarac("menorDiferenca","10");
		m_bAvisoRelogio = false;
//		m_imenorValor = 0;
	}


	public void setValorInicial(double iValor)
	{
		m_iValorInicial = m_iValorAtual = m_iValorVencedor = iValor;
//		System.out.print("Valor inicial  para o produto "+m_Produto.nome() + " = "+ String.valueOf(m_iValorVencedor));
	}


//	public void setmenorValor(int iValor)
//	{
//		m_imenorValor = iValor;
//		System.out.print("Menor valor para o produto "+m_Produto.nome() + " = "+String.valueOf(m_ivalorDecremento));
//	}
//
//	public int menorValor()
//	{
//		return m_imenorValor;
//	}

//	public void setTempoDecremento(int iValor)
//	{
//		m_itempoDecremento = iValor;
//		System.out.print("Tempo de decremento do valor = "+String.valueOf(m_itempoDecremento));
//
//	}
//	public int tempoDecremento()
//	{
//		return m_itempoDecremento;
//	}
	private boolean decrementaValor()
	{
//		System.out.println("Entrou no DecrementaValor "+ String.valueOf(m_ivalorDecremento));
		m_iValorAtual -= menorDiferencaOferta();

		Double valor = Double.valueOf(vetorCaracteristica.getValorCarac("ValorReserva"));
		double valorReserva = (double)valor.doubleValue();
		
		if (m_iValorAtual <= valorReserva || participanteAtual()!=null)//se chegou ao limite ou algu�m efetuou oferta.
		{
		    fechaLeilao();
			return false;
		}
		return true;
	}

	public String printCaracteristicas()
	{
		StringBuffer buffer = new StringBuffer();
		try
		{
			buffer.append(produto().nome());
			buffer.append(tipo());
			buffer.append(String.valueOf(prazo()));
			buffer.append(String.valueOf(valorInicial()));
//			buffer.append(String.valueOf(valorDecremento()));
//			buffer.append(String.valueOf(tempoDecremento()));
			
			
		
		}
		catch (Exception e)
		{
			System.err.println("erro no print caracteristicas do Leil_Holandes "+ e);
		}
		return buffer.toString();
	}

	public boolean AnalisaRestricoes(Participante pPartic,double Valor)
	{
//		if( (Valor - m_iValorVencedor) < 5)
//		{
//			System.out.println("Valor entre ofertas muito pequeno");
//		}
		return true;
	}


/********************* recebeOferta ****************************************/
//chamado pelo processador la de fora
	public synchronized String recebeOferta(Participante pPartic,double iValor)
	{
		try
		{
			if(pPartic == null)
				System.out.println("Erro");
			m_ParticipanteAtual = pPartic;
			m_iValorAtual = iValor;
		//			processaOferta();
			if(findParticipante(pPartic.nome())== null)
				listOfertantes.addElement(pPartic);

			notifyAll();
		}
		catch(Exception e)
		{
			System.err.println("Erro no Recebe Oferta do Leilao Ingles"+ e);		
		}
		return pPartic.nome();
	}

/********************* processaOferta ****************************************/
//chamado pelo run
	public synchronized void processaOferta()
	{
		//por enquato so pega esse valor e joga como o maior valor.

		m_ParticipanteVencedor = m_ParticipanteAtual;
		fechaLeilao();
	}

	public synchronized void recebeAvisoRelogio()
	{
		try
		{
			if(m_bRodando)
			{
				System.out.println(m_Produto.codigo()+" "+m_Produto.nome() +" avisado. Holandes  MenorValor:"+vetorCaracteristica.getValorCarac("ValorReserva") +" V.Atual:" + String.valueOf(m_iValorAtual));
				if(!this.decrementaValor())
					m_bRodando = false;

/*				if(m_bMensagem)
				{
					System.out.println("Leiloeiro recebeu mensagem "+ m_Produto.nome());

					processaOferta();
					m_bMensagem = false;
					System.out.println("Leiloeiro terminou de processar ");
				}
				else
				{
						System.out.println("Leiloeiro recebeu ordem de parar de rodar ");
				}
*/
			}
			else
			{
				String nomeAtual = m_ParticipanteAtual.nome();
				System.out.println(produto().codigo()+" "+produto().nome() + " avisado. Holand�s. Fechado. V.Inic:"+valorInicial()+" V.Venc:" + String.valueOf(m_iValorAtual)+" Vencedor:"+nomeAtual);				
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no recebe AvisoRelogio");
		}
		
	}

	

/********************* run ****************************************
	public synchronized void run()
	{
		System.out.println("Leil_Holandes comecou a rodar"+ m_Produto.nome());
		
		//inicia a roda e starta o relogio
//		this.SetRodando(true);
		
//		recebeAvisoRelogio();
	
/*		while(m_bRodando && !m_bMensagem && !m_bAvisoRelogio)
		{

			System.out.println("\n\n\nLeil_Holandes Indo para o wait");
			try{
				wait();
			}
			catch (InterruptedException ex) {return;}
			System.out.println("Leiloeiro saiu do wait "+ m_Produto.nome());
				
			if(m_bMensagem)
			{
				System.out.println("Leiloeiro recebeu mensagem "+ m_Produto.nome());

				processaOferta();
				m_bMensagem = false;
				System.out.println("Leiloeiro terminou de processar ");
			}
			else if(m_bAvisoRelogio )
			{
				System.out.println("Fui avisado faltam " + String.valueOf(m_Relogio.getPrazo()) + "0 segundos");

				this.decrementaValor();
				m_bAvisoRelogio = false;
			}
			else
			{
					System.out.println("Leiloeiro recebeu ordem de parar de rodar ");
			}

*/		
//	}
}
