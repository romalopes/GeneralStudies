//import java.io.*;
//import java.util.*;
import java.net.*;

import ClassesGeral.ObjetoEnviado;
import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

public class BeanNovoUsuario	
{
	private String nomeUsuario;
	private String passWord;
	private String Email;

	public void setNomeUsuario(String u)
	{
		nomeUsuario = u;
	}
	
	public String getNomeUsuario()
	{
		return nomeUsuario;
	}
	public void setPassWord(String p)
	{
		passWord = p;
	}
	
	public String getPassWord()
	{
		return passWord;
	}
	
	public void setEmail(String e)
	{
		Email = e;
	}
	
	public String getEmail()
	{
		return Email;
	}
		
	public boolean processa() throws Exception 
	{
		Mensagem Msg = new Mensagem("FALHA","");
		try
		{
			System.out.println("Procesando BeanNovoUsuario");
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(nomeUsuario,Inet.toString());
			//AINDA n�o estou passando o password.
			Msg.setMensagem("RGPART");
			Msg.setMensagemAux(passWord+","+Email);
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);
			Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
		
			String valor = Msg.mensagemAux();
			System.out.println("\nRetornou do Cria Usuario *********"+valor);
			if((valor != null) && valor.equalsIgnoreCase("OK"))
				return true;
			else	
				return false;
			

		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanNovoUsuario Exception:  " + e);
		}
		return true;		
	}
}
