import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;


import ClassesGeral.ObjetoEnviado;

public class Participante extends ObjetoEnviado implements Serializable
{
	String m_senha,m_email;	
	int m_numeroEstrelasCompraNeg;//as destrelas v�o de 1 a 5.  0 significa que o participante ainda n�o fechou nada
	int m_numeroEstrelasCompraPos;//as destrelas v�o de 1 a 5.  0 significa que o participante ainda n�o fechou nada	
	int m_numeroEstrelasVendaNeg;//as destrelas v�o de 1 a 5.  0 significa que o participante ainda n�o fechou nada
	int m_numeroEstrelasVendaPos;//as destrelas v�o de 1 a 5.  0 significa que o participante ainda n�o fechou nada	
	
		
	Vector m_listProdutos;
	public Vector m_listProdutosVendidos;
	public Vector m_listProdutosComprados;
	public Vector m_listProdutosOferta;
	String m_Mensagem;


	/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
			out.writeObject(m_senha);
			out.writeObject(m_email);
			out.writeInt(m_numeroEstrelasCompraNeg);
			out.writeInt(m_numeroEstrelasCompraPos);			
			out.writeInt(m_numeroEstrelasVendaNeg);			
			out.writeInt(m_numeroEstrelasCompraPos);			
			
			out.writeInt(m_listProdutos.size());
			for(int i=0;i<m_listProdutos.size();i++)
			{
				out.writeObject(m_listProdutos.elementAt(i));
			}
			out.writeInt(m_listProdutosOferta.size());
			for(int i=0;i<m_listProdutosOferta.size();i++)
			{
				out.writeObject(m_listProdutosOferta.elementAt(i));
			}
			out.writeInt(m_listProdutosVendidos.size());
			for(int i=0;i<m_listProdutosVendidos.size();i++)
			{
				out.writeObject(m_listProdutosVendidos.elementAt(i));
			}			

			out.writeInt(m_listProdutosComprados.size());
			for(int i=0;i<m_listProdutosComprados.size();i++)
			{
				out.writeObject(m_listProdutosComprados.elementAt(i));
			}			
					
			out.writeObject(m_Mensagem);
			
			out.flush();
		}	
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do Participante" );
		}			
	}
	
/****************************** readObject **********************************/		
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{

			m_listProdutos = new Vector();
			m_listProdutosOferta  = new Vector();
			m_listProdutosVendidos = new Vector();
			m_listProdutosComprados = new Vector();
			m_senha = (String)in.readObject();
			m_email = (String)in.readObject();			
			m_numeroEstrelasCompraNeg = in.readInt();
			m_numeroEstrelasCompraPos = in.readInt();			
			m_numeroEstrelasVendaNeg = in.readInt();
			m_numeroEstrelasVendaPos = in.readInt();			
						
			
			int NumProdutos = in.readInt();
			for(int i=0;i<NumProdutos;i++)
			{
				addProduto((Produto)in.readObject());
			}
			NumProdutos = in.readInt();
			for(int i=0;i<NumProdutos;i++)
			{
				m_listProdutosOferta.addElement((Produto)in.readObject());
			}
			NumProdutos = in.readInt();
			for(int i=0;i<NumProdutos;i++)
			{
				m_listProdutosVendidos.addElement((Produto)in.readObject());
			}			

			NumProdutos = in.readInt();
			for(int i=0;i<NumProdutos;i++)
			{
				m_listProdutosComprados.addElement((Produto)in.readObject());
			}						
						
			m_Mensagem = (String)in.readObject();
			
		 }
		 catch(IOException e)
		 {
		 	System.out.println(e+" Erro no read do Participante" );
		 }
	 }


	public Participante (String nome) 
	{ 
		super(nome);
		
		m_numeroEstrelasCompraNeg =0;//as destrelas v�o de 1 a 5.  0 significa que o participante ainda n�o fechou nada
		m_numeroEstrelasCompraPos=0;//as destrelas v�o de 1 a 5.  0 significa que o participante ainda n�o fechou nada	
		m_numeroEstrelasVendaNeg=0;//as destrelas v�o de 1 a 5.  0 significa que o participante ainda n�o fechou nada
		m_numeroEstrelasVendaPos=0;//as destrelas v�o de 1 a 5.  0 significa que o participante ainda n�o fechou nada	

		m_email = "";
		m_senha = "";
		m_listProdutos = new Vector();
		m_listProdutosOferta = new Vector();
		m_listProdutosVendidos = new Vector();
		m_listProdutosComprados = new Vector();
	}

/********************* FindProduto ****************************************/
	public Produto findProduto(String nome)
	{
		Produto p;
		for(int i=0;i<m_listProdutos.size();i++)
		{
			p = (Produto)m_listProdutos.elementAt(i);
			if(p.nome().equalsIgnoreCase(nome))
				   return p;
		}
		return null;
	}
	
	
/********************* findProdutoID ****************************************/
	public Produto findProdutoID(String codigo)
	{
		Produto p;
		for(int i=0;i<m_listProdutos.size();i++)
		{
			p = (Produto)m_listProdutos.elementAt(i);
			if(p.codigo().equalsIgnoreCase(codigo))
				   return p;
		}
		return null;
	}

	
/********************* FindProdutoVendido ****************************************/
	public Produto findProdutoVendido(String nome)
	{
		Produto p;
		for(int i=0;i<m_listProdutosVendidos.size();i++)
		{
			p = (Produto)m_listProdutosVendidos.elementAt(i);
			if(p.nome().equalsIgnoreCase(nome))
				   return p;
		}
		return null;
	}	

/********************* FindProdutoVendidoID ****************************************/	
	public Produto findProdutoVendidoID(String codigo)
	{
		Produto p;
		for(int i=0;i<m_listProdutosVendidos.size();i++)
		{
			p = (Produto)m_listProdutosVendidos.elementAt(i);
			if(p.codigo().equalsIgnoreCase(codigo))
				   return p;
		}
		return null;
	}	

/********************* findProdutoComprado ****************************************/
	public Produto findProdutoComprado(String nome)
	{
		Produto p;
		for(int i=0;i<m_listProdutosComprados.size();i++)
		{
			p = (Produto)m_listProdutosComprados.elementAt(i);
			if(p.nome().equalsIgnoreCase(nome))
				   return p;
		}
		return null;
	}	

/********************* findProdutoCompradoID ****************************************/	
	public Produto findProdutoCompradoID(String codigo)
	{
		Produto p;
		for(int i=0;i<m_listProdutosComprados.size();i++)
		{
			p = (Produto)m_listProdutosComprados.elementAt(i);
			if(p.codigo().equalsIgnoreCase(codigo))
				   return p;
		}
		return null;
	}	
	
		
/********************* findProdutoOfertaID ****************************************/	
	public Produto findProdutoOfertaID(String codigo)
	{
		Produto p;
		for(int i=0;i<m_listProdutosOferta.size();i++)
		{
			p = (Produto)m_listProdutosOferta.elementAt(i);
			if(p.codigo().equalsIgnoreCase(codigo))
				   return p;
		}
		return null;
	}			
		
/********************* Finalize() ****************************************/	
	protected void Finalize()
	{
		
	}
	public String senha() 
	{
		return m_senha;	
	}
	public void setSenha(String s)
	{
		m_senha = s;	
	}
	
	public String email() 
	{
		return m_email;	
	}
	public void setEmail(String e)
	{
		m_email = e;	
	}
	
	public int numeroEstrelas() 
	{
		int numEstrelas=0;
		if (m_numeroEstrelasCompraNeg > 0)
		{
			if ((m_numeroEstrelasCompraNeg - m_numeroEstrelasCompraPos)==0)
			{
				numEstrelas = 5;
			}
			else	
				if ((m_numeroEstrelasCompraNeg - m_numeroEstrelasCompraPos)>0 &&
					(m_numeroEstrelasCompraNeg - m_numeroEstrelasCompraPos)<3)
					numEstrelas = 4;
				else	
					if ((m_numeroEstrelasCompraNeg - m_numeroEstrelasCompraPos)>2)
						numEstrelas = 3;
		}
		if ((m_numeroEstrelasCompraNeg - m_numeroEstrelasCompraPos)>0 )
			numEstrelas = -2;
	
		return numEstrelas;//m_numeroEstrelas;	
	}
//	public void setNumeroEstrelas(int e)
//	{
//		m_numeroEstrelas = e;	
//	}


	public void setConfirmacaoCompra(String codigo)
	{
		try
		{
			Produto pProd = findProdutoCompradoID(codigo);
			if (pProd != null)
			{
				pProd.setConfirmacaoCompra(true);			
				m_numeroEstrelasCompraPos++;				
			}
		
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no confirmacaoCompra do Participante "+nome());
		}
	
	}

	public void setConfirmacaoVenda(String codigo)
	{
		try
		{
			Produto pProd = findProdutoVendidoID(codigo);
			if (pProd != null)
			{
				pProd.setConfirmacaoVenda(true);			
				m_numeroEstrelasVendaPos++;
			}
		
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no confirmacaoCompra do Participante "+nome());
		}
	
	}
		

	public void addProduto(Produto pProduto)
	{
		m_listProdutos.addElement(pProduto);
	}
	public void addProdutoVendido(Produto pProduto)
	{
		m_listProdutosVendidos.addElement(pProduto);
	}
	public void addProdutoComprado(Produto pProduto)
	{
		m_listProdutosComprados.addElement(pProduto);
	}


	public void addProdutoOferta(Produto pProduto)
	{
		if(findProdutoOfertaID(pProduto.codigo()) == null)
			m_listProdutosOferta.addElement(pProduto);
	}

			
	
	public void vendeuProduto(String codigo)
	{
		Produto prod = findProdutoID(codigo);
		if(prod == null)
			return;
			
		retiraProduto(prod);
		
		if (findProdutoVendidoID(codigo) == null)
		{
			addProdutoVendido(prod);
			prod.fazVendido();
		}
				
		m_numeroEstrelasVendaNeg--;
	}
	
	public void comprouProduto(String codigo)
	{
		Produto prod = findProdutoOfertaID(codigo);
		if(prod == null)
			return;
			
		retiraProdutoOferta(prod);
		
		addProdutoComprado(prod);
		
		m_numeroEstrelasCompraNeg--;
	}
	


	public void retiraProduto(Produto pProduto)
	{
		Produto p;
		for(int i=0;i<m_listProdutos.size();i++)
		{
			p = (Produto)m_listProdutos.elementAt(i);
			if(p == pProduto)
			{
				m_listProdutos.removeElementAt(i);
				return;
			}
		}
		System.out.println("Nao foi possivel retirar o Produto "+ pProduto.nome() + " do "+ nome());
	}
	
	
	public void retiraProdutoOferta(Produto pProduto)
	{
		Produto p;
		for(int i=0;i<m_listProdutosOferta.size();i++)
		{
			p = (Produto)m_listProdutosOferta.elementAt(i);
			if(p == pProduto)
			{
				m_listProdutosOferta.removeElementAt(i);
				return;
			}
		}
		System.out.println("Nao foi possivel retirar o Produto da lista de Ofertas"+ pProduto.nome() + " do "+ nome());
	}

	public synchronized void recebeAvisoRelogio()
	{
		try
		{
			//Escrever a Data.
			int size = m_listProdutos.size();
			Produto prod;
			for(int i = 0;i<size;i++)
			{
				prod = (Produto)m_listProdutos.elementAt(i);
				prod.recebeAvisoRelogio();
			}
			size = m_listProdutosVendidos.size();
			for(int i = 0;i<size;i++)
			{
				prod = (Produto)m_listProdutosVendidos.elementAt(i);
				prod.recebeAvisoRelogio();
			}
			
			size = m_listProdutosComprados.size();
			for(int i = 0;i<size;i++)
			{
				prod = (Produto)m_listProdutosComprados.elementAt(i);
				prod.recebeAvisoRelogio();
			}

			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no recebe AvisoRelogio");
		}
		
		
	}

	public Produto getAtProduto(int i)
	{
		if (i< m_listProdutos.size())
		{
			return (Produto)m_listProdutos.elementAt(i);
		}	
		 return null;	
	}


	public boolean isDono(String nome)
	{
		Produto p;
		p = findProduto(nome);
		if(p != null)
			return true;
		return false;
	}
	public boolean isDonoID(String codigo)
	{
		Produto p;
		p = findProdutoID(codigo);
		if(p != null)
			return true;
		return false;
	}
	
	



//	public String TipoParticipante() {
//		return m_TipoParticipante;
//	}

	public void Init()
	{
	}
	

}
