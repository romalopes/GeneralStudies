import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;

import ClassesGeral.Enviador;
import ClassesGeral.Mensagem;
import ClassesGeral.VetorCaracteristica;
import ClassesGeral.Caracteristica;

abstract public class Leiloeiro extends Thread implements Serializable
{

	String m_tipo;
	Produto m_Produto;
	public boolean m_bRodando;
	boolean m_bMensagem;
//	int m_prazo;
	double m_ivalorReserva;
	Participante m_ParticipanteAtual,m_ParticipanteVencedor;
	double m_iValorInicial, m_iValorAtual, m_iValorVencedor,m_iMenorDiferencaOferta;
	private GregorianCalendar m_dataInicio;
	

	public Vector listOfertantes;	
	public VetorCaracteristica vetorCaracteristica;

//metodos que abstratos....	
	abstract public boolean AnalisaRestricoes(Participante pPartic,double Valor);
	abstract public  void processaOferta();
	abstract public  void recebeAvisoRelogio();
	abstract public  String recebeOferta(Participante pPartic,double iValor);

	//depois vejo se faco cast pra chamar ou deixo assim....
//	abstract public void setMenorDiferencaOferta(int iValor);
//	abstract public void setValorDecremento(int iValor);
//	abstract public void setTempoDecremento(int iValor);


	/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
			out.writeObject(m_tipo);
			out.writeObject(m_Produto);
			out.writeBoolean(m_bRodando);
			out.writeBoolean(m_bMensagem);
//			out.writeInt(m_prazo);
			out.writeDouble(m_ivalorReserva);
			out.writeObject(m_ParticipanteAtual);
			out.writeObject(m_ParticipanteVencedor);
			out.writeDouble(m_iValorInicial);			
			out.writeDouble(m_iValorAtual);
			out.writeDouble(m_iValorVencedor);
			out.writeDouble(m_iMenorDiferencaOferta);
			out.writeObject(m_dataInicio);

		
			out.writeInt(listOfertantes.size());
			for(int i=0;i<listOfertantes.size();i++)
			{
				out.writeObject(listOfertantes.elementAt(i));
			}
			out.writeInt(vetorCaracteristica.size());
			for(int i=0;i<vetorCaracteristica.size();i++)
			{
				out.writeObject(vetorCaracteristica.elementAt(i));
			}			
			
			out.flush();
		}	
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do Leiloeiro" );
		}			
	}
	
/****************************** readObject **********************************/		
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_tipo = (String)in.readObject();
			m_Produto = (Produto)in.readObject();			
			m_bRodando = in.readBoolean();			
			m_bMensagem = in.readBoolean();			
//			m_prazo = in.readInt();
			m_ivalorReserva = in.readDouble();
			m_ParticipanteAtual = (Participante)in.readObject();
			m_ParticipanteVencedor = (Participante)in.readObject();
			m_iValorInicial = in.readDouble();
			m_iValorAtual = in.readDouble();
			m_iValorVencedor = in.readDouble();
			m_iMenorDiferencaOferta = in.readDouble();
			m_dataInicio = (GregorianCalendar)in.readObject();
			
			listOfertantes = new Vector();
			int size = in.readInt();
			for(int i=0;i<size;i++)
				listOfertantes.addElement(in.readObject());

			vetorCaracteristica = new VetorCaracteristica();
			 size = in.readInt();
			for(int i=0;i<size;i++)
				vetorCaracteristica.addElement(in.readObject());			
				
		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read do Leileiloeiro" );
		 }
	 }
	 public Leiloeiro(Produto p)
	 {
	 	listOfertantes = new Vector();
		vetorCaracteristica = new VetorCaracteristica();
	 	m_bRodando = false;
	 	m_bMensagem = false;
	 	m_Produto = p;
	 	m_ParticipanteVencedor = m_ParticipanteAtual = null;
	 	m_iValorAtual = 0;
		
	 	GregorianCalendar calendar = new GregorianCalendar();
	 	setData(calendar);
	 	String s = Enviador.getStringData(data());//calendar.get(Calendar.MINUTE)+","+calendar.get(Calendar.HOUR_OF_DAY)+","+calendar.get(Calendar.DAY_OF_YEAR)+","+calendar.get(Calendar.YEAR);
	 	vetorCaracteristica.setValorCarac("dataInicio",s);
		
		
//		String a = "nomeProduto&carro&detalhes&Carro Bom pra Caramba&tipoLeilao&Ingles&prazo&7&valorInicial&10&menordiferenca&10&bValorReserva&false";
//		vetorCaracteristica.setCaracteristicas(a);
	 }

	
	public Participante findParticipante(String nome)
	{
		Participante p = null;
		try
		{
			for(int i=0;i<listOfertantes.size();i++)
			{
				p = (Participante)listOfertantes.elementAt(i);
				if(p.nome().equalsIgnoreCase(nome))
					return p;
			}
		}
		catch(Exception e)
		{
			System.err.println("Erro no find Participante do Leiloeiro"+e);
		}
		return null;
	}
	
//	public void setMenorDiferencaOferta(int iValor)
//	{
//		m_iMenorDiferencaOferta = iValor;
//	}
	
	public double menorDiferencaOferta()
	{
		double menordiferenca;
		try
		{
			menordiferenca = vetorCaracteristica.getValorCaracDouble("menorDiferenca");
		}
		catch(Exception e)
		{
			return 0;
		}
		return menordiferenca;
	}
	
	
	public String retornaListParticipantes()
	{
		StringBuffer buffer = new StringBuffer();
		Participante p;
		for(int i=0;i<listOfertantes.size();i++)
		{
			p = (Participante)listOfertantes.elementAt(i);
			buffer.append(p.nome());
			buffer.append(",");
		}
		return buffer.toString();
	}
	 public void setValorInicial(String sValor)
	 {
	 	if(sValor == null)
			sValor = "0";
		 Double valor = new Double(Double.parseDouble(sValor));
		 double iValor = (double)valor.doubleValue();
	 		 
	 	m_iValorInicial = m_iValorAtual = m_iValorVencedor = iValor;
		
	 }
	  
	 public double valorInicial()
	 {
	 	return m_iValorInicial;
	 }
	 
 	public void setValorReserva(String sValor)
 	{
	 	Double valor = new Double(Double.parseDouble(sValor));
	 	double iValor = (double)valor.doubleValue();
	 			 
 		m_ivalorReserva = iValor;
 	
 	}

 	public void setData(GregorianCalendar d)
 	{
 		m_dataInicio = d;
 	}
 	public GregorianCalendar data()
 	{
 		return m_dataInicio;
 	}
	
	public double valorReserva()
	{
		return m_ivalorReserva;
	}
		
		
	 public void setValorAtual(double iValor)
	 {
		m_iValorAtual = iValor;	 	
	 }
	 public double valorAtual()
	 {
	 	return m_iValorAtual;
	 }
	 public void setValorVencedor(double iValor)
	 {
	 	m_iValorVencedor = iValor;
	 }
	 public double valorVencedor()
	 {
	 	return m_iValorVencedor;
	 }
	public Produto produto()
	{
		return m_Produto;
	}
	
	protected synchronized void setRodando(boolean r)
	{
		m_bRodando = r;
	}
	
	public synchronized boolean rodando()
	{
		return m_bRodando;
	}
	public String prazo()
	{
		return vetorCaracteristica.getValorCarac("prazo");;
				
	}
	public String tipo()
	{
		return m_tipo;
	}

	public String printCaracteristicas()
	{
		return "";
	}

/********************* fechaLeilao ********************************/
	public synchronized void fechaLeilao()
	{
		try
		{
		
			System.out.println("\nFechando o leilao");
			this.setRodando(false);//n�o precisa dessa linha
			m_bMensagem = false;

			if(produto() == null)
				return;
			System.out.println("\nTerminou de fechar o leilao de:"+produto().nome());
			if(m_ParticipanteAtual != null)
			{
				System.out.println("O vencedor foi " +m_ParticipanteAtual.nome());
				System.out.println("E comprou o produto pelo valor  " +String.valueOf(m_iValorAtual));
			}
			else
			{
				System.out.println("Nao houve ofertas...  O Produto continua com o mesmo dono...");
			}
//////////////////////////////
			//primeiro avisa aos agentes que a oferta foi realizada		
			Mensagem msg = new Mensagem("do Leiloeiro","");
			msg.setOrigem("site");
			msg.setDestino(retornaListParticipantes()+this.produto().dono().nome());
			System.out.println("Destino:"+retornaListParticipantes());
			msg.setReply(true);
			msg.setTipo("Agente");
			msg.setMensagem("recebeReplyFechaLeilaoAKRM");			
			//NomeUsuario,IDProd,ValorOferta.
			String nome="",email="";
			if (m_ParticipanteAtual!= null)
			{
				nome = m_ParticipanteAtual.nome();
				email = m_ParticipanteAtual.email();
			}	
			String stringAux = 	produto().codigo()+","+nome+","+email+","+String.valueOf(valorAtual());
			
			System.out.println(stringAux);
			msg.setMensagemAux(stringAux);
			
			m_ParticipanteVencedor = m_ParticipanteAtual;

			msg.setMensagemRetorno(true);
			//processador envia diretamente uma mensagem para os agentes, informando uma oferta.
			Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,msg);
//////////////////////////////			
			
			//faz indica que os dois fecharam a negocia��o, mas ainda n�o confimaram a transa��o.
			produto().dono().vendeuProduto(produto().codigo());
			m_ParticipanteAtual.comprouProduto(produto().codigo());
			
			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no fechaLeilao do Leiloeiro");
		}

	}
	public String printParticipanteAtual()
	{
		if(m_ParticipanteAtual != null)
			return m_ParticipanteAtual.nome();
		return " ";	
	}
	public Participante participanteAtual()
	{
		return m_ParticipanteAtual;
	}
	
	public synchronized void run()
	{
		System.out.println("Leiloeiro comecou a rodar"+ produto().nome());
		//inicia a roda e starta o relogio
		this.setRodando(true);
		
	}
	public void Init(){}
}

