import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
/*
public class Comprador extends Participante
{
	public Comprador (String Nome)
	{ 
//		super(Nome,"Comprador");
		m_Nome = Nome;
		m_TipoParticipante = "Comprador";
	}

	public void Init()
	{
	}
	
}
*/
