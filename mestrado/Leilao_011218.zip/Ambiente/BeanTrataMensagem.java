//import java.io.*;
//import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

public class BeanTrataMensagem extends BeanGeral
{
	private String valor = "";
	private String mensagem = "";	
	private String mensagemAux = "";
	

	public void setMensagem(String m)
	{
		mensagem = m;
	}
	public String getMensagem()
	{
		return mensagem;
	}

	public void setMensagemAux(String m)
	{
		mensagemAux = m;
	}
	public String getMensagemAux()
	{
		return mensagemAux;
	}
	
	public boolean processa()
	{
		System.out.println("Procesando BeanTrataMensagem:" + mensagem);
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(getNomeUsuario(),Inet.toString());
			//AINDA n�o estou passando o password.
			Msg.setMensagem(mensagem);
			Msg.setMensagemAux(mensagemAux);
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);
			Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteProcessador);			
		
			
			String valor = Msg.mensagemAux();
			System.out.println("\nRetornou "+mensagem+" *********" + mensagemAux);
			if ((valor != null) && (valor.equals("OK")))
				return true;
			else
				return false;
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanNovoUsuario Exception:  " + e);
		}
		return true;		
		
	}
}
