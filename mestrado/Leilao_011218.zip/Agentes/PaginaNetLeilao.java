/**classe P�ginas indica a p�gina que vamos entrar**/
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;


import ClassesGeral.Enviador;
import ClassesGeral.Mensagem;

public class PaginaNetLeilao extends Pagina
{

	public PaginaNetLeilao(Agente ag) throws Exception 
	{
		super(ag);
		m_nome = "NETLEILAO";
		m_base = "http://www.netleilao.com/";
		m_biniciaBusca = false;
	}
	public void buscaProdutoIndividual(String CodProd)
	{
	
	}
	public void registraLeilao()
	{
		int i;
		i = agente().estagio()+1;
		agente().setEstagio(i);
	};
	public int tempoRestante(Item it)
	{
		return 0;
	}
	public int tempoRodando(Item it)
	{
		return 0;
	}
	public int prazo(Item it)
	{
		return 0;
	}
	public void insereProduto()
	{
	

			String string;
			
			String stringTotal;
			stringTotal = "ttela=VEN&tipotela=CADASTRO&ttitulo=Mequetrefe4&";
			stringTotal += "tcep1=24000&tcep2=000&novo=S&TCATEGORIA=TTP_1&TINDINHEIRO=S&";
			stringTotal += "Tcustostransp=1&";
			stringTotal += "TLANMIN=1&";
			stringTotal += "TLANMINCENT=1&";
			stringTotal += "TQTITEM=1&TINPACOTE=1&TDIAVENC=1";

			stringTotal += "\r\n";

/*			
			stringTotal = URLEncoder.encode(stringTotal);			
			

			
			Socket s = new Socket("200.222.67.101",80);
			DataInputStream in = new DataInputStream(s.getInputStream());
			DataOutputStream out = new DataOutputStream(s.getOutputStream());
			out.writeBytes("POST pl/cadastralance HTTP/1.0\r\n");
			out.writeBytes("Content-type: application/x-www-form-urlencoded\r\n");
//			out.writeBytes("POST pl/cadastralance HTTP/1.0\r\n");
//			out.writeBytes("Content-type: plain/text\r\n");
			out.writeBytes("Content-length:"+stringTotal.length()+"\n\n");
//			out.writeBytes("POST pl/cadastralance HTTP/1.0\r\n");			
			out.writeBytes(stringTotal);			
			out.flush();
			out.close();
			in.close();
			s.close();
*/

	};
	public void criaLeilao()
	{
	
	};
	public void fechaLeilao()
	{
	};
	
	
	/************************** IniciaBusca *****************************/	
	/**Inicia a busca para o netleilao.com */	
	public void IniciaBusca() 
	{
		try
		{
			setIniciaBusca(true);
			//abre conex�o ...

			String stringTotal;
			stringTotal = "searchstring="+URLEncoder.encode(m_agente.nomeProduto())+"&";
			stringTotal += "searchtype=keyword&";
			String string = "Submit=OK";

			stringTotal = URLEncoder.encode(stringTotal);			

			DataOutputStream    printout;
	
			// URL of CGI-Bin script.
			m_url = new URL (base()+"bin/leilao.cgi");
			// URL connection channel.
			m_siteConnection = m_url.openConnection();
			// Let the run-time system (RTS) know that we want input.
			m_siteConnection.setDoInput (true);
			// Let the RTS know that we want to do output.
			m_siteConnection.setDoOutput (true);
			// No caching, we want the real thing.
			m_siteConnection.setUseCaches (false);
			// Specify the content type.
			m_siteConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			// Send POST output.
			printout = new DataOutputStream (m_siteConnection.getOutputStream ());
			printout.writeBytes (stringTotal);
			printout.flush ();
			printout.close ();
			m_in = new BufferedReader(
						new InputStreamReader(m_siteConnection.getInputStream()));

		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no IniciaBusca"+agente().stringErro() );
			setIniciaBusca(false);
		}			
	}
	
	/************************** finaliza a conex�o para a busca ************/
	public void finalizaConexao()
	{
		try
		{
			m_in.close();
			m_in = null;
		}
		catch(Exception e)
		{}
	
	}
	public Oferta verificaOferta(Item it)
	{
		Oferta oferta = null;
		try
		{
			double valorAtual = it.vetorCaracteristica.getValorCaracDouble("valorAtual");
			
			
			BuscaDetalhes(it);//	throws Exception 
			
			
			double valorAtual2 = it.vetorCaracteristica.getValorCaracDouble("valorAtual");
			if (valorAtual != valorAtual2)
			{
				oferta = new Oferta("Nome",String.valueOf(valorAtual2));
				
				oferta.setNumeroEstrelas(0);
							
				oferta.setCodProd(it.vetorCaracteristica.getValorCarac("codigo"));
				oferta.setNomeProd(it.vetorCaracteristica.getValorCarac("nomeProduto"));				
								
			
			
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no verificaOferta do Paginanetleilao "+agente().stringErro());
		}
		return oferta;
		
	}
	

	
/********************** transformaDataNetleilaoParaAgILE *****************************/	
	static private String transformaDataNetleilaoParaAgILE(String string)
	{
		int minuto=0, hora=0, dia=0, mes=0, ano=0 ,posIndex=0, posIndexAtual=0;
		String stringAtual;
	
		try
		{//31/10/2001 �s 06:28:09		

		    posIndex = string.indexOf('/',posIndexAtual);
			stringAtual = string.substring(posIndexAtual,posIndex);
			Integer valor = new Integer(Integer.parseInt(stringAtual, 10));
			dia = (int)valor.intValue();

			posIndexAtual = posIndex+1;
			posIndex = string.indexOf('/',posIndexAtual);
			stringAtual = string.substring(posIndexAtual,posIndex);
			valor = new Integer(Integer.parseInt(stringAtual, 10));
			mes = (int)valor.intValue();


			posIndexAtual = posIndex+1;
			posIndex = string.indexOf(' ',posIndexAtual);
			stringAtual = string.substring(posIndexAtual,posIndex);
			valor = new Integer(Integer.parseInt(stringAtual, 10));
			ano = (int)valor.intValue();

			posIndex = string.indexOf(':',posIndexAtual);
			posIndexAtual = posIndexAtual-2;
			stringAtual = string.substring(posIndexAtual,posIndex);
			valor = new Integer(Integer.parseInt(stringAtual, 10));
			hora = (int)valor.intValue();
		
			stringAtual = string.substring(posIndex,posIndex+2);
			valor = new Integer(Integer.parseInt(stringAtual, 10));
			minuto = (int)valor.intValue();
		

			int mes31 = 31;
			int mes30= 30;
			int mes28=28;
			
			if(mes==1) 
				mes =0;
			else if(mes == 2)
				mes = mes31;
			else if(mes == 3)
				mes = mes31+mes28;
			else if(mes == 4)	
				mes = 2*mes31+mes28;
			else if(mes == 5)	
				mes = 2*mes31+mes30+mes28;
			else if(mes == 6)	
				mes = 3*mes31+mes30+mes28;
			else if(mes == 7)	
					mes = 3*mes31+2*mes30+mes28;
			else if(mes == 8)	
				mes = 4*mes31+2*mes30+mes28;
			else if(mes == 9)	
				mes = 5*mes31+2*mes30+mes28;
			else if(mes == 10)	
				mes = 5*mes31+3*mes30+mes28;
			else if(mes == 11)	
				mes = 6*mes31+3*mes30+mes28;
			else if(mes == 12)
				mes = 6*mes31+4*mes30+mes28;
			
			ano = 2000+ano;
			string = minuto+"/"+hora+"/"+String.valueOf(dia+mes)+"/"+ano;		
			System.out.println("string:"+string);
			return string;
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no transformaDataNetleilaoParaAgILE" + string+" "+posIndex+" "+posIndexAtual);
		}
		return "";
	}
	
	/************************** BuscaDetalhes *****************************/
	/**faz a busca dos destalhes como descri��o e a foto para o netleilao.com */
	private void BuscaDetalhes(Item item)//	throws Exception 
	{
		BufferedReader in;
		try
		{
			//Abre a conex�o, para pegar os detalhes de cada produto(fotos e descricao)
			String stringTotal;
//bin/leilao.cgi?inforcomputador&1004963516			
			stringTotal = item.vetorCaracteristica.getValorCarac("referencia");

			stringTotal = URLEncoder.encode(stringTotal);			

			DataOutputStream    printout;

			// URL of CGI-Bin script.
			URL site = new URL(base()+"bin/leilao.cgi");

			// URL connection channel.
			URLConnection siteConnection = site.openConnection();
			// Let the run-time system (RTS) know that we want input.
			siteConnection.setDoInput (true);
			// Let the RTS know that we want to do output.
			siteConnection.setDoOutput (true);
			// No caching, we want the real thing.
			siteConnection.setUseCaches (false);
			// Specify the content type.
			siteConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			// Send POST output.
			printout = new DataOutputStream (siteConnection.getOutputStream ());
			printout.writeBytes (stringTotal);
			printout.flush ();
			printout.close ();
			in = new BufferedReader(
						new InputStreamReader(m_siteConnection.getInputStream()));

			String inputLine;
			int fromIndex = 0;
			int index;
			int fim,inic;
			String string;
			
			//pega cada linha
			while ((inputLine = in.readLine()) != null)
			{
				System.out.println (inputLine);

				//onde tiver uma figura � porque est� aqui, assumimos que jpg � s� a figura.
//<td width="30%"> <font face="Tahoma, Arial" size="2"><b>Pre&ccedil;o de base:</b> </font></td><td width="70%"><font face="Tahoma, Arial" size="2">15000$00 Esc</font></td>
				if ((index = inputLine.indexOf("base:",0)) > 0 )
				{
					//pega o 
					inic = inputLine.indexOf("2\">",index);
					if ( inic > 0)
					{
						inic = inic+3;
						fim = inputLine.indexOf("$",inic);
						string =  inputLine.substring(inic,fim);
						item.vetorCaracteristica.setValorCarac("valorInicial",string);
					}
				}
				
//<td width="30%"> <font face="Tahoma, Arial" size="2"><b>Data de fim do leil&atilde;o:</b></font></td><td width="70%">
//<font face="Tahoma, Arial" size="2">31/10/2001 �s 06:28:09<br> <font size="1">Ou 5 minutos apos a ultima oferta...</font></font></td>
				
				else if ((index = inputLine.indexOf("fim do",0)) > 0 )
				{
					//pega o 
					inic = inputLine.indexOf("2\">",index);
					if (inic > 0)
					{
						inic = inic+3;
						fim = inputLine.indexOf("<",inic);
						string =  inputLine.substring(inic,fim);
						
						string = transformaDataNetleilaoParaAgILE(string);
						
						item.vetorCaracteristica.setValorCarac("dataFim",string);
					}
				}//<b>Comprador: <font color="CE0000">romalopes2&nbsp;<A href='/jav/gesh_coment?USR=romalopes2&COD=3406970' target='miolo'>(0)</A><A href='/freeicon.htm' target=miolo><IMG alt='' 
/*				else if ((index = inputLine.indexOf("Comprador:",0)) > 0 )
				{
					//pega o 
					inic = inputLine.indexOf(">",index);
					if (inic > 0)
					{
						inic = inic+1;
						fim = inputLine.indexOf("&",inic);
						string =  inputLine.substring(inic,fim);


						
						item.vetorCaracteristica.setValorCarac("donoProduto",string);
						
						//Aqui pode chamar os detalhes do dono
					}
				}//<b>In&iacute;cio da venda:</b> 26/10/01 09:16<img src="images/1x1verm.gif" width="195" height="1" */
/*				else if ((index = inputLine.indexOf("cio da venda:",0)) > 0 )
				{
					//pega o 
					inic = inputLine.indexOf(">",index);
					if (inic > 0)
					{
						inic = inic+2;
						fim = inputLine.indexOf("<",inic);
						string =  inputLine.substring(inic,fim);
		
						string = transformaDatanetleilaoParaAgILE(string);
						
		
						item.vetorCaracteristica.setValorCarac("dataInicio",string);
						
					}
				}//	<b>N&ordm; lances:</b> 1<img src="images/1x1verm.gif" width="195" height="1" vspace="5"><br>	
*				
				else if ((index = inputLine.indexOf("lances::",0)) > 0 )
				{
					//pega o 
					inic = inputLine.indexOf(">",index);
					if (inic > 0)
					{
						inic = inic+2;
						fim = inputLine.indexOf(" ",inic);
						string =  inputLine.substring(inic,fim);
		
						System.out.println("string:"+inic+" "+fim+" "+string);		
		
//						item.vetorCaracteristica.setValorCarac("dataInicio",string);
						
						//Aqui pode chamar os detalhes.
					}
				}					
*/			}

			//pega a descri��o, pode ser grande.
//			StringBuffer buffer = new StringBuffer(1000);		
//			while ((inputLine = in.readLine()) != null)
//			{
//				inic = inputLine.indexOf("<br>",fromIndex);
//				if (inic < 0 && buffer.capacity() > inputLine.length())
//				{
//					buffer.append(inputLine);
//				}
//				else
//					break;
//			}
//			System.out.println ("Descri��o = "+buffer.toString());
//			item.setDescricao(buffer.toString());
			in.close();
		}
		catch(Exception e)
		{
			System.err.println(e+ " Erro em buscaDetalhes"+agente().stringErro());
		}

	}

	/************************** Busca *****************************/	
	/**faz a busca para o netleilao.com **/
	public Item Busca(String nomeProd)
	{
		Item item = null;

		try
		{
			/*
<TR BGCOLOR=#7B0042><TD ALIGN=CENTER WIDTH=62%><font color=#FFFF00><b><font face=Arial, Helvetica, sans-serif size=2>Artigo</font></b></font></TD><TD ALIGN=CENTER><font color=#FFFF00><b><font face=Arial, Helvetica, sans-serif size=2>Fim:</font></b></font></TD><TD ALIGN=CENTER><font color=#FFFF00><b><font face=Arial, Helvetica, sans-serif size=2>Ofertas</font></b></font></TD><TD ALIGN=CENTER><b><font face=Arial, Helvetica, sans-serif color=#FFFF00 size=2>Oferta <br>mais elevada</font></b></font></TD></TR>
<TR BGCOLOR=#DDDEE3><TD WIDTH=62%><A HREF=//bin/leilao.cgi?inforcomputador&1004963516><font face="Verdana, Arial" size="1">La Pen Cam AIPTEK 64 Mbit</a><img src="http://www.netleilao.com/img.gif" width="15" height="13"></font></TD><TD><font face="Verdana, Arial" size="1">06 dias 10 h. </font></TD><TD align=CENTER><font face="Verdana, Arial" size="1">0</font></TD><TD align=RIGHT><font face="Verdana, Arial" size="1">15000$00 Esc</font></TD></TR>
<TR BGCOLOR=#DDDEE3><TD WIDTH=62%><A HREF=//bin/leilao.cgi?inforcomputador&1005082883><font face="Verdana, Arial" size="1">***Sound Card TYPHOON Acoustic Five***</a><img src="http://www.netleilao.com/img.gif" width="15" height="13"></font></TD><TD><font face="Verdana, Arial" size="1">07 dias 19 h. </font></TD><TD align=CENTER><font face="Verdana, Arial" size="1">0</font></TD><TD align=RIGHT><font face="Verdana, Arial" size="1">17999$00 Esc</font></TD></TR>
<TR BGCOLOR=#DDDEE3><TD WIDTH=62%><A HREF=//bin/leilao.cgi?inforjogos&1004661115><font face="Verdana, Arial" size="1">FAMOSAS NUAS - KOURNUKOVA,PAM,GILLIAN,BRITNEY...</a></font></TD><TD><font face="Verdana, Arial" size="1">02 dias 22 h. </font></TD><TD align=CENTER><font face="Verdana, Arial" size="1">0</font></TD><TD align=RIGHT><font face="Verdana, Arial" size="1">1500$00 Esc</font></TD></TR>
<TR BGCOLOR=#DDDEE3><TD WIDTH=62%><A HREF=//bin/leilao.cgi?inforperifericos&1004479523><font face="Verdana, Arial" size="1">La Pen Cam AIPTEK 64 Mbit</a><img src="http://www.netleilao.com/img.gif" width="15" height="13"></font></TD><TD><font face="Verdana, Arial" size="1"><font color=red> 20 h 19 min.</font></TD><TD align=CENTER><font face="Verdana, Arial" size="1">0</font></TD><TD align=RIGHT><font face="Verdana, Arial" size="1">15000$00 Esc</font></TD></TR>
<TR BGCOLOR=#DDDEE3><TD WIDTH=62%><A HREF=//bin/leilao.cgi?inforperifericos&1004963465><font face="Verdana, Arial" size="1">La Pen Cam AIPTEK 64 Mbit</a><img src="http://www.netleilao.com/img.gif" width="15" height="13"></font></TD><TD><font face="Verdana, Arial" size="1">06 dias 10 h. </font></TD><TD align=CENTER><font face="Verdana, Arial" size="1">0</font></TD><TD align=RIGHT><font face="Verdana, Arial" size="1">15000$00 Esc</font></TD></TR>
<TR BGCOLOR=#DDDEE3><TD WIDTH=62%><A HREF=//bin/leilao.cgi?inforperifericos&1006212520><font face="Verdana, Arial" size="1">VENDO MATROX MARVEL G400 TV</a></font></TD><TD><font face="Verdana, Arial" size="1">20 dias 21 h. </font></TD><TD align=CENTER><font face="Verdana, Arial" size="1">0</font></TD><TD align=RIGHT><font face="Verdana, Arial" size="1">45000$00 Esc</font></TD></TR>
<TR BGCOLOR=#DDDEE3><TD WIDTH=62%><A HREF=//bin/leilao.cgi?lazerfilmes&1005334837><font face="Verdana, Arial" size="1">Fast and Furious em VideoCd!! S� 1600$ (2cds)</a><img src="http://www.netleilao.com/img.gif" width="15" height="13"></font></TD><TD><font face="Verdana, Arial" size="1">10 dias 17 h. </font></TD><TD align=CENTER><font face="Verdana, Arial" size="1">0</font></TD><TD align=RIGHT><font face="Verdana, Arial" size="1">1600$00 Esc</font></TD></TR>
<TR BGCOLOR=#DDDEE3><TD WIDTH=62%><A HREF=//bin/leilao.cgi?sonfotografia&1004531182><font face="Verdana, Arial" size="1">Fotografia numerica + Web Cam Typhoon VGA 64 Mbit</a><img src="http://www.netleilao.com/img.gif" width="15" height="13"></font></TD><TD><font face="Verdana, Arial" size="1">01 dia 10 h. </font></TD><TD align=CENTER><font face="Verdana, Arial" size="1">0</font></TD><TD align=RIGHT><font face="Verdana, Arial" size="1">16000$00 Esc</font></TD></TR>
<TR BGCOLOR=#DDDEE3><TD WIDTH=62%><A HREF=//bin/leilao.cgi?sonfotografia&1004531289><font face="Verdana, Arial" size="1">La Pen Cam AIPTEK 64 Mbit</a><img src="http://www.netleilao.com/img.gif" width="15" height="13"></font></TD><TD><font face="Verdana, Arial" size="1">01 dia 10 h. </font></TD><TD align=CENTER><font face="Verdana, Arial" size="1">1</font></TD><TD align=RIGHT><font face="Verdana, Arial" size="1">15500$00 Esc</font></TD></TR>
<TR BGCOLOR=#DDDEE3><TD WIDTH=62%><A HREF=//bin/leilao.cgi?sonfotografia&1005568186><font face="Verdana, Arial" size="1">La Pen Cam AIPTEK 64 Mbit</a><img src="http://www.netleilao.com/img.gif" width="15" height="13"></font></TD><TD><font face="Verdana, Arial" size="1">13 dias 10 h. </font></TD><TD align=CENTER><font face="Verdana, Arial" size="1">0</font></TD><TD align=RIGHT><font face="Verdana, Arial" size="1">15000$00 Esc</font></TD></TR>
*/ 
			int num = 0;
			int fromIndex = 0;
			int index;
			int inic,fim;
			
			//while para pegar cada linha
			while ( (m_inputLine = m_in.readLine()) != null && item ==null)
			{
//				m_inputLine = URLDecoder.decode(m_inputLine);
				index = m_inputLine.indexOf("mais elevada",fromIndex);
				if (index>0)
				{
					m_inputLine = m_in.readLine();//cada produto
					
//="Verdana, Arial" size="1">15000$00 Esc</font></TD></TR>
					index = m_inputLine.indexOf("HREF",fromIndex);
					if (index>0)
					{
						//pega a referencia  //inforcomputador&1004963516
						inic = m_inputLine.indexOf("?",index);
						fim = m_inputLine.indexOf(">",index);
						inic++;
						String referencia =  m_inputLine.substring(index,fim);
						
						//pega o codigo //1004963516
						inic = m_inputLine.indexOf("&",index);
						fim = m_inputLine.indexOf(">",index);
						inic++;
						String codigoProd =  m_inputLine.substring(inic,fim);

						//pega nome						
						fim++;
						inic = m_inputLine.indexOf(">",fim);
						fim = m_inputLine.indexOf("</a>",inic);
						String nome =  m_inputLine.substring(inic,fim);
						
						//numero de ofertas						
						fim++;
						inic = m_inputLine.indexOf("\">",fim);//esse � o do dias restante
						inic=inic+2;
						inic = m_inputLine.indexOf("\">",inic);//numero ofertas
						inic=inic+2;
						fim = m_inputLine.indexOf(">",inic);
						String numeroOfertas =  m_inputLine.substring(inic,fim);

						//valor oferta
						fim++;
						inic = m_inputLine.indexOf("\">",fim);
						fim = m_inputLine.indexOf("$",inic);
						String valorAtual =  m_inputLine.substring(inic,fim);

						//seta o codigo e o nome
						item = new Item(nome,agente(),this);
						item.vetorCaracteristica.setValorCarac("codigo",codigoProd);
						item.vetorCaracteristica.setValorCarac("valorAtual",valorAtual);
						item.vetorCaracteristica.setValorCarac("referencia",referencia);						
						item.vetorCaracteristica.setValorCarac("numeroOfertas",numeroOfertas);												

						GregorianCalendar dataAtual = new GregorianCalendar();
						item.setData(dataAtual);
						item.vetorCaracteristica.setValorCarac("dataInicio",Enviador.getStringData(dataAtual));							
						
						BuscaDetalhes(item);
					}		
				}
			}	
		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no Busca do Pagianetleilao" );
			return null;
		}			
	
//		this.finalizaConexao();
		
		return item;
	}

	
	/************************** IniciaOferta *****************************/	
	/*********************************************************************/	
	public void IniciaOferta() 
	{
		try
		{
		
			//abre conex�o ...
			m_siteConnection = m_url.openConnection();
			if(m_in!= null)
				m_in.close();
			m_in = new BufferedReader(
						new InputStreamReader(
						m_url.openStream()));
					
						
			StringBuffer line = new StringBuffer(5000);
			m_inputLine = new String(line);//s� pra garantir que a String ser� grande
			
		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no IniciaOferta" );
		}			
	}
	
	/************************** realizaOferta ****************************/
	/*********************************************************************/
	public boolean realizaOfertaItem(Item item,double valorOferta)
	{
		try
		{
		
//			IniciaOferta();
			
			//abre conex�o ... e j� realiza a oferta.
			String string;
			
			String stringTotal;
			stringTotal = "TUSERNAME=romalopes2&";
			stringTotal += "TSENHA=novembro&";
			string = "TCODVEND="+item.vetorCaracteristica.getValorCarac("codigo")+"&";
			stringTotal += string;
			String string2 = String.valueOf(valorOferta);
			string2 = string2.replace('.', ',');
			string = "TVLLANC=22,00&";//+string2;
			stringTotal += string;
			string = "TVLAGEND="+string2;			
			stringTotal += string;
			stringTotal += "\r\n";

			System.out.println(stringTotal);
			
			stringTotal = URLEncoder.encode(stringTotal);			
			
/*			
			Socket s = new Socket("200.222.67.101",80);
			DataInputStream in = new DataInputStream(s.getInputStream());
			DataOutputStream out = new DataOutputStream(s.getOutputStream());
			out.writeBytes("POST pl/cadastralance HTTP/1.0\r\n");
			out.writeBytes("Content-type: application/x-www-form-urlencoded\r\n");
//			out.writeBytes("POST pl/cadastralance HTTP/1.0\r\n");
//			out.writeBytes("Content-type: plain/text\r\n");
			out.writeBytes("Content-length:"+stringTotal.length()+"\n\n");
//			out.writeBytes("POST pl/cadastralance HTTP/1.0\r\n");			
			out.writeBytes(stringTotal);			
			out.flush();
			out.close();
			in.close();
			s.close();
*/







			
/*
			URL  url;
			URLConnection urlConn;
			DataOutputStream    printout;
			DataInputStream     input;
			// URL of CGI-Bin script.
			url = new URL (base() + "pl/cadastralance");
			// URL connection channel.
			urlConn = url.openConnection();
			// Let the run-time system (RTS) know that we want input.
			urlConn.setDoInput (true);
			// Let the RTS know that we want to do output.
			urlConn.setDoOutput (true);
			// No caching, we want the real thing.
			urlConn.setUseCaches (false);
			// Specify the content type.
			urlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			// Send POST output.
			printout = new DataOutputStream (urlConn.getOutputStream ());
//			String content = "name=" + URLEncoder.encode ("Buford Early") +
//							"&email=" + URLEncoder.encode ("buford@known-space.com");
			printout.writeBytes (stringTotal);
			printout.writeBytes("\r\n");
			printout.flush ();
			printout.close ();
			// Get response data.
			input = new DataInputStream (urlConn.getInputStream ());
			String str;
			while (null != ((str = input.readLine())))
			{
//				textArea.appendText (str + "\n");
			}
			input.close ();

*/


		
			//verifica se a oferta foi aceita, se sim faz mais alguma coisa...
			
			finalizaConexao();
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no RealizaOferta do Paginanetleilao para "+item.vetorCaracteristica.getValorCarac("codigo") + " " + agente().stringErro() );
			return false;
		}
		return true;
	}
}


