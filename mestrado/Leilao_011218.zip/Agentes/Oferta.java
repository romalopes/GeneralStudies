
/**classe Abstrata Agente**/
	
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;


public class Oferta extends Object implements Serializable
{	
	private String m_nomeUsuario;
	private String m_valorOferta;
	private String m_codProd;	
	private String m_nomeProd;
	private int m_numeroEstrelas;
	
	/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
			out.writeObject(m_nomeUsuario);
			out.writeObject(m_valorOferta);
			out.writeObject(m_codProd);
			out.writeObject(m_nomeProd);
			
			
			out.writeInt(m_numeroEstrelas);

			
			out.flush();
		}	
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do Oferta" );
		}			
	}
	
/****************************** readObject **********************************/		
	private void readObject(java.io.ObjectInputStream in)  
		throws IOException, ClassNotFoundException
	{
		try
		{
		
			m_nomeUsuario = (String)in.readObject();
			m_valorOferta = (String)in.readObject();
			m_codProd = (String)in.readObject();
			m_nomeProd = (String)in.readObject();
						
			m_numeroEstrelas = in.readInt();
			
		}
		catch(IOException e)
		{
			System.err.println(e+" Erro no read do Oferta" );
		}
	}
	 
	 
	public Oferta()
	{
		m_nomeUsuario = "";
		m_valorOferta = "";
		m_codProd = "";
		m_nomeProd = "";
		m_numeroEstrelas = 0;
	}
	public Oferta(String c)
	{
		m_nomeUsuario = c;
		m_valorOferta = "";
	}
	public Oferta(String c,String v)
	{
		m_nomeUsuario = c;
		m_valorOferta = v;
	}	
	
//NomeUsuario	
	public void setNomeUsuario(String n)
	{
		m_nomeUsuario = n;
	}
	public String nomeUsuario()
	{
		return m_nomeUsuario;
	}

//NumeroEstrelas	
	public void setNumeroEstrelas(int n)
	{
		m_numeroEstrelas = n;
	}	
	public int numeroEstrelas()
	{
		return m_numeroEstrelas;
	}

//ValorOferta		
	public void setValorOferta(String v)
	{
		m_valorOferta = v;
	}
	public String valorOferta()
	{
		return m_valorOferta;
	}

//CodProd		
	public void setCodProd(String c)
	{
		m_codProd = c;
	}
	public String codProd()
	{
		return m_codProd;
	}
	
//NomeProd		
	public void setNomeProd(String n)
	{
		m_nomeProd = n;
	}
	public String nomeProd()
	{
		return m_nomeProd;
	}

	public String printCaracteristicas()
	{
		return "nomeProd="+m_nomeProd+" codProd="+m_codProd+" m_valorOferta="+m_valorOferta+" m_nomeUsuario="+m_nomeUsuario+" m_numeroEstrelas="+String.valueOf(m_numeroEstrelas)+"  ";
		//+vetorCaracteristica.printCaracteristicas();
	}
	
	public void init(){}

}