/**classe Gerador de Agentes Compra**/
	
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

import ClassesGeral.ObjetoEnviado;
import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;


public class GerenciaAgente {
    public static void main(String[] args) 
			throws IOException, ClassNotFoundException
	{


		//Cria o Enviador, que vai conter todos os Agentes.
		Gerente m_gerente = new Gerente();
		m_gerente.startRelogio();

		while(true)
		{
			// create a GregorianCalendar
			System.out.println("Esperando em : "+ Enviador.getStringData(new GregorianCalendar()));//calendar.get(Calendar.MINUTE)+"/"+calendar.get(Calendar.HOUR_OF_DAY)+"/"+calendar.get(Calendar.DAY_OF_YEAR)+"/"+ calendar.get(Calendar.YEAR) );	
			
			//ainda assumindo que a Msg est� com valores.
			Mensagem Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoServidorGerente);
		    //cria uma thread para liberar o Servidor para novas mensagens...
			Gerenciador_Delegado gd;
			gd = new Gerenciador_Delegado(m_gerente);
			gd.processa(Msg);
		    gd.start();
		}
	}//main
}//class