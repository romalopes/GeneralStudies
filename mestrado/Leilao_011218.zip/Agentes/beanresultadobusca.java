import java.io.*;
import java.util.*;
import java.net.*;

import ClassesGeral.ObjetoEnviado;
import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

public class beanresultadobusca extends BeanGeral
{
	
	public ObjetoEnviado pegaAgenteEnviador()
	{
		
		Mensagem Msg = new Mensagem(getNomeUsuario(),getIP());
		Msg.setMensagem("pegaUsuario");
		Msg.setMensagemAux(getNomeAgente());
	
		Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
      	Usuario usuario = (Usuario)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);

		if (usuario == null)
		{
			//"Enviando NULL como usuario");
			return null;
		}
				
		AgenteCompra agenteCompra = (AgenteCompra)usuario.findAgente(getNomeAgente());
		if(agenteCompra != null)
		{
			return agenteCompra;
		}
		//"Enviando NULL como o agente");
		return null;	
	}
	
	public String processa()
	{
	
		try
		{
			//pega a descri��o, pode ser grande.
			StringBuffer buffer = new StringBuffer();		
		
			Agente ag = (Agente)pegaAgenteEnviador();
			if (ag != null)
		    {
				int j = 0 ;
				Item item;
			
				if (ag.getItemAt(0) == null)
				{
					if(ag.jaBuscou())
						return "Nenhum Item Associado ao Agente";			
					else	
						return "O Agente ainda n�o realizou a busca";			
				}
				Item it = (Item)ag.getItemAt(j);
				while (it != null)
				{
					buffer.append("<b>Item =</b>"+it.nome());	  	
					buffer.append("<b>Codigo = </b>"+it.vetorCaracteristica.getValorCarac("codigo"));	  	
					buffer.append("<b>Pre�o inicial = </b>"+it.vetorCaracteristica.getValorCarac("valorInicial"));	  						
					buffer.append("<b>Pre�o = </b>"+it.vetorCaracteristica.getValorCarac("valorVencedor"));	  	
					buffer.append("<br>");	  	
					buffer.append("<br> Valores dos criterios = </b>");	  	
					buffer.append(it.avaliacoes());
					if(it.vetorCaracteristica.getValorCarac("caminhoFigura").length() >0) 
					{
						buffer.append("<center><img src= ALT=\""+it.vetorCaracteristica.getValorCarac("caminhoFigura")+"\"");				
						buffer.append(" height=150 width = 100 border= \"1\"></center>	<br>");
					}	
					buffer.append("	<br>");
				 	j++;
					it = (Item)ag.getItemAt(j);
				}
		    }
			return buffer.toString();
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no processa do beanresultadobusca");
		}
		return "";
	}
}//class

//c:\program files\GNU\gnujsp-1.0.1\lib\servlet-2.0-plus.jar;c:\program files\jsdk2.0\lib\jsdk.jar;c:\program files\Gnu\gnujsp-1.0.1\lib\gnujsp10.jar;