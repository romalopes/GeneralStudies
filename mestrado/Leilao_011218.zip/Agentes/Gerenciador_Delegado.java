import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;
	
import ClassesGeral.ObjetoEnviado;
import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
	
/**Classe que extends Thread chamada pelo GerenciaAgente, utilizada
	 liberar o GerenciaAgente para receber novas mensagens,**/
public class Gerenciador_Delegado extends Thread
{
	Gerente m_gerente;
	Mensagem m_mensagem;
	public  Gerenciador_Delegado(Gerente g)
	{//gostaria que esse metodo fosse pivado e somento o GerenciaAgente chamasse
	//tentei colocar a classe dentro da classe GerenciaAgente mas n�o consegui.
		m_gerente = g;
	}

	//recebe a mensagem do Cliente que passou pelo Servidor, e no futuro vai para o Processador.
	public synchronized void processa(Mensagem Msg)
	{
		m_mensagem = Msg;
	}

	//executa... Apenas chama o ProcessaMensagem do Enviador.
	public synchronized void run()
	{

//		System.out.println("Comecou a rodar Gerenciador_Delegado");			
		try
		{
//			System.out.println(m_mensagem.printCaracteristicas());
			ObjetoEnviado obj = null;
			if (m_mensagem != null)
			{
				if (m_mensagem.tipo().equals("site"))
					obj = m_gerente.processaMensagem(m_mensagem);				
				else
					obj = m_gerente.processaMensagemAgente(m_mensagem);

				if (m_mensagem.reply() == true)
				{
					
					if (m_mensagem.tipo().equalsIgnoreCase("Agente"))
						m_gerente.processaMensagemAgente((Mensagem)obj);
//						Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,obj);
					else	
					{
						Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoClienteGerente,obj);
					}
				}
			}
		}
		catch (Exception e) 
		{
			System.err.println(" Erro em Gerenciador_Delegado" + e);
			return;
		}

//		System.out.println("Terminou de rodar Serv_Delegado");

 	}   
}