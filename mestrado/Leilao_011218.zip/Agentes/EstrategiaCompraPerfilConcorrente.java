/**classe EstrategiaPerfilConcorrente**/

import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.VetorCaracteristica;
import ClassesGeral.Caracteristica;

/**
� uma estrat�gia.

Nessa estrat�gia comprasse os perfis dos concorrentes e verifica 
o tempo restante para o t�rmino do leil�o.

Os oponetes serao divididos de duas formas relacionadas. 
A primeira e o numero de estrelas e a outra e a quantidade de ofertas.
Estrelas : informacao vinda do leilao.  quanto mais estrelas melhor o oponente, poucas estrelas ele n'ao 'e confi[avel
Numero oferta : Se tiver muitas quer muito o produto.

Devemos considerar se o oponete esta vencendo o leilao.

Procedimento:
muitas estrelas - muitas ofertas - atue pouco, mas fazendo uma oferta grande para ver a disposicao
muitas estrelas - poucas ofertas -  atue muito com ofertas simples
poucas estrelas - muitas oferta - especulador, atue pouco com ofertas minimas
poucas estrelas - poucas ofertas - atue pouco com ofertas simples.
**/

public class EstrategiaCompraPerfilConcorrente extends Estrategia
{
	Vector vetorUsuariosOfertas;//o vetor com objetos da classe acima.
	Vector listItensOfertas;
	boolean m_primeiraOferta;
	
	public EstrategiaCompraPerfilConcorrente(AgenteCompra ag)
	{
		super(ag);
		try
		{	
			vetorUsuariosOfertas = new Vector();
			listItensOfertas = new Vector();
			m_primeiraOferta = true;
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro na Cria��o do EstrategiaCompraPerfilConcorrente" );
		}
	}

	

	/****************************** writeObject **********************************/
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{
			int i;		
			out.writeInt(vetorUsuariosOfertas.size());
			for(i=0;i<vetorUsuariosOfertas.size();i++)
			{
				out.writeObject(vetorUsuariosOfertas.elementAt(i));
			}
			out.writeInt(listItensOfertas.size());
			for(i=0;i<listItensOfertas.size();i++)
			{
				out.writeObject(listItensOfertas.elementAt(i));
			}
			out.writeBoolean(m_primeiraOferta);

			out.flush();

		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write da EstrategiaCompraPerfilConcorrente" );
		}
	}

/****************************** readObject **********************************/
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			vetorUsuariosOfertas = new Vector();		
			int i,size = in.readInt();
			for(i=0;i<size;i++)
			{
				vetorUsuariosOfertas.addElement(in.readObject());
			}
			
			size = in.readInt();
			listItensOfertas = new Vector();
			for(i=0;i<size;i++)
			{
				listItensOfertas.addElement(in.readObject());
			}
			m_primeiraOferta= in.readBoolean();
		}
		catch(IOException e)
		{
			System.err.println(e+" Erro no read da EstrategiaCompraPerfilConcorrente" );
		}
	}
/****************** findVetorUsuariosOfertas *********************/	
	private VetorOferta findVetorUsuariosOfertas(String nomeConcorrente)
	{
		try
		{
			VetorOferta vetorOferta;
			for(int i=0;i<vetorUsuariosOfertas.size();i++)
			{
				vetorOferta = (VetorOferta)vetorUsuariosOfertas.elementAt(i);
				if(nomeConcorrente.equals(vetorOferta.vetorVetorCaracUsu.getValorCarac("nome")))
					return vetorOferta;
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no read da findVetorUsuariosOfertas" );
		}
		return null;
	}

	
/****************** recebeReplyBuscaParticipanteIndividual *********************/	
//vai modificar as informa��es do perfil de um usu�rio espec�fico.   
	private void recebeReplyBuscaParticipanteIndividual(Mensagem msg)
	{
		String nomeConcorrente = Enviador.pegaParte(msg.mensagemAux(),0,',');
		VetorOferta vetorOferta;
		vetorOferta = findVetorUsuariosOfertas(nomeConcorrente);
		if (vetorOferta == null)
		{
			vetorOferta = new VetorOferta();
			vetorUsuariosOfertas.addElement(vetorOferta);//cada vetor oferta 'e relativa a um usuario

		}
		vetorOferta.vetorVetorCaracUsu.setCaracteristicas(msg.mensagemAux());

		ag().executaEstrategia();
	}

/************************** findMaiorOferta ********************/
//acha a maior oferta ao item.
	public Oferta findMaiorOferta(Item it)
	{
		String nome = null;
		Oferta oferta=null,ofertaMelhor=null;		
		try
		{
		
			String codProdAtual,codProd = it.vetorCaracteristica.getValorCarac("codigo");
					
			VetorOferta vetorOferta = null;
			double valorOferta=0,valorOfertaAtual=0;
			for(int i=0;i<vetorUsuariosOfertas.size();i++)
			{

				vetorOferta = (VetorOferta)vetorUsuariosOfertas.elementAt(i);
				oferta = (Oferta)vetorOferta.ofertas.elementAt(vetorOferta.ofertas.size()-1);//pega a ultima oferta desse cara

				codProdAtual = oferta.codProd();
				
				if (codProdAtual.equals(codProd))
				{
					Double valor = Double.valueOf(oferta.valorOferta());
					valorOfertaAtual = (double)valor.doubleValue();
					if(valorOfertaAtual > valorOferta)
	 				{
	 					valorOferta = valorOfertaAtual;
	 					ofertaMelhor = oferta;
	 				}
				}
				
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no findVetorMaiorOferta da Estrat'egiaCompraPerfilConcorente");
		}
		return ofertaMelhor;
	}
	
/************************** findNumeroOfertas ********************/
//retorna o n�mero de ofertas que o usu�rio j� deu para esse item
	public int findNumeroOfertas(String nomeConcorrente,Item it)
	{
		String nome = null;
		Oferta oferta=null,ofertaMelhor=null;		
		try
		{
			int numeroOfertas=0;		
			String codProdAtual,codProd = it.vetorCaracteristica.getValorCarac("codigo");
					
			VetorOferta vetorOferta = null;
			double valorOferta=0,valorOfertaAtual=0;
			vetorOferta = findVetorUsuariosOfertas(nomeConcorrente);
			
			if (vetorOferta != null)
			{
				for(int i=0;i<vetorOferta.ofertas.size();i++)
				{
					oferta = (Oferta)vetorOferta.ofertas.elementAt(i);//pega a ultima oferta desse cara
	
					if (codProd.equals(oferta.codProd()))
						numeroOfertas++;
				}
			}
			return numeroOfertas;
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no findVetorMaiorOferta da Estrat'egiaCompraPerfilConcorente");
		}
		return 0;
	
		
	}
	

/************************** achaMomento ********************
/**decide o melhor momento para realizar a oferta.  Se for anterior ao momento atual, ent�o deve-se aumentar o pre�o da oferta.  Retorna o minuto que deve ser realizada a oferta*							
	private double achaMomento(Item it)
	{
		try
		{
			AgenteCompra ag = (AgenteCompra)ag();

			Pagina pag = ag.findPagina(it.pagina().nome());
			if (pag == null)
			{
				System.err.println("P�gina n�o existe no item:"+it.vetorCaracteristica.getValorCarac("codigo")+"  "+it.vetorCaracteristica.getValorCarac("nomeDono"));
				return 0;
			}
			double valorInicial = it.vetorCaracteristica.getValorCaracDouble("valorInicial");
			
			double valorAtual = it.vetorCaracteristica.getValorCaracDouble("valorAtual");

			double precoMax = ag.vetorCaracteristica.getValorCaracDouble("precoMax");
		
			//pegou o pre�o maximo mas vai verificar atrav�s da avalia��o qual o precoMaximo aceito para o item.
			precoMax = precoMax*it.somaAvaliacao();

			int tempoRestanteLeilao = pag.tempoRestante(it);
			int tempoRodandoLeilao = pag.tempoRodando(it);
			
			//tempo Restante
			double tempoRestante = ag().vetorCaracteristica.getValorCaracDouble("tempoTrabalho");
			double tempoTrabalhando	= ag().tempoTrabalhando();
			tempoRestante = tempoRestante-tempoTrabalhando;
			if (tempoRestante<0)
			{
				tempoRestante = 0;
				return 0;
			}
			if(tempoRestante > tempoRestanteLeilao)
				tempoRestante = tempoRestanteLeilao;
			
			double menorDiferenca = it.vetorCaracteristica.getValorCaracDouble("menordiferenca");
			if (menorDiferenca == 0)
			{
				menorDiferenca++;
				System.out.println("menorDiferenca:"+menorDiferenca);
				it.vetorCaracteristica.setValorCarac("menordiferenca",String.valueOf(menorDiferenca));	
			}
		
			double deltaPreco = precoMax-valorInicial;

			double tempo = (double)(tempoRestante*(valorAtual - valorInicial));
			tempo = tempo/(deltaPreco);//peguei o tempo.  se o tempo em relacao ao valor for maior que o atual entao deve esperar
		
			it.vetorCaracteristica.setValorCarac("tempoOferta",String.valueOf(tempo));
		
			System.out.println("tempoRestante"+tempoRestante+"tempoTrabalhando"+tempoTrabalhando+" tempoRodandoLeilao:"+tempoRodandoLeilao+" tempo:"+tempo+" \nvalorAtual"+valorAtual+" valorInicial:"+valorInicial+" precoMax:"+precoMax);
			return tempo;
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no achaMomento da EstrategiaCompraPerfilConcorrente do Agente de compra :"+ag().nome());
		}

			
		return 0.0;	
	}
	
/************************** achaValor ********************/	
/**acha o valor para realizar a oferta, se for maior que o valor m�ximo, ent�o pode-se realizar uma oferta maior que a menor diferen�a, por�m menor que o pre�o m�ximo permitido*/
	private double achaValor(double tempoOferta,Item it)
	{
		try
		{
	
			Pagina pag = ag().findPagina(it.pagina().nome());
			if (pag == null)
			{
				System.err.println("P�gina n�o existe no item:"+it.vetorCaracteristica.getValorCarac("codigo")+"  "+it.vetorCaracteristica.getValorCarac("nomeDono"));
				return 0;
			}

			//tempo de leil�o
			double tempoRestanteLeilao = pag.tempoRestante(it);
			double tempoRodandoLeilao = pag.tempoRodando(it);

			//tempo Restante
			double tempoRestante = ag().vetorCaracteristica.getValorCaracDouble("tempoTrabalho");
			double tempoTrabalhando	= ag().tempoTrabalhando();
			tempoRestante = tempoRestante-tempoTrabalhando;
			
			
//			System.out.println(tempoRestanteLeilao+" "+tempoRestante+" "+ag().nome()+" "+Enviador.getStringData(new GregorianCalendar()));			
			tempoRestanteLeilao = Math.min(tempoRestanteLeilao,tempoRestante);
			if (tempoRestanteLeilao<0)
			{
				tempoRestanteLeilao = 0;
				ag().appendHistoria("Problema.  Ainda estou em um leil�o que j� fechou "+ it.nome());
				//colocar algum comentario
				return 0;
			}
			double tempo = (tempoRodandoLeilao/(tempoRestanteLeilao+tempoRodandoLeilao));
			
			String subTipoEstrategia = ag().vetorCaracteristica.getValorCarac("subTipoEstrategia");
//			System.out.println(ag().nome()+" "+subTipoEstrategia);
			if (subTipoEstrategia.equalsIgnoreCase("ARRISCADO"))
			{
				tempo = Math.sqrt(tempo);
			}
			else if (subTipoEstrategia.equalsIgnoreCase("MODERADO"))
			{
				tempo = tempo*tempo;
			}
//			System.out.println(ag().nome()+" tempo:"+tempo);
//			else if (subTipoEstrategia.equals("NORMAL"))
//			{
//			}
					
			
			
//			System.out.println("tempo:"+tempo+" tempoRodandoLeilao:"+tempoRodandoLeilao +"  tempoRestanteLeilao:"+tempoRestanteLeilao);
			//valor Inicial do produto						
			double valorInicial = it.vetorCaracteristica.getValorCaracDouble("valorInicial");
			
			//o valor inicial do produto
			double valorAtual = it.vetorCaracteristica.getValorCaracDouble("valorAtual");

			//preco m�ximo aceito para o produto. 
			double precoMax = ag().vetorCaracteristica.getValorCaracDouble("precoMax");
			//pegou o pre�o maximo mas vai verificar atrav�s da avalia��o qual o precoMaximo aceito para o item.
			precoMax = precoMax*it.somaAvaliacao();
	
			double deltaPreco = precoMax-valorInicial;

			double valorOferta = ((precoMax-valorInicial)*tempo)+valorInicial;

			if(valorOferta == 0)
				valorOferta=valorInicial;
				
//			System.out.println("agente:"+ag().nome()+" valorOferta:"+valorOferta+" tempo:"+tempo);			
			
			//menor diferen�a entre ofertas
			double menorDiferenca = it.vetorCaracteristica.getValorCaracDouble("menordiferenca");
			
			if (menorDiferenca == 0)
			{
				menorDiferenca++;
//				System.out.println("menorDiferenca:"+menorDiferenca);			
				it.vetorCaracteristica.setValorCarac("menordiferenca",String.valueOf(menorDiferenca));	
			}
						
//			System.out.println("valorOferta:"+valorOferta+" tempoTrabalhando:"+tempoTrabalhando+" tempoRestante:"+tempoRestante+"\nvalorInicial:"+valorInicial+" valorAtual:"+valorAtual+" deltaPreco:"+deltaPreco);			
		
			it.vetorCaracteristica.setValorCarac("valorOferta",String.valueOf(valorOferta));
			it.vetorCaracteristica.setValorCarac("tempoOferta",String.valueOf(tempo));
			return valorOferta;	
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no achaValor da EstrategiaCompraPerfilConcorrente do agente " + ag().nome());
		}

		return (float)0;	
	}	
	
/*********************** avaliacaoItem ***********************/	
	private double avaliacaoItem(Item it)
	{
		try
		{
//			System.out.println("$$$$$$ Avalianado "+it.nome()+" $$$$$$"+it.pagina().nome());
		
			Pagina pag = ag().findPagina(it.pagina().nome());
			if (pag == null)
			{
				System.err.println("P�gina n�o existe no item:"+it.vetorCaracteristica.getValorCarac("codigo")+"  "+it.vetorCaracteristica.getValorCarac("nomeDono"));
				return 0;
			}
		
			double valorOferta = it.vetorCaracteristica.getValorCaracDouble("valorOferta");
		
			double tempoOferta = it.vetorCaracteristica.getValorCaracDouble("tempoOferta");
	
			double v = tempoOferta*valorOferta;
			
//			System.out.println(ag().nome()+"  avaliacaoOferta:"+v+" tempoOferta:"+tempoOferta+" valorOferta:"+valorOferta);
			it.vetorCaracteristica.setValorCarac("avaliacaoOferta",String.valueOf(v));
			
/*
			//tempo de leil�o
			double tempoRestanteLeilao = pag.tempoRestante(it);
			double tempoRodandoLeilao = pag.tempoRodando(it);

			//tempo Restante
			double tempoRestante = ag().vetorCaracteristica.getValorCaracDouble("tempoTrabalho");
			double tempoTrabalhando	= ag().tempoTrabalhando();
			tempoRestante = tempoRestante-tempoTrabalhando;
			
			
			System.out.println(tempoRestanteLeilao+" "+tempoRestante+" "+ag().nome()+" "+Enviador.getStringData(new GregorianCalendar()));			
			tempoRestanteLeilao = Math.min(tempoRestanteLeilao,tempoRestante);
			if (tempoRestanteLeilao<0)
			{
				tempoRestanteLeilao = 0;
				ag().appendHistoria("Problema.  Ainda estou em um leil�o que j� fechou "+ it.nome());
				//colocar algum comentario
				return 0;
			}
			double tempo = (tempoRodandoLeilao/(tempoRestanteLeilao+tempoRodandoLeilao));
*/
//Tenho que verifica a avalia��o de cada um melhor um pouquinho...			
			return v;
			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no avaliacaoItem da EstrategiaCompraPerfilConcorrente do agente " + ag().nome());
		}
		return 0;
	}
	
/*********************** verificaOponentes ***********************/	
public String verificaOponentes(Item it)
{

	VetorOferta vetorOferta=null;
	try
	{
		Oferta oferta;
		String nomeOponente;
		for(int i=0;i<it.vetorOfertas.size();i++)
		{
			 oferta = (Oferta)it.vetorOfertas.elementAt(i);	
			 if (!oferta.nomeUsuario().equals(ag().nomeUsuarioPagina()))
			 {
				 vetorOferta = findVetorUsuariosOfertas(oferta.nomeUsuario());
				 if(vetorOferta==null)
				 {
				 	 	vetorOferta = new VetorOferta();
						//cada vetor oferta 'e relativa a um usuario
				 	 	vetorUsuariosOfertas.addElement(vetorOferta);
				 }
				 
				 //sao as ofertas do usuario.
				 vetorOferta.insereOferta(oferta);		
			 }
	 	}
	 	
		//s� para retorna nome do usuario com a melhor oferta, procura no vetorUsuariosOfertas
	 	return "";//findVetorMaiorOferta(it,vetorOferta);
	}
	catch(Exception e)
	{
		System.err.println(e+" Erro no verificaOponentes da EstrategiaCompraPerfilConcorrente do agente " + ag().nome());

	}
	return "";
}
			
/*********************** analisaSituacaoItemIndividual ***********************/	
	public double analisaSituacaoItemIndividual(Item it)
	{
		double avaliacao=0;
		AgenteCompra ag = (AgenteCompra)ag();
		try
		{
		
			
			Pagina pag = ag.findPagina(it.pagina().nome());
			if (pag == null)
			{
				System.err.println("P�gina n�o existe no item:"+it.vetorCaracteristica.getValorCarac("codigo")+"  "+it.vetorCaracteristica.getValorCarac("nomeDono"));
				return 0.0;
			}
			pag.verificaOferta(it);
			
			
			String s;
			int size = it.vetorOfertas.size();
			if (size > 0)
			{
				Oferta oferta = (Oferta)it.vetorOfertas.elementAt(size - 1);	
				if(oferta != null)
					if(ag.nomeUsuarioPagina().equalsIgnoreCase(oferta.nomeUsuario()))
						return 0 ;//o vencedor atual � o pr�prio agente
			}				
			
			//decide o melhor momento para realizar a oferta.  Se for anterior ao momento atual, ent�o deve-se aumentar o pre�o da oferta.
			double tempoOferta = 0;//= achaMomento(it);			

	
			verificaOponentes(it);
			
			//acha o valor para realizar a oferta, se for maior que o valor m�ximo, ent�o pode-se realizar uma oferta maior que a menor diferen�a, por�m menor que o pre�o m�ximo permitido
			double valorOferta = achaValor(tempoOferta,it);

			avaliacao = avaliacaoItem(it);	
			
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no analisaSituacaoItemIndividual da EstrategiaCompraPerfilConcorrente do Agente de compra :"+ag().nome());
		}
		return avaliacao;
	}

	/****************** modificaValorOfertaPerfilOponentes *****************/
	//est� dentro o m�todo que chama esse.
	public double modificaValorOfertaPerfilOponentes(Item it,double valorOferta)
	{
		Oferta oferta;
		try
		{
			oferta = findMaiorOferta(it);
			if(oferta == null)
				return valorOferta;
				
			int numeroEstrelas = oferta.numeroEstrelas();
			
			int numeroOfertas = findNumeroOfertas(oferta.nomeUsuario(),it);
			
			int fatorNumeroEstrelas = ag().vetorCaracteristica.getValorCaracInteiro("fatorNumeroEstrelas");
//muitas estrelas - muitas ofertas - atue pouco, mas fazendo uma oferta grande para ver a disposicao
//muitas estrelas - poucas ofertas -  atue muito com ofertas simples
//poucas estrelas - muitas oferta - especulador, atue pouco com ofertas minimas
//poucas estrelas - poucas ofertas - atue pouco com ofertas simples.
			
			if (numeroEstrelas>=fatorNumeroEstrelas)
			{
			
			}
			else
			{
			
			}
			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no modificaValorOfertaPerfilOponentes da EstrategiaCompraPerfilConcorrente do Agente de compra :"+ag().nome());
		}
		return valorOferta;
	
	}


	/*********************** realizaOfertaItem ***********************/	
	public boolean realizaOfertaItem(Item it)
	{
		try
		{
			AgenteCompra ag = (AgenteCompra)ag();
		
			Pagina pag = ag.findPagina(it.pagina().nome());
			if (pag == null)
			{
				System.err.println("P�gina n�o existe no item:"+it.vetorCaracteristica.getValorCarac("codigo")+"  "+it.vetorCaracteristica.getValorCarac("nomeDono"));
				return false;
			}
				
			double avaliacaoMinimaOferta = it.vetorCaracteristica.getValorCaracDouble("avaliacaoMinimaOferta");
//			System.out.println("avaliacaoMinima"+avaliacaoMinimaOferta);
			double avaliacaoOferta = it.vetorCaracteristica.getValorCaracDouble("avaliacaoOferta");
//			System.out.println("avaliacaoOferta"+avaliacaoOferta);			
//			if(avaliacaoOferta < avaliacaoMinimaOferta)
//			{
//				System.out.println("*****************\n*************\n Nao realiza oferta agora pois as avaliacoes nao sao boas"+avaliacaoOferta+"******AvalMin:"+avaliacaoMinimaOferta);
//				return false;
//			}
		
			double menorDiferenca = it.vetorCaracteristica.getValorCaracDouble("menordiferenca");
			
			double precoMax = ag.vetorCaracteristica.getValorCaracDouble("precoMax");
			double valorAtual = it.vetorCaracteristica.getValorCaracDouble("valorAtual");
						
			double valorOferta = it.vetorCaracteristica.getValorCaracDouble("valorOferta");
			
			double tempoOferta = it.vetorCaracteristica.getValorCaracDouble("tempoOferta");
			
//Modifica o valor da oferta com base no perfil dos oponentes
//			valorOferta = modificaValorOfertaPerfilOponentes(it,valorOferta);
			Oferta oferta;
			oferta = findMaiorOferta(it);
			if (oferta != null)
			{
				int numeroEstrelas = oferta.numeroEstrelas();
				int numeroOfertas = findNumeroOfertas(oferta.nomeUsuario(),it);
				int numerConcorrentes = vetorUsuariosOfertas.size();
			
				int fatorNumeroEstrelas = ag.vetorCaracteristica.getValorCaracInteiro("fatorNumeroEstrelas");
				int fatorNumeroConcorrentes = ag.vetorCaracteristica.getValorCaracInteiro("fatorNumeroConcorrentes");				
		
				if (numeroEstrelas >= fatorNumeroEstrelas )
				{
		//muitas estrelas - muitas ofertas - atue pouco, mas fazendo uma oferta grande para ver a disposicao				
					if (numeroOfertas >= fatorNumeroConcorrentes)
					{
						tempoOferta = tempoOferta - (tempoOferta/10);//mais 10 por cento no tempo de oferta.
						valorOferta = valorOferta + (valorOferta/10);//mais 10 por cento no valor de oferta.
					}
					else
					{
					//muitas estrelas - poucas ofertas -  atue muito com ofertas simples
						tempoOferta = tempoOferta + (tempoOferta/10);//menos 10 por cento no tempo de oferta.
					}
				}
				else
				//poucas estrelas - muitas oferta - especulador, atue pouco com ofertas minimas				
//				if (numeroEstrelas < 3)
				{
					tempoOferta = tempoOferta - (tempoOferta/10);//mais 10 por cento no tempo de oferta.
				}
			
				//muitas estrelas - muitas ofertas - atue pouco, mas fazendo uma oferta grande para ver a disposicao
				//muitas estrelas - poucas ofertas -  atue muito com ofertas simples
				//poucas estrelas - muitas oferta - especulador, atue pouco com ofertas minimas
				//poucas estrelas - poucas ofertas - atue pouco com ofertas simples.
				
			}

			it.vetorCaracteristica.setValorCarac("tempoOferta",String.valueOf(tempoOferta));			

			if (valorOferta>precoMax && (valorAtual + menorDiferenca*2)<precoMax)
			{
				valorOferta = valorAtual + menorDiferenca*2;//(precoMax-valorOferta);//fiz alguma coisa so pra fazer com que a oferta seja maior.
			}
			else if((valorAtual + menorDiferenca)>precoMax)
				valorOferta = valorAtual + menorDiferenca;


		
			double tempoTrabalho = ag.vetorCaracteristica.getValorCaracDouble("tempoTrabalho");

//			System.out.println("tempoTrab:"+ tempoTrabalho+" TempoOferta:"+tempoOferta+" valorAtual:"+ valorAtual+" valorOferta:"+valorOferta);

			StringBuffer buf = new StringBuffer(500);
			if ( (tempoTrabalho>=tempoOferta && valorOferta>=(valorAtual+menorDiferenca) ) || m_primeiraOferta==true)//se o tempo que j� foi trabalhado at� o momento	for maior que o tempo ideal da oferta, ent�o pode fazer a oferta.		
			{
				m_primeiraOferta = false;
				buf.append("Vai efetuar a oferta sobre produto:"+it.vetorCaracteristica.getValorCarac("codigo"));
				buf.append("\n, o valor estimado por mim nesse momento �:"+String.valueOf(valorOferta)+", e o valor minimo para oferta �:"+String.valueOf(valorAtual+menorDiferenca)); 
				buf.append(".\n  O momento ideal para mim �:"+String.valueOf(tempoOferta)+", e o tempo de trabalho at� agora �:"+String.valueOf(tempoTrabalho));
				ag.appendHistoria(buf.toString());
				ag.realizaOfertaItem(it,valorOferta);	
				return true;
			}
			else
			{
				System.out.println("***************"+ag.nome()+"em:"+Enviador.getStringData(new GregorianCalendar())+" Achou melhor n�o efetuar a oferta sobre produto:"+it.vetorCaracteristica.getValorCarac("codigo")+"***************");
			
				buf.append("Achei melhor n�o efetuar a oferta sobre produto:"+it.vetorCaracteristica.getValorCarac("codigo"));
				buf.append("\n, o valor estimado por mim nesse momento seria:"+String.valueOf(valorOferta)+", e o valor minimo para oferta �:"+String.valueOf(valorAtual+menorDiferenca)); 
				buf.append(".\n  O momento ideal para mim seria:"+String.valueOf(tempoOferta)+", e o tempo de trabalho at� agora �:"+String.valueOf(tempoTrabalho));
				ag.appendHistoria(buf.toString());
				return false;
			}
		}
		catch(Exception e)
		{
			System.out.println(e+" Erro no realizaOfertaItem da EstrategiaCompraPerfilConcorrente do agente " + ag().nome());

		}	
		return false;
	}

/************************** findItemMelhor *****************************/
//quanto maior a avaliacao melhor
	public Item findItemMelhor(double avaliacaoMelhorAnterior)
	{
		double avaliacaoAtual,avaliacaoMelhor=0;
		Item itemMelhor=null,it=null;
		try
		{
			if(ag().listItens.size()>0)
			{
				itemMelhor = (Item)ag().listItens.elementAt(0);
				avaliacaoMelhor = itemMelhor.vetorCaracteristica.getValorCaracDouble("avaliacaoOferta");
			}
			for(int i=0;i<ag().listItens.size();i++)
			{
			
				it = (Item)ag().listItens.elementAt(i);
				avaliacaoAtual = it.vetorCaracteristica.getValorCaracDouble("avaliacaoOferta");
				
				//deve ser maior que a avaliacao atual e menor que a avaliacao anterior
				if (avaliacaoAtual > avaliacaoMelhor && avaliacaoAtual < avaliacaoMelhorAnterior)			
				{
					itemMelhor = it;
					avaliacaoMelhor = avaliacaoAtual;
				}
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no findItemMelhor da EstrategiaCompraPerfilConcorrente do agene "+ag().stringErro());
		}
		return itemMelhor;
	}
	
	
	
			
			/************************** OrdenaItens *****************************/		
/**O que tem maior avalia��o primeiro*/
	public void ordenaItensAvaliacao()
	{

		Item itAtual,it;
		int size = ag().listItens.size();
		double avalMelhor;
		int posMelhor;

		//deppois melhoro essa ordena��o		
		for(int i = 0; i<ag().listItens.size();i++)
		{
			itAtual = (Item)ag().listItens.elementAt(i);
			avalMelhor = itAtual.vetorCaracteristica.getValorCaracDouble("avaliacaoOferta");
			posMelhor = i;
			for(int j = i;j<ag().listItens.size();j++)
			{
				it = (Item)ag().listItens.elementAt(j);
				//se o item for maior insere nessa posi��o se n�o vai inserir mais pra baixo
				if (avalMelhor < it.somaAvaliacao())
				{			
					avalMelhor = it.vetorCaracteristica.getValorCaracDouble("avaliacaoOferta");
					posMelhor = j;
				}
			}
			it = (Item)ag().listItens.elementAt(posMelhor);
			ag().listItens.removeElementAt(i);			
			ag().listItens.insertElementAt(it,i);			
			ag().listItens.removeElementAt(posMelhor);			
			ag().listItens.insertElementAt(itAtual,posMelhor);			
		}
	}


	
/************************** analisaSituacaoItens *****************************/	
	public synchronized void analisaSituacaoItens()
	{//aqui que vem o racioc�nio
		try
		{
				
			AgenteCompra ag = (AgenteCompra)ag();	
			Item it= null,itemMelhor=null;
			double avaliacaoAtual,avaliacaoMelhor = 0;

			if(!ag.verificaRestricaoConfiguracaoOferta())//verifica na configura��o do agente se ele pode efetuar ofertas.
				return;				
	
			//for para analisar individualmente todos os itens. depois faz a avaliacao geral.
			for(int i=0;i<ag.listItens.size();i++)
			{
				it = (Item)ag.listItens.elementAt(i);

				if(it.vendido())
					continue;					
				avaliacaoAtual = this.analisaSituacaoItemIndividual(it);
				System.out.println(it.vetorCaracteristica.getValorCarac("codigo")+it.nome()+" Avaliacao:"+avaliacaoAtual);
			}
			boolean conseguiuOferta=false;
			double melhorAnterior = Double.MAX_VALUE; 
			
//			analisaSituacaoItemIndividual(it)	

			//ordena os itens pela avaliacao			
			ordenaItensAvaliacao();

			for(int i=0;i<ag.listItens.size() && !conseguiuOferta;i++)
			{
				if(it.vendido() )
					continue;					
			
				it = (Item)ag.listItens.elementAt(i);//findItemMelhor(melhorAnterior);
				conseguiuOferta = realizaOfertaItem(it);	
			}

		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no analisaSituacaoItens da EstrategiaCompraPerfilConcorrente do agene "+ag().stringErro());
		}

	}

//agora analisa para ver sobre qual leil�o vai realizar a oferta.  Essa an�lise ser� feita baseada na avalia��o do produto na atualidade.
	/************************** recebeMensagem *****************************/	
	public Mensagem recebeMensagem(Mensagem msg)
	{
		Mensagem mensagem = new Mensagem("","");
		try
		{
		
			if (msg.mensagem().equalsIgnoreCase("recebeReplyBuscaParticipanteIndividual"))
			{
				recebeReplyBuscaParticipanteIndividual(msg);
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no comeca da recebeMensagem EstrategiaCompraPerfilConcorrente do "+ag().nome());
		}
		return mensagem;
	}
}


/*
A estrategia, possui uma lista de VetorOfertas, que indica cada usu�rio e todas as suas ofertas.
Cada VetorOfertas todas as ofertas efetuadas pelo usu�rio aos produtos que o agente est� relacionado

*/

/* analisaSitua��o
		verificaRestricaoConfiguracaoOferta
		analisaSituacaoItemIndividual para cada item
			achaMomento
			achaValor
			verificaOponentes
	
		se tiver algum item 
			realizaOfertaItem
				modificaValorOfertaPerfilOponentes
				realiza a oferta mesmo.


*/