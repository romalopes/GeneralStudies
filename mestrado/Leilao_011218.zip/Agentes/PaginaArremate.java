/**classe P�ginas indica a p�gina que vamos entrar**/
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

public class PaginaArremate extends Pagina
{
	Socket m_socket;
	DataOutputStream m_out;
	
	
	public PaginaArremate(Agente ag) throws Exception 
	{
		super(ag);
		m_nome = "ARREMATE";
		m_base = "www.arremate.com.br";
	};

	public void buscaProdutoIndividual(String CodProd)
	{
	}
	public void registraLeilao()
	{
	};
	public void insereProduto()
	{
	};
	public void criaLeilao()
	{
	};
	public void fechaLeilao()
	{
	};
	public int prazo(Item it)
	{
		return 0;
	}
	public int tempoRestante(Item it)
	{
		return 0;
	}
	public int tempoRodando(Item it)
	{
		return 0;
	}
	/************************** IniciaBusca *****************************/	
	/**Inicia a busca para o Arremante.com */	
	public void IniciaBusca() 
	{
		try
		{
/*
			Socket s = new Socket("www.ole.com.br",80);
			DataInputStream in = new DataInputStream(s.getInputStream());
			DataOutputStream out = new DataOutputStream(s.getOutputStream());

			out.writeBytes("POST /cgi-bin/login.exe HTTP/1.0\n");
			out.writeBytes("Content-type: plain/text\n");
			out.writeBytes("Content-length: 25\n\n");
			out.writeBytes("login=emarques&");
			out.writeBytes("senha=4444");

			String site = "";
			while ((site = in.readLine()) != null)
			System.out.println(site);
			site = "";

			out.close();
			in.close();
			s.close();
*/
			
			m_socket = new Socket(m_base,80);
			
		    m_in= new BufferedReader(
						new InputStreamReader(m_socket.getInputStream()));
			m_out = new DataOutputStream(m_socket.getOutputStream());

			m_out.writeBytes("POST /accdb/search1.asp HTTP/1.0\n");
//			m_out.writeBytes("Content-type: plain/text\n");
			m_out.writeBytes("Content-type: html/text\n");
//			String s = String.valueOf(m_agente.produto().length()+10);
			String s = String.valueOf(8899);
			String stringTamanho = "Content-length: "+s+"\n\n";
			m_out.writeBytes(stringTamanho);
			m_out.writeBytes("txtsearch="+m_agente.nomeProduto());
//			m_out.writeBytes("Content-length: 17\n\n");
//			m_out.writeBytes(m_agente.produto());

 			//abre conex�o ...
/*		   HttpURLConnection m_siteConnection = ( HttpURLConnection )( new 
							URL( "accdb/search1.asp") ).openConnection();
		   m_siteConnection.setDoOutput( true );
		   m_siteConnection.setRequestMethod( "POST" );        // Configura conexao para envio de dados atraves do metodo POST
		   //escreve os par�metros
		   PrintWriter out;
		   out = new PrintWriter( m_siteConnection.getOutputStream() );
		   out.println( "txtsearch="+produto() );
		   out.close();
			//L� a p�gina de resultado
//			if(m_in!= null)
//				m_in.close();
//			m_in = new BufferedReader(m_siteConnection.getInputStreamReader()
//						new InputStreamReader(
//						m_siteConnection.openStream())
//						);
						
			StringBuffer line = new StringBuffer(5000);
			m_inputLine = new String(line);//s� pra garantir que a String ser� grande
*			*/
		}
		catch(IOException e)
		{
			System.out.println(e+ " Erro no IniciaBusca" );
		}			
	}
	
	/************************** finaliza a conex�o para a busca ************/
	public void finalizaConexao()
	{
		try
		{
			m_out.close();			
			m_in.close();
			m_socket.close();
		}
		catch(Exception e)
		{}
	
	}
	/************************** Busca *****************************/	
	/**faz a busca para o Arremate.com */	
	public Item Busca(String nomeProd)
	{
		Item item = null;		
		try
		{

			String string;
			int num = 0;
			FileWriter fw = new FileWriter("c:\\users\\anderson\\teste.htm");
			
			while ( (m_inputLine = m_in.readLine()) != null && num<5)
			{
				fw.write(m_inputLine);
				System.out.println (m_inputLine);
				int fromIndex = 0;
				int index = m_inputLine.indexOf("IDI=",fromIndex);
				if (index>0)
				{

					num++;
					
					//peaga o c�digo
					int fim,inic = index;					
					{
//						 inic +=4;						
						//peaga o c�digo
						fim = m_inputLine.indexOf("\">",inic);
						String codigoProd =  m_inputLine.substring(inic,fim);
						System.out.println ("\n\n*******************************\n*****"+codigoProd+"******\n\n*******************************");

						if ((m_inputLine = m_in.readLine()) != null)
						{
							//pega o nome do produto
//							for(inic = 0; m_inputLine.find(inic) == " ";inic++);
//							if(m_inputLine.getAt(inic) == "<")
//								m_inputLine = m_inputLine + 3;

							fim = m_inputLine.indexOf("</",inic);
							string =  m_inputLine.substring(inic,fim);
						
							System.out.println ("Nome = "+string);
						
							//seta o codigo e o nome
							//Cria o Item...
							item = new Item(string,agente(),this);
							item.vetorCaracteristica.setValorCarac("Codigo",String.valueOf(codigoProd));
							
						}
						else //se n�o conseguir retorna com null e l� fora para de buscar.
							return null;
							
						//pega e seta o pre�o
						while ((m_inputLine = m_in.readLine()) != null && (inic = m_inputLine.indexOf("<b>",0))<0)
						{
							inic += 6;
							fim = m_inputLine.indexOf("</b>",inic);					
							string =  m_inputLine.substring(inic,fim);
							System.out.println ("Pre�o = "+string);
//							item.setPreco(string);
						}							
							
						//pula o n�mero de lances j� feitos
						m_inputLine = m_in.readLine();
	
						//pega e seta o prazo
						if ((m_inputLine = m_in.readLine()) != null)
						{
							inic = m_inputLine.indexOf("center",0);
							inic += 8;
							fim = m_inputLine.indexOf("</td>",inic);
							fim = fim -2;
							string =  m_inputLine.substring(inic,fim);
							System.out.println ("Prazo = "+string);
							item.ConvertePrazoDataMinutos(string);
						}

						BuscaDetalhes(item);

					}		
				}
			}	
			fw.flush();
			fw.close();
		}
		catch(IOException e)
		{
			System.out.println(e+ " Erro no Busca do PagiaLokau" );
			return null;
		}			
		
		return item;
	}


	
	/************************** BuscaDetalhes *****************************/	/**faz a busca dos destalhes como descri��o e a foto para o lokau.com */
	private void BuscaDetalhes(Item item)//	throws Exception 
	{
		try
		{
			
			Socket socket = new Socket(base(),80);
			BufferedReader in= new BufferedReader(
						new InputStreamReader(m_socket.getInputStream()));
			DataOutputStream out = new DataOutputStream(socket.getOutputStream());

			out.writeBytes("POST /accdb/viewItem.asp HTTP/1.0\n");
			out.writeBytes("Content-type: plain/text\n");
//			String s = String.valueOf(item.codigo()+3);
//			String stringTamanho = "Content-length: "+s+"\n\n";
//			out.writeBytes(stringTamanho);
//			out.writeBytes("IDI="+item.codigo());
			

/*			//Abre a conex�o, para pegar os detalhes de cada produto(fotos e descricao)
			URL site = new URL(base()+"/accdb/viewItem.asp?IDI="+item.codigo());
			URLConnection siteConnection = site.openConnection();
			BufferedReader in = new BufferedReader(
						new InputStreamReader(
						site.openStream()));
*/			
			String inputLine;
			int fromIndex = 0;
			int fim,inic;

			while ((inputLine = in.readLine()) != null)
			{
				System.out.println (inputLine);

				//onde tiver uma figura � porque est� aqui.
				int index = inputLine.indexOf("jpg",0);
				if (index > 0)
				{
					fromIndex = 0;
					inic = inputLine.indexOf("src=\'",fromIndex);
					if ( inic > 0)
					{
						inic = inic+5;
						fim = inputLine.indexOf("\'",inic);
						String string =  inputLine.substring(inic,fim);
						System.out.println ("Figura = "+string);
						string = base() + string;
//						item.setCaminhoFigura(string);
						break;//sai do while antes de terminar a leitura
					}
				}
			}

			//pega a descri��o
			StringBuffer buffer = new StringBuffer(1000);		
			while ((inputLine = in.readLine()) != null)
			{
				inic = inputLine.indexOf("<br>",fromIndex);
				if (inic<0 && buffer.capacity() > inputLine.length())
				{
					buffer.append(inputLine);
				}
				else
					break;
			}
			System.out.println ("Descri��o = "+buffer.toString());
//			item.setDescricao(buffer.toString());
			
			
			out.close();
			in.close();
			socket.close();

		}
		catch(Exception e)
		{
			System.out.println("Erro em buscaDetalhes"+e);
		}
		
	}
	


	
	/************************** IniciaOferta *****************************/	
	/*********************************************************************/	
	public void IniciaOferta() 
	{
		try
		{
		
			//abre conex�o ...
			m_siteConnection = m_url.openConnection();
			if(m_in!= null)
				m_in.close();
//			m_in = new BufferedReader(
//						new InputStreamReader(
//						m_url.openStream()));
					
						
			StringBuffer line = new StringBuffer(5000);
			m_inputLine = new String(line);//s� pra garantir que a String ser� grande
			
		}
		catch(IOException e)
		{
			System.out.println(e+ " Erro no IniciaBusca" );
		}			
	}
	
	/************************** realizaOferta ****************************/
	/*********************************************************************/
	public boolean realizaOfertaItem(Item item,double valorOferta)
	{
		try
		{
			//abre conex�o ... e j� realiza a oferta.
//			m_url = new URL(base()+"pl/cadastralance?TVLLANC="+String.valueOf(item.valorOferta())+
//							"&TCODVEND="+item.codigo()+"&TUSERNAME="+item.agente().loginLokau()+
//							"&TSENHA="+item.agente().senhaLokau()+"&x=8&y=10");						
			m_siteConnection = m_url.openConnection();
			if(m_in!= null)
				m_in.close();
//			m_in = new BufferedReader(
//						new InputStreamReader(
//						m_url.openStream()));
					
			//s� pra garantir que a String ser� grande						
			StringBuffer line = new StringBuffer(5000);
			m_inputLine = new String(line);
			
			
			//verifica se a oferta foi aceita, se sim faz mais alguma coisa...
			
			
		}
		catch(Exception e)
		{
//			System.out.println("Erro no RealizaOferta do PaginaLokau para "+item.codigo() + " "+ e );
			return false;
 		}
		return true;
	}
}
