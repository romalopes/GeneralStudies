/**classe Final Agente de compra**/

import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;

/*
� uma estrat�gia.
Faremos v�rias classes de estrat�gias, todas filhas dessa.
//se fosse em C essa classe seria friend do agente, pois foi criada apenas para encapsular as funcoes de estrat�gia, e deve acessar tudo do agente.

Essa classe funciona tipo um pattern delegate, pois ela atua como se fosse parte do agente.

*/

abstract public class Estrategia implements Serializable
{


	abstract public double analisaSituacaoItemIndividual(Item it);
	abstract public void analisaSituacaoItens();
	abstract public Mensagem recebeMensagem(Mensagem msg);
	
	Agente m_agente;
	String m_tipo;

		
	public Estrategia(Agente ag)
	{
		try
		{
			m_agente = ag;	
			m_tipo = "";

		}
		catch(Exception e)
		{
			System.err.println(e+" Erro na Cria��o do Estrategia" );
		}
	}

	

	/****************************** writeObject **********************************/
	private void writeObject(java.io.ObjectOutputStream out)

	     throws IOException

	{
		try
		{
			out.writeObject(m_agente);	
			out.writeObject(m_tipo);
			out.flush();

		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write da Estrategia" );
		}
	}



/****************************** readObject **********************************/

	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_agente = (Agente)in.readObject();	
			m_tipo = (String)in.readObject();
		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read da Estrategia" );
		 }
	}

	public Agente ag()
	{
		return m_agente;
	}
	
	public String tipo()
	{
		return m_tipo;
	}


}