
import java.io.*;    //Package de classes para manipulacao de E/S
import java.net.*;   //Package de classes para manipulacao de Sockets, IP, etc.
import java.util.*;

import ClassesGeral.ObjetoEnviado;
import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

public class Usuario extends ObjetoEnviado implements Serializable
{
	private Vector m_listAgentesCompra;
	private Vector m_listAgentesLeiloeiro;
	private Vector m_listAgentesVenda;
	private String m_senha;
	private String m_email;


	public Usuario(String n)
	{
		super(n);
		m_senha = "";
		m_email = "";
		m_listAgentesCompra = new Vector();
		m_listAgentesLeiloeiro = new Vector();
		m_listAgentesVenda = new Vector();
	}

	public String printCaracteristicas()
	{
		return "nome:"+nome() ;
	}
	
/****************************** writeObject **********************************/
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{
			out.writeObject(m_senha);	
			out.writeObject(m_email);
			
			out.writeInt(m_listAgentesCompra.size());	
			int i;
			for(i=0;i<m_listAgentesCompra.size();i++)
			{
				AgenteCompra ag = (AgenteCompra)m_listAgentesCompra.elementAt(i);
				out.writeObject(ag);	
			}
			
			out.writeInt(m_listAgentesVenda.size());	
			for(i=0;i<m_listAgentesVenda.size();i++)
				out.writeObject((AgenteVenda)m_listAgentesVenda.elementAt(i));	
	
			out.writeInt(m_listAgentesLeiloeiro.size());	
			for(i=0;i<m_listAgentesLeiloeiro.size();i++)
				out.writeObject((AgenteLeiloeiro)m_listAgentesLeiloeiro.elementAt(i));	
	
			out.flush();	
		}
		catch(IOException e)
		{
			System.err.println(e+" Erro no read do Usuario");
		}
		
	}

/****************************** readObject **********************************/	
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{	 
			m_listAgentesCompra = new Vector();
			m_listAgentesLeiloeiro = new Vector();
			m_listAgentesVenda = new Vector();
		
			m_senha = (String)in.readObject();
			m_email = (String)in.readObject();

			//agente de compra
			m_listAgentesCompra.removeAllElements();
			int i,size = in.readInt();
			for(i=0;i<size;i++)
				m_listAgentesCompra.addElement((AgenteCompra)in.readObject());	

			//agente de venda
			m_listAgentesVenda.removeAllElements();
			size = in.readInt();
			for(i=0;i<size;i++)
				m_listAgentesVenda.addElement(in.readObject());	

			//agente leiloeiro
			m_listAgentesLeiloeiro.removeAllElements();
			size = in.readInt();
			for(i=0;i<size;i++)
				m_listAgentesLeiloeiro.addElement(in.readObject());	
		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no read do Usuario");
		}
	 }
	 
	//Agente Compra 
	public int sizeAgenteCompra()
	{
		return m_listAgentesCompra.size();
	}

	public AgenteCompra getAtAgenteCompra(int i)
	{
		return (AgenteCompra)m_listAgentesCompra.elementAt(i);
	}

	//Agente Venda
	public int sizeAgenteVenda()
	{
		return m_listAgentesVenda.size();
	}

	public AgenteVenda getAtAgenteVenda(int i)
	{
		return (AgenteVenda)m_listAgentesVenda.elementAt(i);
	}

	//Agente Leiloeiro
	public int sizeAgenteLeiloeiro()
	{
		return m_listAgentesLeiloeiro.size();
	}

	public AgenteLeiloeiro getAtAgenteLeiloeiro(int i)
	{
		return (AgenteLeiloeiro)m_listAgentesLeiloeiro.elementAt(i);
	}


	public String senha()
	{
		return m_senha;
	}
	
	public void senha(String s)
	{
		m_senha = s;
	}
	public String email()
	{
		return m_email;
	}
	
	public void setEmail(String e)
	{
		m_email = e;
	}
		
	

/********************* findAgente *************************************/
	public Agente findAgente(String nome)
	{
		if(nome == null)
			return null;
		Agente agente;
		for(int i=0;i<m_listAgentesCompra.size();i++)
		{
			 agente = (Agente)m_listAgentesCompra.elementAt(i);
			if(agente.nome().equalsIgnoreCase(nome))
			   return agente;
		}
		for(int i=0;i<m_listAgentesVenda.size();i++)
		{
			agente = (Agente)m_listAgentesVenda.elementAt(i);
			if(agente.nome().equalsIgnoreCase(nome))
			   return agente;
		}
		for(int i=0;i<m_listAgentesLeiloeiro.size();i++)
		{
			agente = (Agente)m_listAgentesLeiloeiro.elementAt(i);
			if(agente.nome().equalsIgnoreCase(nome))
			   return agente;
		}
		return null;
	}
	
/********************* existeAgentes *************************************/	
	public boolean existeAgentes()
	{
		if(m_listAgentesCompra.size()>0 || m_listAgentesLeiloeiro.size()>0
		 || m_listAgentesVenda.size()>0)
			return true;
		return false;	
	}


/********************* removeAgente ***************************/
	public boolean removeAgente(String nome) 
		throws IOException
	{
		try
		{
			if(nome == null)
				return false;
			Agente agente;
			for(int i=0;i<m_listAgentesCompra.size();i++)
			{
				 agente = (Agente)m_listAgentesCompra.elementAt(i);
				if (agente.nome().equalsIgnoreCase(nome))
				{
				   m_listAgentesCompra.removeElementAt(i);
   				   return true;   
				}
			}
			for(int i=0;i<m_listAgentesVenda.size();i++)
			{
				agente = (Agente)m_listAgentesVenda.elementAt(i);
				if(agente.nome().equalsIgnoreCase(nome))
				{
				   m_listAgentesVenda.removeElementAt(i);
   				   return true;   
				}
			}
			for(int i=0;i<m_listAgentesLeiloeiro.size();i++)
			{
				agente = (Agente)m_listAgentesLeiloeiro.elementAt(i);
				if(agente.nome().equalsIgnoreCase(nome))
				{
				   m_listAgentesLeiloeiro.removeElementAt(i);
   				   return true;   
				}
			}
		}
		catch(Exception e)
		{
			System.err.println(e+ " Erro no removeAgente do Usuario");
		}
				
		return false;
	}

/********************* criaAgenteCompra *************************************
	public AgenteCompra criaAgenteCompra(String nome)
	{
		AgenteCompra agente;
		if(findAgente(nome) != null)
			return null;

		agente = new AgenteCompra(nome(),nome);
		System.out.println("Agente Criado "+ agente.nome() );
			
		System.out.println("email:"+email());
		agente.setEmail(email());
		m_listAgentesCompra.addElement(agente);	
		agente.appendHistoria("Agente Criado com nome "+ agente.nome()+" Tipo:"+agente.tipo());
		return agente;
	}
/********************* criaAgenteVenda *************************************
	public AgenteVenda criaAgenteVenda(String nome)
	{
		AgenteVenda agente;
		if(findAgente(nome) != null)
			return null;

		agente = new AgenteVenda(nome(),nome);
		m_listAgentesCompra.addElement(agente);	
		
		System.out.println("email:"+email());
		agente.setEmail(email());
				
		System.out.println("Agente Criado "+ agente.nome() );
		agente.appendHistoria("Agente Criado com nome "+ agente.nome()+" Tipo:"+agente.tipo());
		return agente;
	}

/********************* criaAgenteLeiloeiro *************************************/
	public AgenteLeiloeiro criaAgenteLeiloeiro(String nomeAgente,String tipoLeiloeiro,Gerente gerente)
	{
		AgenteLeiloeiro agente= null;	
		try
		{
			if(findAgente(nomeAgente) != null)
				return null;
			System.out.println(tipoLeiloeiro);
			if (tipoLeiloeiro.equalsIgnoreCase("aconselhador"))
			{
				agente = new AgenteLeiloeiroAconselhador(nome(),nomeAgente,gerente);		
			}
			else if (tipoLeiloeiro.equalsIgnoreCase("juntador"))
			{
				agente = new AgenteLeiloeiroJuntador(nome(),nomeAgente,gerente);		
			}
			else 
			{
				System.err.println("N�o existe esse tipo de Leiloeiro: "+tipoLeiloeiro);
				return agente;
//				throw();		
			}

			agente.setEmail(email());	
			System.out.println("Agente Criado "+ agente.nome() );
			agente.appendHistoria("Agente Criado com nome "+ agente.nome()+" Tipo:"+agente.tipo());
			return agente;
		}
		catch(Exception e)
		{
			System.err.println(e+"Erro no criaAgente Leiloeiro do Usuario"+nome());
		}
		return agente;
	}
	
/********************* removeAgente ***************************/	
public Agente criaAgenteMensagem(String nomemsg,Gerente gerente)
{
	try
	{
		String nomeAgente,nomeProduto;
		Agente agente = null;
	
		//1=tipoAgente,1=nomeAgente ,
		String tipoAgente = Enviador.pegaParte(nomemsg,0,',');
		nomeAgente = Enviador.pegaParte(nomemsg,1,',');

		if(findAgente(nomeAgente) != null)
			return null;

		if(tipoAgente.equalsIgnoreCase("compra"))
		{
		
//			nomeProduto = Enviador.pegaParte(nomemsg,2,',');
			agente = new AgenteCompra(nome(),nomeAgente);
			if(agente == null)
				return null;
			m_listAgentesCompra.addElement(agente);	
			
			agente.setEmail(email());
			agente.appendHistoria("Agente de Compra Criado com nome "+ agente.nome()+" Tipo:"+agente.tipo());
			
//			agente.setNomeProduto(nomeProduto);
			
		}
		else if(tipoAgente.equalsIgnoreCase("venda"))
		{
//			nomeProduto = Enviador.pegaParte(nomemsg,2,',');
			agente = new AgenteVenda(nome(),nomeAgente);
			if(agente == null)
				return null;
			m_listAgentesVenda.addElement(agente);	
			
			agente.setEmail(email());
				

			agente.appendHistoria("Agente de venda Criado com nome "+ agente.nome()+" Tipo:"+agente.tipo());
			
//			agente.setNomeProduto(nomeProduto);
		}
		else if(tipoAgente.equalsIgnoreCase("aconselhador") || tipoAgente.equalsIgnoreCase("juntador"))
		{

			agente = criaAgenteLeiloeiro(nomeAgente,tipoAgente,gerente);
			if(agente == null)
				return null;		
			m_listAgentesLeiloeiro.addElement(agente);	
			
//			int i=3;
//			nomeProduto = Enviador.pegaParte(nomemsg,i,',');
//			String nomesProdutos = "";
//			while (!nomeProduto.equals(""))
//			{
//				nomesProdutos += nomeProduto+",";
//				i++;
//				nomeProduto = Enviador.pegaParte(nomemsg,i,',');
//			}
//			agente.setNomeProduto(nomesProdutos);
		}		

		System.out.println("Agente Criado nome:"+ agente.nome()+"Tipo:"+agente.tipo());		
		agente.appendHistoria("Agente Criado nome:"+ agente.nome()+" Tipo:"+agente.tipo());

		return agente;
	}
	catch(Exception e)
	{
		System.err.println(e+"Erro no criaAgenteMensagem do Usuario");
	
	}
	return null;
}
	
	////////////////////////////recebeAvisoRelogio()////////////////
	//Recebe o aviso do relogio que se passaram 1 min e repassa ao usu�rio 
	//para que ele repasse aos seus agentes.
	public synchronized void recebeAvisoRelogio()
	{
		
	
	// print out a bunch of interesting things
		System.out.println("Usuario Avisado :"+nome());
		//		Escrever a Data.
		int i,size = m_listAgentesCompra.size();
		Agente ag;
		for(i = 0;i<size;i++)
		{
			ag = (Agente)m_listAgentesCompra.elementAt(i);
			ag.setAvisoRelogio(true);

		}
		size = m_listAgentesVenda.size();
		for(i = 0;i<size;i++)
		{
			ag = (Agente)m_listAgentesVenda.elementAt(i);
			ag.setAvisoRelogio(true);
		}
		size = m_listAgentesLeiloeiro.size();
		for(i = 0;i<size;i++)
		{
			ag = (Agente)m_listAgentesLeiloeiro.elementAt(i);
			ag.setAvisoRelogio(true);
		}
	}


	
}

