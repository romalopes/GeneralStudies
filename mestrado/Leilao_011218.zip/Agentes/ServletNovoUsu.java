import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

//Servlet para login
public class ServletNovoUsu extends HttpServlet 
{
	String m_usrlogin;	
	String usrsenha;
	String email_usuario;
    public void init(ServletConfig servletConfig) throws ServletException
  {
	    super.init(servletConfig);
  }


	public void printOk(HttpServletRequest request,
						HttpServletResponse response)
	throws ServletException, IOException 

	{
	    // Set the attribute and Forward to usuariologado.jsp
		String caminho = "/jsp/usuariologado.jsp";
//	    request.setAttribute ("nomeUsuario", m_usrlogin);
	    getServletConfig().getServletContext().getRequestDispatcher(caminho).forward(request, response);

//		response.sendRedirect("/agile/jsp/resultadobusca.jsp?nomeUsuario="+m_usrlogin+"&nomeAgente="+usrsenha);
	}
	

	public void printFalha(HttpServletResponse response)
	throws ServletException, IOException 

	{
		response.setContentType("text/html");
    	PrintWriter out = response.getWriter();
    	String title = "Login Falha";
		out.println("<html>");
		out.println("<head><title>Login Falha</title></head>");
		out.println("<BODY BGCOLOR=\"#FDF5E6\">\n" +
                "<h1 ALIGN=CENTER>" + title + "</h1>\n" +
                "<TABLE BORDER=1 ALIGN=CENTER>\n" +
                "<TH>Nome rejeitado" );
		out.println("</body></html>");
	}

	public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
    throws ServletException, IOException 
	{    
//     	doGet(request, response);  
        m_usrlogin = request.getParameter("nomeUsuario");
		usrsenha = request.getParameter("senha_usuario");
	    email_usuario = request.getParameter("email_usuario");
		
		String ip = request.getRemoteAddr();    	
		Mensagem Msg = new Mensagem(m_usrlogin,ip);
		Msg.setMensagem("NovoUsuario");
		Msg.setMensagemAux(usrsenha);

		System.out.println("Cria Usuario ****************************************************************************************************************");
		
		Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
      	Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);
/**********************************************/
		
		
        if (Msg.mensagemRetorno())
        {
			System.out.println("\nRetornou do Cria Usuario ******** ROMA **************");
        	printOk(request,response);

        }
        else
        {
        	printFalha( response);
        }
	}
}