import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;


public class Recebedor
{
	public Recebedor(){};

  
	static public ObjetoEnviado RecebeMensagem(int portaDefault)
	{
		ObjetoEnviado Msg = null ;
        /* --- constante --- */

//        final int portaDefault = 8082;    // porta inicial default
         /* --- variaveis --- */
        int backlog = 5;                 // tamanho da fila de requisicoes

       
        /* --- objetos sockets --- */

		ServerSocket socketServidor = null;
		Socket clienteSocket = null;
		OutputStream os = null;
		ObjectOutputStream dos = null;
		ObjectInputStream is = null;

        /* --- associacao da porta utilizada pelo servidor --- */
		try
		{
        	socketServidor = new ServerSocket(portaDefault, backlog);
       
        	System.out.println ("\nObjeto ativado. " + 
                            "Aguardando mensagens na porta " + portaDefault + "...\n"+
								socketServidor.getLocalPort());
		}
		catch(Exception e) 
		{
			System.out.println ("\nPorta n�o pode ser liberada\n"+ portaDefault + e);
		}
		
        clienteSocket = null;
        try 
        {
	 	        System.out.println ("\nObjeto Espera alguma coisa...\n");
                clienteSocket = socketServidor.accept();  // listen() + accept()
        } 
        catch (IOException e) 
        {
			System.out.println ("\nObjeto nao recebeu direito\n");
			System.err.println("Erro de E/S " + e);
			System.exit(1);
		}     
		try 
		{
			System.out.println ("\nServidor Recebe alguma coisa...\n");
			os = clienteSocket.getOutputStream();
		    dos = new ObjectOutputStream (os);
		    is = new ObjectInputStream(clienteSocket.getInputStream());

		    Msg = (ObjetoEnviado)is.readObject(); 

		    dos.flush();	

		    os.flush();           
		    dos.close();
		    os.close();
	        is.close();
		    clienteSocket.close();
		    socketServidor.close();
		   	
		   	return Msg;
		}
		catch (Exception e) 
	  	{
	  		System.out.println("Erro no Recebedor"); 
	  	}
	  	return Msg;
	}
}	  	