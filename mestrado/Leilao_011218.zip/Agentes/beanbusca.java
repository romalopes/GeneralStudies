import java.io.*;
import java.util.*;
import java.net.*;
import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

public class beanbusca extends BeanGeral
{
	private String lokau;
	private String arremate;

	public beanbusca()
	{
		lokau = null;
	}
	
	public void setLokau(String l)
	{
		lokau = l;
	}
	
	public String getLokau()
	{
		return lokau;
	}
	
	public void setArremate(String l)
	{
		arremate = l;
	}
	
	public String getArremate()
	{
		return arremate;
	}
	
	 
//	
	public String processa(String s)
	{
		Mensagem Msg = new Mensagem(getNomeUsuario(),getIP());
		Msg.setMensagem("busca");
		Msg.setMensagemAux(getNomeAgente()+s);
		Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
		
		//nem precisava retornar o agente...
     	Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);
		return "OK";	
	}

}
