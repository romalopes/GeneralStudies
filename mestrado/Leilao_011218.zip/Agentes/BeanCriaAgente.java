import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;


public class BeanCriaAgente extends BeanGeral
{
	private String mensagem = "";	
	private String mensagemAux = "";
	

	public void setMensagem(String m)
	{
		mensagem = m;
	}
	public String getMensagem()
	{
		return mensagem;
	}

	public void setMensagemAux(String m)
	{
		mensagemAux = m;
	}
	public String getMensagemAux()
	{
		return mensagemAux;
	}
	
	public String processa()
	{
//		System.out.println("Procesando BeanCriaAgente:" + mensagem + " "+getNomeUsuario());
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(getNomeUsuario(),Inet.getHostAddress());
			//AINDA n�o estou passando o password.
			Msg.setMensagem(mensagem);
			Msg.setMensagemAux(mensagemAux);
			Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
			Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);			
			
			return Msg.mensagemAux();
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
				return "Erro na conex�o";
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanCriaAgente Exception:  " + e);
			return "Erri no processamento";	
		}
	}
}
