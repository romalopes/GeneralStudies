import java.io.*;
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;


public class BeanSalvarAbrir 
{
	private String nomeUsuario;
	private String arquivo;
	private String tipo;

	public void setNomeUsuario(String u)
	{
		nomeUsuario = u;
	}
	
	public String getNomeUsuario()
	{
		return nomeUsuario;
	}
	
	public void setArquivo(String a)
	{
		arquivo = a;
	}
	
	public String getArquivo()
	{
		return arquivo;
	}
	public void setTipo(String t)
	{
		tipo = t;
	}
	
	public String getTipo()
	{
		return tipo;
	}

	
	public boolean processa()
	{
	
		Mensagem Msg = new Mensagem(getNomeUsuario(),"");
		Msg.setMensagem(tipo);

		Msg.setMensagemAux(getArquivo());
		
		Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
		
		//nem precisava retornar o agente...
	 	Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);
		return Msg.mensagemRetorno();
	}
	

}
