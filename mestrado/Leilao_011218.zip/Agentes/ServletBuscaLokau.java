import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

//Acho que essa class morreu...


//Servlet para login
public class ServletBuscaLokau extends HttpServlet 
{
    public void init(ServletConfig servletConfig) throws ServletException
    {
	    super.init(servletConfig);
    }
	
		public void printOk(HttpServletResponse response)
	throws ServletException, IOException 

	{		
		response.setContentType("text/html");
    	PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head><title>Tela principal</title>"+
					"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">" +
					"</head> <body bgcolor=\"#FFFFFF\"> <hr> " +
					"<h1> Usu�rio  Cadastrado </h1>" +
					"<p><a href=\"/agile/criacao_agente.htm\">Criar Agente</a></p>" +
					"<p>&nbsp;</p>  <p>Visualizar agentes</p> \n <hr>" +
					"<p>&nbsp;</p>  <p>Remover Agente</p>  <hr>\n" +
					"<p>&nbsp; </p> <p>&nbsp;</p> <p>&nbsp;</p> \n </body> \n </html>");
					
//		<INPUT TYPE="hidden" NAME="nome_oculto" VALUE="form12">
				


		//aqui ou deveria fazer na ra�a ou poderia chamar um jsp, passando uns parametros
//		response.sendRedirect("/agile/principal.htm");
	}
	
	public void printAceito(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException 

	{
		response.setContentType("text/html");
    	PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head><title>Tela principal</title>"+
					"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">" +
					"</head> <body bgcolor=\"#FFFFFF\"> <hr> " +
					"<h1> Usu�rio  Aceito </h1>" +
					"<h1> Nome  </h1>" +
					"<p><a href=\"/agile/criacao_agente.htm\">Criar Agente</a></p>" +
					"<p>&nbsp;</p>  <p>Visualizar agentes</p> \n <hr>" +
					"<p>&nbsp;</p>  <p>Remover Agente</p>  <hr>\n" +
					"<p>&nbsp; </p> <p>&nbsp;</p> <p>&nbsp;</p> \n </body> \n </html>");
		
				
		//aqui ou deveria fazer na ra�a ou poderia chamar um jsp, passando uns parametros
//		response.sendRedirect("/agile/principal.htm");
	}

	
	public void printFalha(HttpServletResponse response)
	throws ServletException, IOException 

	{
		response.setContentType("text/html");
    	PrintWriter out = response.getWriter();
    	String title = "Login Falha";
		out.println("<html>");
		out.println("<head><title>Login Falha</title></head>");
		out.println("<BODY BGCOLOR=\"#FDF5E6\">\n" +
                "<h1 ALIGN=CENTER>" + title + "</h1>\n" +
                "<TABLE BORDER=1 ALIGN=CENTER>\n" +
                "<TH>Nome rejeitado" );
		out.println("</body></html>");
	}
	public void doPost(HttpServletRequest request,
                   HttpServletResponse response)
    throws ServletException, IOException 

	{    
		try
		{
			String nomeUsuario = (String)request.getParameter("nomeUsuario");
	 		String nomeAgente = (String)request.getParameter("nomeAgente");
//			String m_palavrasChave = URLDecoder.decode((String)request.getParameter("produto"));
			String m_palavrasChave = (String)request.getParameter("produto");			

			Mensagem Msg = new Mensagem(nomeAgente,request.getRemoteAddr());
			Msg.setMensagem("busca");
			Msg.setMensagemAux("lokau");
			
			Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);

			Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);

			String caminho = "/jsp/okbuscou.jsp";
			request.setAttribute ("m_nomeAgente", nomeUsuario);
			request.setAttribute ("m_nomeAgente", nomeAgente);
			request.setAttribute ("produto", m_palavrasChave);
			
			getServletConfig().getServletContext().getRequestDispatcher(caminho).forward(request, response);
			
		}
		catch(Exception e)
		{
			System.out.print(e + " Erro no ServletBuscaLokau");
		}

	}
}