//import java.io.*;
//import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

public class BeanPegaAgentes extends BeanGeral
{
	Usuario m_usuario;
	Agente m_agente;
	String m_arquivo;


	public Agente agente(String nome)
	{
		m_agente =  m_usuario.findAgente(nome);
		return m_agente;
	}
	
	public String getArquivo()
	{
		return m_arquivo;
	}
	public void setArquivo(String a)
	{
		m_arquivo = a;
	}

	public String historia()
	{
		String stringHistoria,stringAtual,stringTela;
		int i;
			
		StringBuffer stringBuffer = new StringBuffer(1000);
		stringHistoria = m_agente.historia();

		stringBuffer.append("<div id=\"Historia\" style=\"position:absolute; width:500px; height:115px; z-index:6; left: 155px; right: 255px; top: 120px\">");
		stringBuffer.append("<table width=\"75%\" border=\"2\">");
		stringBuffer.append("<tr>"); 
		stringBuffer.append("<td width=\"80%\">"); 
		stringBuffer.append("<div align=\"center\">A��o</div></td>");
		stringBuffer.append("<td width=\"20%\">"); 
		stringBuffer.append("<div align=\"center\">Data</div></td>");
		stringBuffer.append("</tr>");

		i=0;
		stringAtual = Enviador.pegaParte(stringHistoria,i,';');
		while(stringAtual .equals("") == false)
		{
			stringBuffer.append("<tr>\n");
			stringBuffer.append("<td width=\"80%\">\n");			
			stringBuffer.append("<div align=\"left\">" +stringAtual+ "</a></div></td>\n");
			i++;
			stringAtual = Enviador.pegaParte(stringHistoria,i,';');			
			stringBuffer.append("<td width=\"20%\">"+stringAtual+"</td>"); 
			stringBuffer.append("</tr>\n");						
			stringBuffer.append("\n");						
		
			i++;
			stringAtual = Enviador.pegaParte(stringHistoria,i,';');
		}
		
		stringBuffer.append("</table>");
		stringBuffer.append("</div>");						
		return stringBuffer.toString();
	}

	//imprime Agente, pode ser para remover ou simplesmente mostrar
		//setArquivo("VerificaAgente.jsp");
//		ou setArquivo("RemoveAgente.jsp");
	public String imprimeAgentes()
	{
	
		StringBuffer stringBuffer = new StringBuffer();
		try
		{
			stringBuffer.append("<div id=\"Layer1\" style=\"position:absolute; width:200px; height:115px; z-index:1; left: 165px; top: 148px\">"); 
			stringBuffer.append("<table width=\"63%\" border=\"2\">");
			stringBuffer.append("<tr>"); 
	        stringBuffer.append("<td width=\"21%\" height=\"43\">"); 
	        stringBuffer.append("<div align=\"left\">Agente</div>");
	        stringBuffer.append("</td>");
	        stringBuffer.append("<td width=\"18%\" height=\"43\">Tipo</td>");
	        stringBuffer.append("<td width=\"37%\" height=\"43\">Produto</td>");
	        stringBuffer.append("<td width=\"37%\" height=\"43\">Trabalhando</td>");
			stringBuffer.append("</tr>");
	  			
				
			if (m_usuario == null)					
				System.out.println("usuario Null");
			else
				System.out.println("achou usuario em imprimeAgentes "+m_usuario.nome());
			
			
			AgenteCompra agCompra;
			int i,size = m_usuario.sizeAgenteCompra();
			for(i=0;i<size;i++)
			{
				agCompra = m_usuario.getAtAgenteCompra(i);

				stringBuffer.append("<tr>\n");
				stringBuffer.append("<td width=\"21%\" height=\"31\">\n");			
				stringBuffer.append("<div align=\"left\"> <a href=\"/agile/jsp/"+getArquivo()+"?nomeUsuario="+getNomeUsuario()+"&nomeAgente="+agCompra.nome()+"&tipoAgente="+agCompra.tipo()+"&trabalhando="+agCompra.TrabalhandoString()+"&nomeProduto="+agCompra.nomeProduto()+"\">" +agCompra.nome()+ "</a></div></td>\n");
				stringBuffer.append("<td width=\"18%\" height=\"31\">"+agCompra.tipo()+"</td>\n");
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+agCompra.nomeProduto()+"</td>\n");			
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+agCompra.TrabalhandoString()+"</td>\n");			
				stringBuffer.append("</tr>\n");						
				stringBuffer.append("\n");						
			}
			
			AgenteVenda agVenda;
			size = m_usuario.sizeAgenteVenda();
			for(i=0;i<size;i++)
			{
				agVenda = m_usuario.getAtAgenteVenda(i);

				stringBuffer.append("<tr>\n");
				stringBuffer.append("<td width=\"21%\" height=\"31\">\n");			
				stringBuffer.append("<div align=\"left\"> <a href=\"/agile/jsp/"+getArquivo()+"?nomeUsuario="+getNomeUsuario()+"&nomeAgente="+agVenda.nome()+"&tipoAgente="+agVenda.tipo()+"&trabalhando="+agVenda.TrabalhandoString()+"&nomeProduto="+agVenda.nomeProduto()+"\">" +agVenda.nome()+ "</a></div></td>\n");
				stringBuffer.append("<td width=\"18%\" height=\"31\">"+agVenda.tipo()+"</td>\n");
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+agVenda.nomeProduto()+"</td>\n");			
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+agVenda.TrabalhandoString()+"</td>\n");			
				stringBuffer.append("</tr>\n");						
				stringBuffer.append("\n");						
			}
			
			AgenteLeiloeiro agLeiloeiro;
			size = m_usuario.sizeAgenteLeiloeiro();
			for(i=0;i<size;i++)
			{
				agLeiloeiro = m_usuario.getAtAgenteLeiloeiro(i);

				stringBuffer.append("<tr>\n");
				stringBuffer.append("<td width=\"21%\" height=\"31\">\n");			
				stringBuffer.append("<div align=\"left\"> <a href=\"/agile/jsp/"+getArquivo()+"?nomeUsuario="+getNomeUsuario()+"&nomeAgente="+agLeiloeiro.nome()+"&tipoAgente="+agLeiloeiro.tipo()+"&trabalhando="+agLeiloeiro.TrabalhandoString()+"&nomeProduto="+agLeiloeiro.nomeProduto()+"\">" +agLeiloeiro.nome()+ "</a></div></td>\n");
				stringBuffer.append("<td width=\"18%\" height=\"31\">"+agLeiloeiro.tipo()+"</td>\n");
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+agLeiloeiro.nomeProduto()+"</td>\n");			
				stringBuffer.append("<td width=\"37%\" height=\"31\">"+agLeiloeiro.TrabalhandoString()+"</td>\n");			
				stringBuffer.append("</tr>\n");						
				stringBuffer.append("\n");						
			}
			stringBuffer.append("</table>");
			stringBuffer.append("</div>");
		}
		catch (Exception e) 
		{
			System.err.println("Erro o imprimeAgentes do BeanPegaAgentes Exception:  " + e);
			return stringBuffer.toString();
		}


			return stringBuffer.toString();
	}

	public boolean processa()
	{
		System.out.println("Procesando BeanPegaAgentes");
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(getNomeUsuario(),Inet.getHostAddress());
			//AINDA n�o estou passando o password.
			Msg.setMensagem("PegaUsuario");
			
//			Msg.setMensagemAux(valor);
			Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
			m_usuario = (Usuario)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);			
			System.out.println("Retornou PegaUsuario *********" + m_usuario);
			if (m_usuario == null) 
				return false;
			
			agente(getNomeAgente());
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanPegaAgentes Exception:  " + e);
		}
		return true;		
	}
}
