/**classe Final EstrategiaCompraSimples**/

import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;

/**
� uma estrat�gia.
Faremos v�rias classes de estrat�gias, todas filhas dessa.
//Essa estrat�gia � a mais burrinha, pois somente verifica se os valores est�o dentro do esperados, e se tiverem efetua a oferta.
//
*/

public class EstrategiaCompraSimples extends Estrategia
{


	public EstrategiaCompraSimples(AgenteCompra ag)
	{
		super(ag);
		try
		{	

		}
		catch(Exception e)
		{
			System.err.println(e+" Erro na Cria��o do Estrategia" );
		}
	}

	

	/****************************** writeObject **********************************/
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{
			out.writeObject(m_agente);	
			out.flush();
		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write da Estrategia" );
		}
	}



/****************************** readObject **********************************/

	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_agente = (AgenteCompra)in.readObject();	
		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read da Estrategia" );
		 }
	}

/*********************** analisaSituacaoItemIndividual ***********************/	
	public double analisaSituacaoItemIndividual(Item it)
	{
		AgenteCompra ag = (AgenteCompra)ag();
		try
		{
			int size = it.vetorOfertas.size();
			if (size > 0)
			{
				Oferta oferta = (Oferta)it.vetorOfertas.elementAt(size - 1);	
				if(oferta != null )
					if(ag.nomeUsuarioPagina().equalsIgnoreCase(oferta.nomeUsuario()))
						return 0;//o vencedor atual � o pr�prio agente
			}				
			double valorAtual = it.vetorCaracteristica.getValorCaracDouble("valorAtual");
			Pagina pag = ag.findPagina(it.pagina().nome());
			if (pag == null)
			{
				System.err.println("P�gina n�o existe no item:"+it.vetorCaracteristica.getValorCarac("codigo")+"  "+it.vetorCaracteristica.getValorCarac("nomeDono"));
				return 0;
			}
			
			double precoMax = ag().vetorCaracteristica.getValorCaracDouble("precoMax");
			
			double menorDiferenca = it.vetorCaracteristica.getValorCaracDouble("menordiferenca");
			
			double valorOferta = valorAtual + menorDiferenca;
			
			//pegou o pre�o maximo mas vai verificar atrav�s da avalia��o qual o precoMaximo aceito para o item.
//			precoMax = precoMax*it.somaAvaliacao();
			System.out.println("nomeProduto:"+it.vetorCaracteristica.getValorCarac("nomeProduto")+" valorAtual:"+valorAtual+ " precoMax:"+precoMax+" valorOferta:"+valorOferta+" menordiferencaOferta:"+menorDiferenca);						
			if (valorOferta <=  precoMax )
			{
				ag.realizaOfertaItem(it,valorOferta);	
			}
			else
			{
				StringBuffer buf = new StringBuffer(500);
				
				buf.append("Achei melhor n�o efetuar a oferta sobre produto:"+it.vetorCaracteristica.getValorCarac("codigo"));
				buf.append("\n, o valor estimado por mim nesse momento seria:"+String.valueOf(valorOferta)+", e o valor minimos para oferta �:"+String.valueOf(valorAtual+menorDiferenca)); 
//				buf.append(".  O momento ideal para mim seria:"+String.valueOf(tempoOferta)+", e o tempo de trabalho at� agora �:"+String.valorOf(tempoTrabalho));
				ag.appendHistoria(buf.toString());
				
			}
		}
		catch(Exception e)
		{
			System.err.println ("\nErro no analisaSituacaoItemIndividual do Agente de compra :"+ag().nome() + e);
		}
		return 0;
	}

/************************** analisaSituacaoItens *****************************/	
	public synchronized void analisaSituacaoItens()
	{//aqui que vem o racioc�nio
		Item it;
		
		AgenteCompra ag = (AgenteCompra)ag();
		if(!ag.verificaRestricaoConfiguracaoOferta())
			return;
			
		for(int i=0;i<ag().listItens.size();i++)
		{
			it = (Item)ag().listItens.elementAt(i);
			System.out.println(it.nome());
			if(it.vendido())
				continue;
			this.analisaSituacaoItemIndividual(it);
		}
	}
	
	public Mensagem recebeMensagem(Mensagem msg)
	{
		return null;
	}

}