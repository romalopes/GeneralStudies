/**classe P�ginas indica a p�gina que vamos entrar**/
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

import ClassesGeral.VetorCaracteristica;
import ClassesGeral.Caracteristica;

abstract class Pagina extends Object implements Serializable
{
	URL m_url;
	Agente m_agente;
	String m_base;
	URLConnection m_siteConnection;
	BufferedReader m_in;
	String m_inputLine;
	String m_nome;
	boolean m_registrado;
	boolean m_produtoInserido;
	boolean m_leilaoCriado;
	boolean m_biniciaBusca;
	VetorCaracteristica vetorCaracteristica;
	String m_login;
	String m_senha;

	
	abstract public void registraLeilao();	
	abstract public void insereProduto();
	abstract public void criaLeilao();
	abstract public void fechaLeilao();
	
	abstract public void IniciaBusca();
	abstract public Item Busca(String nomeProd);
	abstract public void buscaProdutoIndividual(String CodProd);
	abstract public boolean realizaOfertaItem(Item it,double valorOferta);
	abstract public void finalizaConexao();
	abstract public int tempoRestante(Item it);
	abstract public int tempoRodando(Item it);
	abstract public int prazo(Item it);
	public Pagina(Agente ag) throws Exception 
	{
		m_agente = ag;
		vetorCaracteristica = new VetorCaracteristica();
	}
	
		/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{
			out.writeObject(m_url);
			out.writeObject(m_agente);
			out.writeObject(m_nome);			
			out.writeObject(m_base);
			out.writeBoolean(m_registrado);
			out.writeBoolean(m_produtoInserido);
			out.writeBoolean(m_leilaoCriado);
			out.writeBoolean(m_biniciaBusca);
			out.writeObject(m_login);
			out.writeObject(m_senha);
			int i;
			out.writeInt(vetorCaracteristica.size());
			for(i=0;i<vetorCaracteristica.size();i++)
				out.writeObject(vetorCaracteristica.elementAt(i));	
			
			out.flush();
		}	
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do Pagina" );
		}			
	}
	
/****************************** readObject **********************************/		
	private void readObject(java.io.ObjectInputStream in)  
		throws IOException, ClassNotFoundException
	{
		try
		{
		
			m_url		=  (URL)in.readObject();
			m_agente	=  (Agente)in.readObject();						
			m_nome 		=  (String)in.readObject();
			m_base		=  (String)in.readObject();
			m_registrado = in.readBoolean();
			m_produtoInserido = in.readBoolean();
			m_leilaoCriado = in.readBoolean();
			m_biniciaBusca = in.readBoolean();
			m_login = (String)in.readObject();
			m_senha = (String)in.readObject();
			
			vetorCaracteristica = new VetorCaracteristica();
			int i,size = in.readInt();
			for(i=0;i<size;i++)
				vetorCaracteristica.addElement(in.readObject());
			
		}
		catch(IOException e)
		{
			System.err.println(e+" Erro no read do Pagina" );
		}
	}
	 

	public void setRegistrado(boolean r)
	{
		 m_registrado = r;
	}
	public boolean registrado()
	{
		return m_registrado;
	}
	public void setLogin(String l)
	{
		 m_login = l;
	}
	public String login()
	{
		return m_login;
	}
	public void setSenha(String s)
	{
		 m_senha = s;
	}
	public String senha()
	{
		return m_senha;
	}		
	
	public void setProdutoInserido(boolean pi)
	{
		 m_produtoInserido = pi;
	}
	public boolean produtoInserido()
	{
		return m_produtoInserido;
	}

	public void setLeilaoCriado(boolean pi)
	{
		 m_leilaoCriado = pi;
	}
	public boolean leilaoCriado()
	{
		return m_leilaoCriado;
	}		
	
	public void setIniciaBusca(boolean b)
	{
		 m_biniciaBusca = b;
	}
	public boolean biniciaBusca()
	{
		return m_biniciaBusca;
	}		
	
	
	public String base()
	{
		return m_base;
	}
	public String nome()
	{
		return m_nome;
	}
	
	public Agente agente()
	{
		return m_agente;
	}
	public URL url()
	{
		return m_url;
	}
	public void seturl(URL url)
	{
		m_url = url;
	}
	
	
	public Oferta verificaOferta(Item it)
	{
		return null;
	}
	
	/*
	
//	Venda
//"nome,detalhes,tipoLeilao,valorInicial,Prazo,bValorReserva,ValorReserva,MenorDiferenca,
//Relogio 2 que tamb�m funciona",Ingles,	    50,         10,   true,         500,         10,		
		
//Compra			
//tipoLeilao,PrecoMax,PrecoMin,detalhes,
//Ingles,    500,      10,Relogio que funcione um pouquinho"	
	public void addCaracteristica(String c)
	{
		 vetorCaracteristicas.addElement(c);
	}
	public String getCaracteristica(int i)
	{
		if(i<vetorCaracteristicas.size())
			vetorCaracteristicas.elementAt(i);
		return "";	
	}
	public int getIndiceCaracteristica(String caracteristica)
	{
		int i=0;
		String caracAtual;
		for(i=0;i<vetorCaracteristicas.size();i++)
		{ 
			caracAtual = (String)vetorCaracteristicas.elementAt(i);
			if(caracteristica.equalsIgnoreCase(caracAtual))
				return i;
		}
		return -1;	
	}	
	public String getValorCaracteristicaNome(String caracteristica)
	{
		int i = getIndiceCaracteristica(caracteristica);
		return getValorCaracteristica(i);

	}	
	public void addValorCaracteristica(String c)
	{
		 vetorValorCaracteristicas.addElement(c);
	}
	
	public void setValorCaracteristica(String c,String valor)
	{
		int i = getIndiceCaracteristica(c);	
		vetorValorCaracteristicas.setElementAt(valor,i);
	}
	public String getValorCaracteristica(int i)
	{
		if(i<vetorValorCaracteristicas.size() && i>-1)
			return (String)vetorValorCaracteristicas.elementAt(i);
		return "";	
	}
	*/
		
			

}

