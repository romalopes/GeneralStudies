/**classe P�ginas indica a p�gina que vamos entrar**/
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;


import ClassesGeral.Enviador;
import ClassesGeral.Mensagem;

public class PaginaLokau extends Pagina
{

	public PaginaLokau(Agente ag) throws Exception 
	{
		super(ag);
		m_nome = "LOKAU";
		m_base = "http://www.lokau.com.br/";
		m_biniciaBusca = false;
	};
	public void buscaProdutoIndividual(String CodProd)
	{
	}
	public int tempoRestante(Item it)
	{
		return 0;
	}
	public int tempoRodando(Item it)
	{
		return 0;
	}
	public int prazo(Item it)
	{
		return 0;
	}
	public void registraLeilao()
	{
		int i;
		i = agente().estagio()+1;
		agente().setEstagio(i);
	};
	public void insereProduto()
	{
	
/*	
<input type=hidden name=tcoditem value=>
<input type=hidden name=ttela value='VEN'>
<input type=hidden name=tipotela value=CADASTRO>
<input name='ttitulo' maxlength=70 size=70 value=""><br><font size="-2"> (m�ximo de 70 
//CEP
<input name='tcep1' maxlength=5 style="HEIGHT: 22px; WIDTH: 60px" value=""><font size="+1">-</font> 
<input name='tcep2' maxlength=3 
//Novo
<font color="red">Aqui voc� deve marcar se seu produto �:</font><br><input type="radio"  name="novo" value="S">novo (nunca teve uso)&nbsp;&nbsp;ou&nbsp;&nbsp;<input type="radio"  name="novo" value="N">usado


//CAtegoria	= 68
<td>&nbsp;&nbsp;<font face="Arial" size="2" color="Black">categoria escolhida:</font> <input type="text" name="TCATEGORIA" value="" size="5" readonly onChange="initMenu(document.formvend.TCATEGORIA.value);"></td>
				</td>
//Tipo de Transacao

						<INPUT type=checkbox value=S name=TTP_1 > Transa��o Segura Paguei.com (<A href="javascript:reg();">o que � o Paguei.com?</A>)&nbsp;&nbsp;&nbsp;&nbsp;
						<INPUT type=checkbox value=S name=TTP_2 > Dep�sito Antecipado &nbsp;&nbsp;&nbsp;<br><br>
						<INPUT type=checkbox value=S name=TTP_4 > <A href="http://www.lokau.com.br/jav/go?nomehtm=/sedex_portaporta.htm">Sedex Porta a Porta</A> &nbsp;&nbsp;&nbsp;&nbsp;
						<!-- <INPUT type=checkbox value=S name=TTP_5 > <B>LokauSafe</B> (<A href="javascript:Abrejanela6();">o que � LokauSafe?</A>)&nbsp;&nbsp;&nbsp;&nbsp; -->
						<INPUT type=checkbox value=S name=TTP_3 > Pagamento na Entrega &nbsp;
					</td>
				</tr>


//Tipo Dinheiro
	                <TD><INPUT type=checkbox value=S name=TINDINHEIRO > Dinheiro&nbsp;&nbsp;&nbsp;&nbsp;
						<INPUT type=checkbox value=S name=TINCHEQUE > Cheque&nbsp;&nbsp;&nbsp;&nbsp; 
		                <INPUT type=checkbox value=S name=TINCARTAO > Cart&atilde;o de cr&eacute;dito&nbsp;&nbsp;&nbsp;&nbsp;
						<INPUT type=checkbox value=S name=TINDEPCONTA > Dep�sito em conta&nbsp;&nbsp;&nbsp;&nbsp;
				  	</TD>


//Custo Transporte
					<td><input type="radio" name="Tcustostransp" value="1" CHECKED > Comprador 
					    <input type="radio" name="Tcustostransp" value="2"  > Vendedor

//Lance M�nimo

m�nimo:</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						R$ <input name="TLANMIN" maxlength=7 size="7" value= ><font size="+1"> <b>,</b> </font>
						<input name="TLANMINCENT" maxlength=2 size="2" value=>&nbsp;Ex.: R$ 

//Quantidade
<input name="TQTITEM" maxlength=7 size="7" value="" ><br><font size="1">


//Tipo pacote		
<td><input type="radio" name="TINPACOTE" value="1" @RADIOPACO1 ><font size="2" face="arial" color="#319AFF">N�o quero comprar destaque</font></td>

//Dia do vencimento
			<td valign="middle" height="45">
				<font face="Arial" size="2">Quero que a data de vencimento do meu extrato seja no dia </font>
				<select name="TDIAVENC" size="1">
					<option value="0" selected></option>
					<option value="1">1</option>
					<option value="5">5</option>
					<option value="10">10</option>
					<option value="20">20</option>
				</select>de cada m�s.
			</td>


*/


			String string;
			
			String stringTotal;
			stringTotal = "ttela=VEN&tipotela=CADASTRO&ttitulo=Mequetrefe4&";
			stringTotal += "tcep1=24000&tcep2=000&novo=S&TCATEGORIA=TTP_1&TINDINHEIRO=S&";
			stringTotal += "Tcustostransp=1&";
			stringTotal += "TLANMIN=1&";
			stringTotal += "TLANMINCENT=1&";
			stringTotal += "TQTITEM=1&TINPACOTE=1&TDIAVENC=1";

			stringTotal += "\r\n";

			System.out.println(stringTotal);
/*			
			stringTotal = URLEncoder.encode(stringTotal);			
			
			System.out.println(base());
			
			Socket s = new Socket("200.222.67.101",80);
			DataInputStream in = new DataInputStream(s.getInputStream());
			DataOutputStream out = new DataOutputStream(s.getOutputStream());
			out.writeBytes("POST pl/cadastralance HTTP/1.0\r\n");
			out.writeBytes("Content-type: application/x-www-form-urlencoded\r\n");
//			out.writeBytes("POST pl/cadastralance HTTP/1.0\r\n");
//			out.writeBytes("Content-type: plain/text\r\n");
			out.writeBytes("Content-length:"+stringTotal.length()+"\n\n");
//			out.writeBytes("POST pl/cadastralance HTTP/1.0\r\n");			
			out.writeBytes(stringTotal);			
			out.flush();
			out.close();
			in.close();
			s.close();
*/







			
/*
			URL  url;
			URLConnection urlConn;
			DataOutputStream    printout;
			DataInputStream     input;
			// URL of CGI-Bin script.
			url = new URL (base() + "pl/cadastralance");
			// URL connection channel.
			urlConn = url.openConnection();
			// Let the run-time system (RTS) know that we want input.
			urlConn.setDoInput (true);
			// Let the RTS know that we want to do output.
			urlConn.setDoOutput (true);
			// No caching, we want the real thing.
			urlConn.setUseCaches (false);
			// Specify the content type.
			urlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			// Send POST output.
			printout = new DataOutputStream (urlConn.getOutputStream ());
//			String content = "name=" + URLEncoder.encode ("Buford Early") +
//							"&email=" + URLEncoder.encode ("buford@known-space.com");
			printout.writeBytes (stringTotal);
			printout.writeBytes("\r\n");
			printout.flush ();
			printout.close ();
			// Get response data.
			input = new DataInputStream (urlConn.getInputStream ());
			String str;
			while (null != ((str = input.readLine())))
			{
				System.out.println (str);
//				textArea.appendText (str + "\n");
			}
			input.close ();

*/


	};
	public void criaLeilao()
	{
	
	};
	public void fechaLeilao()
	{
	};
	
	
	/************************** IniciaBusca *****************************/	
	/**Inicia a busca para o Lokau.com */	
	public void IniciaBusca() 
	{
		try
		{
			setIniciaBusca(true);
			//abre conex�o ...
			String s = base()+"jav/geli_listsimples?palavra="+URLEncoder.encode(m_agente.nomeProduto())+"&uf=00";
			System.out.println("url:"+s);
			m_url = new URL(s);
			m_siteConnection = m_url.openConnection();
			
			if(m_in!= null)
				m_in.close();
			m_in = new BufferedReader(
						new InputStreamReader(
						m_url.openStream()));
					
						
		}
		catch(IOException e)
		{
			System.out.println(e+ " Erro no IniciaBusca"+agente().stringErro() );
			setIniciaBusca(false);
		}			
	}
	
	/************************** finaliza a conex�o para a busca ************/
	public void finalizaConexao()
	{
		try
		{
			m_in.close();
			m_in = null;
		}
		catch(Exception e)
		{}
	
	}
	public Oferta verificaOferta(Item it)
	{
		Oferta oferta = null;
		try
		{
			double valorAtual = it.vetorCaracteristica.getValorCaracDouble("valorAtual");
			
			
			BuscaDetalhes(it);//	throws Exception 
			
			
			double valorAtual2 = it.vetorCaracteristica.getValorCaracDouble("valorAtual");
			if (valorAtual != valorAtual2)
			{
				oferta = new Oferta("Nome",String.valueOf(valorAtual2));
				
				oferta.setNumeroEstrelas(0);
							
				oferta.setCodProd(it.vetorCaracteristica.getValorCarac("codigo"));
				oferta.setNomeProd(it.vetorCaracteristica.getValorCarac("nomeProduto"));				
								
			
			
			}
		}
		catch(Exception e)
		{
			System.out.println(e+" Erro no verificaOferta do PaginaLokau "+agente().stringErro());
		}
		return oferta;
		
	}
	

	
/********************** tranformaDataLokauParaAgILE *****************************/	
	static private String tranformaDataLokauParaAgILE(String string)
	{
		int minuto=0, hora=0, dia=0, mes=0, ano=0 ,posIndex=0, posIndexAtual=0;
		String stringAtual;
	
		try
		{
			System.out.println("string"+string);
			
		    posIndex = string.indexOf('/',posIndexAtual);
			stringAtual = string.substring(posIndexAtual,posIndex);
			Integer valor = new Integer(Integer.parseInt(stringAtual, 10));
			dia = (int)valor.intValue();
			
			System.out.println(minuto+"/"+hora+"/"+dia+"/"+mes+"/"+ano);

			posIndexAtual = posIndex+1;
			posIndex = string.indexOf('/',posIndexAtual);
			stringAtual = string.substring(posIndexAtual,posIndex);
			valor = new Integer(Integer.parseInt(stringAtual, 10));
			mes = (int)valor.intValue();

			System.out.println(minuto+"/"+hora+"/"+dia+"/"+mes+"/"+ano);
						
		
			posIndexAtual = posIndex+1;
			posIndex = string.indexOf(' ',posIndexAtual);
			stringAtual = string.substring(posIndexAtual,posIndex);
			valor = new Integer(Integer.parseInt(stringAtual, 10));
			ano = (int)valor.intValue();

			System.out.println(minuto+"/"+hora+"/"+dia+"/"+mes+"/"+ano);
			
			posIndexAtual = posIndex+1;
			posIndex = string.indexOf(':',posIndexAtual);
			stringAtual = string.substring(posIndexAtual,posIndex);
			valor = new Integer(Integer.parseInt(stringAtual, 10));
			hora = (int)valor.intValue();
		
			System.out.println(minuto+"/"+hora+"/"+dia+"/"+mes+"/"+ano);
			
			stringAtual = string.substring(string.length()-2,string.length());
			valor = new Integer(Integer.parseInt(stringAtual, 10));
			minuto = (int)valor.intValue();
		
			System.out.println(minuto+"/"+hora+"/"+dia+"/"+mes+"/"+ano);

			int mes31 = 31;
			int mes30= 30;
			int mes28=28;
			
			if(mes==1) 
				mes =0;
			else if(mes == 2)
				mes = mes31;
			else if(mes == 3)
				mes = mes31+mes28;
			else if(mes == 4)	
				mes = 2*mes31+mes28;
			else if(mes == 5)	
				mes = 2*mes31+mes30+mes28;
			else if(mes == 6)	
				mes = 3*mes31+mes30+mes28;
			else if(mes == 7)	
					mes = 3*mes31+2*mes30+mes28;
			else if(mes == 8)	
				mes = 4*mes31+2*mes30+mes28;
			else if(mes == 9)	
				mes = 5*mes31+2*mes30+mes28;
			else if(mes == 10)	
				mes = 5*mes31+3*mes30+mes28;
			else if(mes == 11)	
				mes = 6*mes31+3*mes30+mes28;
			else if(mes == 12)
				mes = 6*mes31+4*mes30+mes28;
			
			ano = 2000+ano;
			string = minuto+"/"+hora+"/"+String.valueOf(dia+mes)+"/"+ano;		
			System.out.println("string:"+string);
			return string;
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no tranformaDataLokauParaAgILE" + string+" "+posIndex+" "+posIndexAtual);
		}
		return "";
	}
	
	/************************** BuscaDetalhes *****************************/
	/**faz a busca dos destalhes como descri��o e a foto para o lokau.com */
	private void BuscaDetalhes(Item item)//	throws Exception 
	{
		BufferedReader in;
		try
		{//jav/gesh_showitem?cod=
		//pl/showitem_detalhe?cod=
			//Abre a conex�o, para pegar os detalhes de cada produto(fotos e descricao)
			String s = base()+"jav/gesh_showitem?cod="+item.vetorCaracteristica.getValorCarac("codigo");
//			System.out.println("detalhes:"+s);	
			URL site = new URL(s);
			URLConnection siteConnection = site.openConnection();
			in = new BufferedReader(
						new InputStreamReader(
						site.openStream()));
			String inputLine;

			int fromIndex = 0;
			int fim,inic;
			String string;

			//pega cada linha
			while ((inputLine = in.readLine()) != null)
			{
//				System.out.println (inputLine);

				//onde tiver uma figura � porque est� aqui, assumimos que jpg � s� a figura.
				//<b>Pre&ccedil;o atual: <font color="CE0000">R$ 20,40 </font></b><img 
				int index;// = inputLine.indexOf("atual:",0);
				if ((index = inputLine.indexOf("o atual:",0)) > 0 )
				{
					//pega o 
					inic = inputLine.indexOf(">",index);
					if ( inic > 0)
					{
						inic = inic+4;
						fim = inputLine.indexOf(",",inic);
						string =  inputLine.substring(inic,fim);
						System.out.println("string:"+inic+" "+fim+" "+string);
						item.vetorCaracteristica.setValorCarac("valorAtual",string);
					}
				}//<b>Pre&ccedil;o inicial:</b> R$ 20,40<img src="images/1x1verm.gif" width="195" height="1" 
				else if ((index = inputLine.indexOf("inicial:",0)) > 0 )
				{
					//pega o 
					inic = inputLine.indexOf(">",index);
					if (inic > 0)
					{
						inic = inic+4;
						fim = inputLine.indexOf(",",inic);
						string =  inputLine.substring(inic,fim);
						
						System.out.println("string:"+inic+" "+fim+" "+string);
						
						item.vetorCaracteristica.setValorCarac("valorInicial",string);
					}
				}//<b>Comprador: <font color="CE0000">romalopes2&nbsp;<A href='/jav/gesh_coment?USR=romalopes2&COD=3406970' target='miolo'>(0)</A><A href='/freeicon.htm' target=miolo><IMG alt='' 
				else if ((index = inputLine.indexOf("Comprador:",0)) > 0 )
				{
					//pega o 
					inic = inputLine.indexOf(">",index);
					if (inic > 0)
					{
						inic = inic+1;
						fim = inputLine.indexOf("&",inic);
						string =  inputLine.substring(inic,fim);

						System.out.println("string:"+inic+" "+fim+" "+string);
						
						item.vetorCaracteristica.setValorCarac("nomeDono",string);
						
						//Aqui pode chamar os detalhes do dono
					}
				}//<b>In&iacute;cio da venda:</b> 26/10/01 09:16<img src="images/1x1verm.gif" width="195" height="1" 
				else if ((index = inputLine.indexOf("cio da venda:",0)) > 0 )
				{
					//pega o 
					inic = inputLine.indexOf(">",index);
					if (inic > 0)
					{
						inic = inic+2;
						fim = inputLine.indexOf("<",inic);
						string =  inputLine.substring(inic,fim);
		
						string = tranformaDataLokauParaAgILE(string);
						
						System.out.println("string:"+string);
		
						item.vetorCaracteristica.setValorCarac("dataInicio",string);
						
					}
				}//	<b>N&ordm; lances:</b> 1<img src="images/1x1verm.gif" width="195" height="1" vspace="5"><br>	
				else if ((index = inputLine.indexOf("lances::",0)) > 0 )
				{
					//pega o 
					inic = inputLine.indexOf(">",index);
					if (inic > 0)
					{
						inic = inic+2;
						fim = inputLine.indexOf(" ",inic);
						string =  inputLine.substring(inic,fim);
		
						System.out.println("string:"+inic+" "+fim+" "+string);		
		
//						item.vetorCaracteristica.setValorCarac("dataInicio",string);
						
						//Aqui pode chamar os detalhes.
					}
				}					
			}

			//pega a descri��o, pode ser grande.
//			StringBuffer buffer = new StringBuffer(1000);		
//			while ((inputLine = in.readLine()) != null)
//			{
//				inic = inputLine.indexOf("<br>",fromIndex);
//				if (inic < 0 && buffer.capacity() > inputLine.length())
//				{
//					buffer.append(inputLine);
//				}
//				else
//					break;
//			}
//			System.out.println ("Descri��o = "+buffer.toString());
//			item.setDescricao(buffer.toString());
			in.close();
		}
		catch(Exception e)
		{
			System.out.println(e+ " Erro em buscaDetalhes"+agente().stringErro());
		}

	}

	/************************** Busca *****************************/	
	/**faz a busca para o lokau.com **/
	public Item Busca(String nomeProd)
	{
		Item item = null;

		try
		{
		
			int num = 0;
			
			//while para pegar cada linha
			while ( (m_inputLine = m_in.readLine()) != null && item ==null)
			{
//				System.out.println (m_inputLine);
//				m_inputLine = URLDecoder.decode(m_inputLine);
				int fromIndex = 0;
				int index = m_inputLine.indexOf("cod=",fromIndex);
				if (index>0)
				{
					fromIndex = 0;
					int fim,inic = m_inputLine.indexOf("cod=",fromIndex);
					if ( inic > 0)
					{
						//pega o codigo
						fim = m_inputLine.indexOf("\"",inic);
						inic=inic+4;
						String codigoProd =  m_inputLine.substring(inic,fim);
						System.out.println ("\n\n*******************************\n*****"+codigoProd+"******\n\n*******************************");
						num++;
						
						//pega a pr�xima linha						
//						m_inputLine = m_in.readLine();
						inic=m_inputLine.indexOf(m_agente.nomeProduto(),fromIndex);
	//pega o nome do produto
//						inic = inic + 3;
						fim = m_inputLine.indexOf("</font",inic);
						if(fim < 0)
							fim = m_inputLine.indexOf("</b>",inic);
						String string;
						if(fim >=0)
							string =  m_inputLine.substring(inic,fim);
						else
							continue;
						System.out.println ("Nome = "+string);
							
						//seta o codigo e o nome
						item = new Item(string,agente(),this);
						item.vetorCaracteristica.setValorCarac("codigo",codigoProd);
//						item.setCodigo(codigoProd);
//						item.setNomePagina("lokau");
						GregorianCalendar dataAtual = new GregorianCalendar();
						item.setData(dataAtual);
						BuscaDetalhes(item);
					}		
				}
			}	
		}
		catch(IOException e)
		{
			System.out.println(e+ " Erro no Busca do PagiaLokau" );
			return null;
		}			
	
//		this.finalizaConexao();
		
		return item;
	}

	
	/************************** IniciaOferta *****************************/	
	/*********************************************************************/	
	public void IniciaOferta() 
	{
		try
		{
		
			//abre conex�o ...
			m_siteConnection = m_url.openConnection();
			if(m_in!= null)
				m_in.close();
			m_in = new BufferedReader(
						new InputStreamReader(
						m_url.openStream()));
					
						
			StringBuffer line = new StringBuffer(5000);
			m_inputLine = new String(line);//s� pra garantir que a String ser� grande
			
		}
		catch(IOException e)
		{
			System.out.println(e+ " Erro no IniciaOferta" );
		}			
	}
	
	/************************** realizaOferta ****************************/
	/*********************************************************************/
	public boolean realizaOfertaItem(Item item,double valorOferta)
	{
		try
		{
		
//			IniciaOferta();
			
			//abre conex�o ... e j� realiza a oferta.
			String string;
			
			String stringTotal;
			stringTotal = "TUSERNAME=romalopes2&";
			stringTotal += "TSENHA=novembro&";
			string = "TCODVEND="+item.vetorCaracteristica.getValorCarac("codigo")+"&";
			System.out.println("string:"+string);
			stringTotal += string;
			String string2 = String.valueOf(valorOferta);
			string2 = string2.replace('.', ',');
			string = "TVLLANC=22,00&";//+string2;
			stringTotal += string;
			string = "TVLAGEND="+string2;			
			stringTotal += string;
			stringTotal += "\r\n";

			System.out.println(stringTotal);
			
			stringTotal = URLEncoder.encode(stringTotal);			
			
			System.out.println(base());
/*			
			Socket s = new Socket("200.222.67.101",80);
			DataInputStream in = new DataInputStream(s.getInputStream());
			DataOutputStream out = new DataOutputStream(s.getOutputStream());
			out.writeBytes("POST pl/cadastralance HTTP/1.0\r\n");
			out.writeBytes("Content-type: application/x-www-form-urlencoded\r\n");
//			out.writeBytes("POST pl/cadastralance HTTP/1.0\r\n");
//			out.writeBytes("Content-type: plain/text\r\n");
			out.writeBytes("Content-length:"+stringTotal.length()+"\n\n");
//			out.writeBytes("POST pl/cadastralance HTTP/1.0\r\n");			
			out.writeBytes(stringTotal);			
			out.flush();
			out.close();
			in.close();
			s.close();
*/







			
/*
			URL  url;
			URLConnection urlConn;
			DataOutputStream    printout;
			DataInputStream     input;
			// URL of CGI-Bin script.
			url = new URL (base() + "pl/cadastralance");
			// URL connection channel.
			urlConn = url.openConnection();
			// Let the run-time system (RTS) know that we want input.
			urlConn.setDoInput (true);
			// Let the RTS know that we want to do output.
			urlConn.setDoOutput (true);
			// No caching, we want the real thing.
			urlConn.setUseCaches (false);
			// Specify the content type.
			urlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			// Send POST output.
			printout = new DataOutputStream (urlConn.getOutputStream ());
//			String content = "name=" + URLEncoder.encode ("Buford Early") +
//							"&email=" + URLEncoder.encode ("buford@known-space.com");
			printout.writeBytes (stringTotal);
			printout.writeBytes("\r\n");
			printout.flush ();
			printout.close ();
			// Get response data.
			input = new DataInputStream (urlConn.getInputStream ());
			String str;
			while (null != ((str = input.readLine())))
			{
				System.out.println (str);
//				textArea.appendText (str + "\n");
			}
			input.close ();

*/


		
			//verifica se a oferta foi aceita, se sim faz mais alguma coisa...
			
			finalizaConexao();
		}
		catch(Exception e)
		{
			System.out.println(e+"Erro no RealizaOferta do PaginaLokau para "+item.vetorCaracteristica.getValorCarac("codigo") + " " + agente().stringErro() );
			return false;
		}
		return true;
	}
}


