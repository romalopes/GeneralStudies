import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;


abstract class Criterio extends Object implements Serializable
{
	String nomeCriterio;
	abstract public Double CalculaCriterio(Item it);
	
	public Criterio(String n)
	{
		nomeCriterio = n;
	}
	
	
/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
	
			out.writeObject(nomeCriterio);

			out.flush();
		}	
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do Criterio" );
		}			
	}
	
/****************************** readObject **********************************/		
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			nomeCriterio =  (String)in.readObject();
		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read do Criterio" );
		 }
	 }
	 
	
	public String nomeCriterio()
	{
		return nomeCriterio;
	}
	
	public Criterio()
	{
	}
	
}

