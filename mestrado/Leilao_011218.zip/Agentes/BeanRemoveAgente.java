//import java.io.*;
//import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;


public class BeanRemoveAgente extends BeanGeral
{

	public boolean processa()
	{
		System.out.println("Procesando BeanRemoveAgente");
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(getNomeUsuario(),Inet.getHostAddress());
			Msg.setMensagem("RemoveAgente");
			
			Msg.setMensagemAux(getNomeAgente());
			Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
			Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);			
			return Msg.mensagemRetorno();
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanPegaAgentes Exception:  " + e);
		}
		return false;		
	}
}
