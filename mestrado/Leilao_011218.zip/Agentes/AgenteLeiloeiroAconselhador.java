/**classe Final Agente de Leiloeiro**/

import java.io.*;    //Package de classes para manipulacao de E/S

import java.util.*;

import java.net.*;

import ClassesGeral.Enviador;
import ClassesGeral.Mensagem;

/*
Procedimento do Agente Leiloeiro
	Configurado Pelo Usu�rio
	Visita Agentes Compra(pode realizar isso atrav�s do site de leil�o)
			Verifica Perfis e tenta achar compradores com perfis parecidos e interessantes, nesse passo o agente leiloeiro j� deve saber o perfil que ele procura.

	Visita Sites de Leil�es
		Procura produtos para os agentes com os perfis interessantes

	Convida os Agentes
		Convida os agente 

	Inicia o Leil�o no ambiente AgILE
		O fato de Iniciar o leil�o pode implicar na entrada em algum leil�o de um site j� existente .
		Recebe notifica��o das ofertas dos agentes e de outros.
		Responde d�vidas.
	Fecha Leil�o
	Entra Entra em contato com o vendedor e oferece o pre�o com �gil para que ele diga o comprador
		D� o contato do comprador para o vendedor e visse-versa	
*/

final public class AgenteLeiloeiroAconselhador extends AgenteLeiloeiro
{

	public AgenteLeiloeiroAconselhador(String usu,String n)
	{
		super(usu,n);
		try
		{	
			setTipo("aconselhador");
//			setTipoLeiloeiro("Aconselhador");
			
			//somente por enquanto, isso vai ser criado de forma externa
//			CriterioPreco c = new CriterioPreco((float)1);
//			listCriterios.addElement(c);	
			//adciona a p�gina AKRM.
			addPagina("AKRM");
			
			setStringErro("no Agente LeiloeiroAconselhador:"+nome());
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro na Cria��o do AgenteLeiloeiroAconselhador" );
		}
	}



	public AgenteLeiloeiroAconselhador(String usu,String n,Gerente gerente)
	{
		super(usu,n,gerente);
		
		setTipo("aconselhador");

//		setTipoLeiloeiro("Aconselhador");

		try
		{	
//			addPagina("LOKAU");
//			addPagina("ARREMATE");
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro na Cria��o do AgenteLeiloeiroAconselhador" );
		}

		//somente por enquanto, isso vai ser criado de forma externa

		CriterioPreco c = new CriterioPreco((float)1);
		listCriterios.addElement(c);	
	}

	

	/****************************** writeObject **********************************/
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{
			out.flush();
		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do AgenteLeiloeiroAconselhador" );
		}
	}

/****************************** readObject **********************************/
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{

		 }
		 catch(Exception e)
		 {
		 	System.err.println(e+" Erro no read do AgenteLeiloeiroAconselhador" );
		 }
	}





/************************** encontraRelacaoAgente *****************************
//tenta achar a relacao entre os agentes e o Leiloeiro
//poderia verificar a relacao entre os agentes.	ou mesmo verificar alguma coisa que os agente podem possuir de correlatos.
	private boolean encontraRelacaoAgente(Agente ag)
	{
		try
		{
			return Enviador.encontraRelacaoPalavras(nomeProduto(),ag.nomeProduto());
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no encontraRelacaoAgente Agente de Leiloeiro " + nome());
		}
		return false;
	}
	
/************************** BuscaAgentesCompra *****************************
//Pesquisa os Agente de compra para ver se eles possuem as prefer�ncias especificadas 

	private String BuscaAgentesCompra()	throws Exception 
	{
		boolean relacao = true;
		int j=0,i;
		try
		{
			System.out.println ("Busca agentes de compra com: "+ nomeProduto());
			this.appendHistoria("Pesquisa os agentes de Compra com: "+ nomeProduto());

			setBuscando(true);

			//acho que o ideal seria enviar mensagens, mas fica dificil de conseguir consistencia
			for(i=0;i<m_gerente.m_listAgentes.size();i++)
			{
				Agente ag = (Agente)m_gerente.m_listAgentes.elementAt(i);
				if(!ag.tipo().equalsIgnoreCase("compra"))
					continue;

				//aqui analisa se os agentes possuem as caracteristicas desejadas para que o leiloeiro ofereca o produto.				
				relacao = encontraRelacaoAgente(ag);//poderia verificar a relacao entre os agentes.	

				if (relacao)
				{
					this.appendHistoria("Achou o agente de compra "+ ag.nome()+" interessante");
					listAgentesCompra.addElement(ag);
				}
			}
			setBuscando(false);

			i = estagio();
			setVezes(0);
			setEstagio(++i);	
			executaEstrategia();

//			EscolheAgentes();
		}
		catch(Exception e) 
		{

			System.err.println ("\nErro no Busca Ag Compra do Agente de Leiloeiro " + e);
			return "erro";
		}     
		EscolheItens();
		return "ok";
	}

	
/************************** BuscaAgentesVenda *****************************
//Pesquisa os Agente de venda para ver se eles oferecem os produtos especificados 
	private String BuscaAgentesVenda()	throws Exception 
	{//deveria enviar uma mensagem para o gerente. 
		boolean relacao = true;
		int j=0,i;
		try
		{
			System.out.println ("Busca por agentes de venda com:"+ nomeProduto());
			this.appendHistoria("Pesquisa os agentes de venda com: "+ nomeProduto());

			setBuscando(true);

			//acho que o ideal seria enviar mensagens, mas fica dificil de conseguir consistencia
			for(i=0;i<m_gerente.m_listAgentes.size();i++)
			{
				Agente ag = (Agente)m_gerente.m_listAgentes.elementAt(i);
				if(!ag.tipo().equalsIgnoreCase("venda"))
					continue;

				//aqui analisa se os agentes possuem as caracteristicas desejadas para que o leiloeiro ofereca o produto.				
				relacao = encontraRelacaoAgente(ag);//poderia verificar a relacao entre os agentes.	

				if (relacao)
				{
					this.appendHistoria("Achou o agente de venda "+ ag.nome()+" interessante");
					listAgentesVenda.addElement(ag);
				}
			}
			setBuscando(false);

			i = estagio();
			setVezes(0);
			setEstagio(++i);	
			executaEstrategia();

//			EscolheAgentes();
		}
		catch(Exception e) 
		{

			System.err.println ("\nErro no Busca Ag Venda do Agente de Leiloeiro " + e);
			return "erro";
		}     
		EscolheItens();
		return "ok";
	}


	
/************************** RemoveItensExcedentes *****************************
//Somente Deixa os que est�o na faixa do permitido(numMaxItens)
//No futuro vai remover os que tiver abaixo da satisfa��o desejada tamb�m.
//deve ser chamado depois da ordena��o.
	public void	RemoveItensExcedentes()
	{
		for(int i = numMaxItens(); i<listItens.size();i++)
		{

			Item it = (Item)listItens.elementAt(i);
			listItens.removeElementAt(i);

		}
	}


/************************** passaRestricoes *****************************/			
	public void	passaRestricoes()
	{
	}
	

/************************** OrdenaItens *****************************
/**O que tem maior avalia��o primeiro*
	public void OrdenaItens()
	{
		Item itAtual,it;
		int size = listItens.size();
		double avalMelhor;
		int posMelhor;
		

		//deppois melhoro essa ordena��o		
		for(int i = 0; i<listItens.size();i++)
		{
			itAtual = (Item)listItens.elementAt(i);
			avalMelhor = itAtual.somaAvaliacao();
			posMelhor = i;
			for(int j = i;j<listItens.size();j++)
			{
				it = (Item)listItens.elementAt(j);
				//se o item for maior insere nessa posi��o se n�o vai inserir mais pra baixo
				if (avalMelhor < it.somaAvaliacao())
				{			
					avalMelhor = it.somaAvaliacao();
					posMelhor = j;
				}
			}

			it = (Item)listItens.elementAt(posMelhor);
			listItens.removeElementAt(i);			
			listItens.insertElementAt(it,i);			
			listItens.removeElementAt(posMelhor);			
			listItens.insertElementAt(itAtual,posMelhor);			
		}
	}

	

/************************** EscolheItens *****************************/
/**de todos os Itens j� pegos nas p�ginas ir� escolher algumas de acorod com os crit�rios e restri��es*
	public void EscolheItens()
	{
		Item item;
		//para cada Itens verifica a alternativa
		for(int i = 0; i<listItens.size();i++)
		{
			item = getItemAt(i);
			item.removeAllCriterios();
			for(int j = 0;j<listCriterios.size();j++)
			{
				Criterio c = (Criterio)listCriterios.elementAt(j);
				item.addValorCriterio(c.CalculaCriterio(item));
			}
			//soma os crit�rios para depois ordenar
			item.SomaCriterios();
		}
		//passa as restri��es...
		passaRestricoes();
		
		//Ordena
		OrdenaItens();
		
		//Remove
		RemoveItensExcedentes();
	}
	
/*********************** BuscaLeiloes() *****************************
	private String BuscaLeiloes() 	throws Exception 
	{
		Item item;
		int j=0;
	
		try
		{
		
			System.out.println ("Busca por "+ nomeProduto());
			this.appendHistoria("Busca por "+ nomeProduto());

			setBuscando(true);

			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				pag.IniciaBusca();
				System.out.println ("\nBusca na pagina "+pag.nome());
				do
				{
					j++;
					System.out.println(nomeProduto());
					item = pag.Busca(nomeProduto());//aqui no futuro vai buscar com v�rios nomes diferentes para juntar.
					if(item!=null)
						this.addItem(item);
				}while (item != null );
				pag.finalizaConexao();
			}
			setBuscando(false);
//			EscolheItens();
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no Busca do Agente de compra " );
			return "erro";
		}     
		return "ok";
	}
	
	
/*	public boolean OfereceLeiloesAgenteCompra()
	{//talvez devesse enviar uma mensagem.
	//nao vamos pegar os agente diretamente, vamos usar somente os 
	//seus atributos pois no futuro nao utilizaremos a classe agente.
		try
		{
			AgenteCompra ag;
			Item it;
			String idItem,msgAux;
			int j,i;
			
			if(listAgentesCompra.size() == 0 )
				return false;
			for(i=0;i<listAgentesCompra.size();i++)
			{
				ag = (AgenteCompra)listAgentesCompra.elementAt(i);
				
				for(j=0;j<listItens.size();j++)
				{
					it = (Item)listItens.elementAt(j);
					idItem = it.vetorCaracteristica.getValorCarac("codigo");
					if(ag.findItemID(idItem) != null)
						continue;					

					
					//se chegou at� aqui � porque vai oferecer.
							
					Mensagem Msg = new Mensagem(this.nome(), Enviador.nomeHostGerente  );
					Msg.setMensagem("recebeConviteLeilao");
					Msg.setOrigem(this.nome());
					Msg.setDestino(ag.nomeUsuarioPagina());
					Msg.setTipo("Agente");
					Msg.setReply(false);
					msgAux = idItem+","+it.pagina().nome(); 
					Msg.setMensagemAux(msgAux);//
					Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);		
				}
			}
		}
		catch(Exception e)
		{
			System.err.println(e+"Erro no OfereceLeiloesAgenteCompra do Leiloeiro");
		
		}
		return true;
	}
	*/

//Especial para o site do AKRM
/*********************** RecebeMensagemBusca *****************************/	
	public Mensagem recebeReplyBuscaProdutos(Mensagem msg) 	throws Exception 
	{
		Item item;
		try
		{
			boolean achou = false;
			String StringItem;
			this.appendHistoria("Reply busca produtos ");
			msg.setMensagemRetorno(false);
			String	mensagemAux = msg.mensagemAux();
			msg.setReply(false);
			int i=0;
			Pagina pag = findPagina("AKRM");
			if (pag == null)
			{
				this.appendHistoria("Inconsistencia na p�ginha AKRM ");
				return msg;
			}
			i=0;
			StringItem = Enviador.pegaParte(mensagemAux,i,';');
			while(!StringItem.equalsIgnoreCase(""))
			{
				achou = true;
				item = new Item(Enviador.pegaParte(StringItem,1,'&'),this,pag);

				String palavra;
				item.vetorCaracteristica.setCaracteristicas(StringItem);
				String nomeProd = item.vetorCaracteristica.getValorCarac("nomeProduto");
				if(!nomeProd.equals(""))
					item.setNome(nomeProd);
				addItem(item);
								
				System.out.println ("valorInicial" + item.vetorCaracteristica.getValorCarac("valorinicial"));
				item.vetorCaracteristica.setValorCarac("valorAtual",item.vetorCaracteristica.getValorCarac("valorinicial"));
				item.vetorCaracteristica.setValorCarac("valorVencedor",item.vetorCaracteristica.getValorCarac("valorinicial"));
				System.out.println ("\nPegou prod" + StringItem);
				i++;
				StringItem = Enviador.pegaParte(mensagemAux,i,';');
			}		
			if (achou)
			{
				i = estagio();
				setVezes(0);
				setEstagio(++i);	
				executaEstrategia();
				mensagemAux = msg.mensagemAux();
				this.appendHistoria("Retornou da busca com produtos");//Resultado Busca "+ mensagemAux);
			}
			else 			
				this.appendHistoria("Retornou de uma busca sem produtos");			
			EscolheItens();
		}
		catch(Exception e) 
		{

			System.err.println ("\nErro no Busca do Agente de compra " + e);
		}     
		msg.setMensagemRetorno(true);

		return msg;
	}


	public Mensagem recebeReplyRegistroAKRM(Mensagem msg) 	throws Exception 
	{
		try
		{
			this.appendHistoria("Reply de Registro AKRM TRUE");
			msg.setReply(false);
			Pagina pag = findPagina("AKRM");
			if (msg.mensagemRetorno())
			{
				pag.setRegistrado(true);
				int i = estagio();
				setEstagio(++i);
				executaEstrategia();
			}
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no recebeReplyRegistroAKRM do Agente de compra " + e);
		}     
		
		return msg;	
	}	


	/************************** recebeMensagem *****************************/	
	public Mensagem recebeMensagem(Mensagem msg)
	{
		Mensagem mensagem = new Mensagem("","");
		try
		{
			System.out.println (nome()+" Recebi a mensagem "+msg.mensagem());
			if (msg.mensagem().equalsIgnoreCase("recebeReplyBuscaProdutos"))
			{
				mensagem = recebeReplyBuscaProdutos(msg);
			}
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyRegistroAKRM"))
			{
				mensagem = recebeReplyRegistroAKRM(msg);
			}
			else
				System.out.println("\nMensagem n�o reconhecida "+nome());			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no comeca a Trabalhar do "+nome());
		}
		return mensagem;
	}
	
	
	//depois de receber o aviso verifica se j� est� trabalhando e continua a estrat�gia.
	public synchronized void executaEstrategia()
	{
		try
		{
			this.appendHistoria("Verifica estrat�gia. Estagio:"+estagioString()+" Vezes:"+vezes());
			System.out.println(nome()+"Executando estrategia. estagio:"+estagioString()+" Vezes:"+vezes());
			int i = vezes();
			setVezes(++i);
			if (estagio() == 0)//busca pelos agentes
			{
				buscaAgentesCompra();//Busca os Agentes de compra;
			}
//			else if (estagio() == 1)//busca pelos agentes de venda
//			{
//				BuscaAgentesVenda();
//			}
			else if (estagio() == 1)//busca pelos itens
			{
				BuscaLeiloes();
			}
//			Antes pode haver um cria novos leil�es e at� mesmo buscar agentes venda
			else if (estagio()==2)//analisa situacao dos leiloes
			{
				if (OfereceLeiloesAgenteCompra())
				{
					i = estagio()+1;
					setEstagio(i);
				}
			}
			else if (estagio()>2)
			{
				System.out.println ("Est�gio maior que 3:"+nome());
			}
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no executaEstrategia de:"+nome());
		}   
	}


	public void Init(){}


/************** ModificaConfiguracaoMensagem *********************/
//noero,autonomia,sites,arremate,mlivre,&,akrm,precoMin,precoMax,
//Modifica a configura��o com base na mensagem que foi passado pelo usu�rio
/*	public void ModificaConfiguracaoMensagem(String mensagem)
	{
		try
		{
			this.appendHistoria("Modifica a Configuracao "+ mensagem);
			Integer valor;
			int i = 1;
			setAutonomia(Enviador.pegaParteInteiro(mensagem,1,','));
			i++;
			String s1,s2;
			while (!Enviador.pegaParte(mensagem,i,',').equals("&"))
			{
				String site = Enviador.pegaParte(mensagem,i,',');
				Pagina pag = addPagina(site);
				while (!Enviador.pegaParte(mensagem,i,',').equals("*") && !Enviador.pegaParte(mensagem,i,',').equals("&"))						
				{	
					s1 = Enviador.pegaParte(mensagem,i,',');
					i++;
					s2 = Enviador.pegaParte(mensagem,i,',');
					pag.vetorCaracteristica.setValorCarac(s1,s2);					
					i++;
				}
			}
			if(i==2)//pois n�o entrou nenhum site
				return;
/*			i++;
			setPrecoMin(Enviador.pegaParteInteiro(mensagem,i,','));
			i++;
			setPrecoMax(Enviador.pegaParteInteiro(mensagem,i,','));*
		}
		catch(Exception e)
		{
			System.err.println(e+"Erro no ModificaConfiguracaoMensagem");
		}
	}*/
}



	/**	
	busca();
	pegaPagina();
	ParsePalavrasChave();
	fazPergunta)seNecessario();
	atualizaFuncaoUtilizadade();
	insereReferenciasValores();//Uma lista de listas tipo www.xxx,valor 1, valor2....
								 que indica onde clicar e quais os valores a inserir. 
								 ex: login, senha.
	Nesse ponto ser� encontrado uma lista de refer�ncias ordenadas pela fun��o utilidade.

	NEGOCIA��O

	selecionaReferencias();
	iniciaNegociacao();
	verificaSePode();
	efetuaOferta();
	**/



/** 

	O valor da fun��o de Utilidade vai de 0 a 10, e n�o pode ser  valores comparativos 

	de acordo com as refer�ncias.  O valor est� relacionado apenascom a satisfa��o. 

	Ela pde ser a princ�pio RUIM, BOM, OTIMA.

	� considerado tamb�m o valor M�ximo dado pelo usu�rio, no momento da configura��o.

	Al�m dos dois deve se considerado o valor inicial, dado pelo leil�o(na refer�ncia).

**/

