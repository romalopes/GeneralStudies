import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.sql.Date;

import ClassesGeral.Enviador;
import ClassesGeral.ObjetoEnviado;
import ClassesGeral.VetorCaracteristica;
import ClassesGeral.Caracteristica;


public class Item extends ObjetoEnviado implements Serializable
{

	VetorCaracteristica vetorCaracteristica;

	public Vector vetorOfertas;
	private double m_somaAvaliacao;
	private Agente m_agente;
	private Pagina m_pagina;
	
	private GregorianCalendar m_dataBusca;
	long m_minutosRestantes;
	Vector  avaliacaoCriterios;
	private boolean m_novo;
	boolean m_comprado;
	boolean m_vendido;
	
	public Item (String n,Agente a,Pagina p)
	{
		super(n);
		m_agente = a;
		m_pagina = p;
		avaliacaoCriterios = new Vector();
		
		vetorCaracteristica = new VetorCaracteristica();

	  vetorCaracteristica.setValorCarac("avaliacaoMinimaOferta",String.valueOf(2));


		vetorOfertas = new Vector();
		
		m_comprado = false;
		m_vendido = false;
		m_somaAvaliacao = 1.0;
	}
	
	public String printCaracteristicas()
	{
		return "comprado="+m_comprado+" Vendido="+m_vendido+"  "+vetorCaracteristica.printCaracteristicas();
	}
	
	/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
			int i;		
			out.writeInt(vetorCaracteristica.size());
			for(i=0;i<vetorCaracteristica.size();i++)
				out.writeObject(vetorCaracteristica.elementAt(i));	
			
///			out.writeObject(m_codigo);
//			out.writeObject(m_descricao);
//			out.writeObject(m_bprecoReserva);
//			out.writeInt(m_precoReserva);			
//			out.writeInt(m_prazo);			
//			out.writeObject(m_nomeDono);
//			out.writeObject(m_nomeVencedorAtual);
//			out.writeObject(m_tipoLeilao);
//			out.writeInt(m_valorInicial);			
//			out.writeInt(m_valorAnterior):
//			out.writeInt(m_valorAtual);			
//			out.writeInt(m_valorVencedor);			
//			out.writeObject(m_caminhoFigura);			
//			out.writeObject(m_nomePagina);
			out.writeDouble(m_somaAvaliacao);			
			out.writeObject(m_agente);			
			out.writeObject(m_pagina);
			out.writeLong(m_minutosRestantes);
			out.writeBoolean(m_novo);			
			out.writeBoolean(m_comprado);
			out.writeBoolean(m_vendido);
		
					
			out.writeInt(avaliacaoCriterios.size());	
			for(i=0;i<avaliacaoCriterios.size();i++)
				out.writeObject(avaliacaoCriterios.elementAt(i));	

			out.writeInt(vetorOfertas.size());	
			for(i=0;i<vetorOfertas.size();i++)
				out.writeObject(vetorOfertas.elementAt(i));	
			
			
			out.flush();
		}	
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do Item" );
		}			
	}
	
/****************************** readObject **********************************/		
	private void readObject(java.io.ObjectInputStream in)  
		throws IOException, ClassNotFoundException
	{
		try
		{
		
			vetorCaracteristica = new VetorCaracteristica();		
			int i,size = in.readInt();
			for(i=0;i<size;i++)
				vetorCaracteristica.addElement(in.readObject());
			
			m_somaAvaliacao = in.readDouble();
			m_agente = (Agente)in.readObject();
			m_pagina = (Pagina)in.readObject();
			m_minutosRestantes = in.readLong();
			m_novo = in.readBoolean();
			m_comprado = in.readBoolean();
			m_vendido = in.readBoolean();
			
			avaliacaoCriterios = new Vector();
			avaliacaoCriterios.removeAllElements();			
			size = in.readInt();
			for(i=0;i<size;i++)
				avaliacaoCriterios.addElement(in.readObject());	

			vetorOfertas = new Vector();
			size = in.readInt();
			for(i=0;i<size;i++)
				vetorOfertas.addElement(in.readObject());	
			
				
		}
		catch(IOException e)
		{
			System.err.println(e+" Erro no read do Item" );
		}
	}
	 
	 
	
	protected void Finalize(){}
	public void Init(){}
	

	public void removeAllCriterios()
	{
		avaliacaoCriterios.removeAllElements();
		m_somaAvaliacao  = (double)0;
	
	}
	
	public void setData(GregorianCalendar d)
	{
		m_dataBusca = d;
	}
	public GregorianCalendar data()
	{
		return m_dataBusca;
	}
	public void setAgente(Agente a)
	{
		m_agente = a;
	}

	public Agente agente()
	{
		return m_agente;
	}

	public Pagina pagina()
	{
		return m_pagina;
	}
	
	public void setNovo(boolean n)
	{
		m_novo = n;
	}
	public boolean novo()
	{
		return m_novo;
	}
	public void setComprado(boolean c)
	{
		m_comprado = c;
	}
	public boolean comprado()
	{
		return m_comprado;
	}
	
	public void setVendido(boolean v)
	{
		m_vendido = v;
	}
	public boolean vendido()
	{
		return m_vendido;
	}
			
	
	public void setMinutosRestantes(long m)
	{
		m_minutosRestantes = m;
	}

	public long minutosRestantes()
	{
		return m_minutosRestantes;
	}
	
	public double somaAvaliacao()
	{
		return m_somaAvaliacao;
	}
	
/**************************** SomaCriterios **********************************/
	public void SomaCriterios()
	{
		if (avaliacaoCriterios.size() == 0)
		{
			m_somaAvaliacao = 1.0;
			return;
		}
		else
			m_somaAvaliacao = 0.0;
			
	
		for(int j = 0;j<avaliacaoCriterios.size();j++)
		{
			Double aval = (Double)avaliacaoCriterios.elementAt(j);
			m_somaAvaliacao += aval.doubleValue();
		}
		m_somaAvaliacao = m_somaAvaliacao/avaliacaoCriterios.size();
	}
	
	
/**************************** avaliacoes **********************************/	
	//pega os Crit�rios e avalia��es e retorna como uma String para mostrar na p�gina
	public String avaliacoes()
	{
		CriterioPreco c;
		StringBuffer buffer = new StringBuffer();
		for(int j=0;j<avaliacaoCriterios.size();j++)
		{
			Double aval = (Double)avaliacaoCriterios.elementAt(j);
			buffer.append("<OL type=\"1\">");
			buffer.append("<LI>");
			c = ((CriterioPreco)m_agente.listCriterios.elementAt(j));
			buffer.append("Avalia��o do Criterio : ");
			buffer.append(c.nomeCriterio());
			buffer.append(" entre "+ c.precoMin()+ " e "+c.precoMax()+" => ");
			buffer.append(aval.toString());
			buffer.append("</LI>\n");
			buffer.append("</OL>");
		}
		buffer.append("\n<UL type=\"square>\"");
		buffer.append("\n<LI>");
		buffer.append("Avalia��o geral");
		buffer.append(" = ");
		buffer.append(somaAvaliacao());
		buffer.append("</LI>\n");
		buffer.append("</UL>");
		
		String s = new String(buffer.toString()); 
		return s;
		
	}

	public void	addValorCriterio(Double c)
	{
		avaliacaoCriterios.addElement(c);
	}
	
	/****************** ConvertePrazoDataMinutos *********************/			
	public void ConvertePrazoDataMinutos(String string)
	{
		//nao implementado
	}
	
	/****************** tempoLeilao *********************/
/**Indica o tempo que o leil�o est� trabalhando, em minutos**/
	public int tempoLeilao()
	{
		String dataInicio = vetorCaracteristica.getValorCarac("dataInicio");
		
		int minutoInicio = (int)Enviador.pegaParteInteiro(dataInicio,0,'/');
		int horaInicio = (int)Enviador.pegaParteInteiro(dataInicio,1,'/');	
		int diaInicio = (int)Enviador.pegaParteInteiro(dataInicio,2,'/');		
		int AnoInicio = (int)Enviador.pegaParteInteiro(dataInicio,3,'/');			

		int minutos=0;
		Calendar calendar = new GregorianCalendar();	
		
		minutos = (calendar.get(Calendar.YEAR) - AnoInicio)*365*24*60;
		minutos += (calendar.get(Calendar.DAY_OF_YEAR) - diaInicio)*24*60;
		minutos += (calendar.get(Calendar.HOUR_OF_DAY) - horaInicio)*60;		
		minutos += (calendar.get(Calendar.MINUTE) - minutoInicio);		
		return minutos;
	}
	
	
	
/*	//Caracteristicas
	public void addCaracteristica(String c)
	{
		 vetorCaracteristicas.addElement(c);
	}
	public String getCaracteristica(int i)
	{
		if(i<vetorCaracteristicas.size())
			vetorCaracteristicas.elementAt(i);
		return "";	
	}
	public int getIndiceCaracteristica(String caracteristica)
	{
		int i=0;
		String caracAtual;
		for(i=0;i<vetorCaracteristicas.size();i++)
		{ 
			caracAtual = (String)vetorCaracteristicas.elementAt(i);
			if(caracteristica.equalsIgnoreCase(caracAtual))
				return i;
		}
		return -1;	
	}	
	public String getValorCaracteristicaNome(String c)
	{
		int i = getIndiceCaracteristica(c);
		String v = getValorCaracteristica(i);
		return v;

	}	
	public void addValorCaracteristica(String c)
	{
		 vetorValorCaracteristicas.addElement(c);
	}
	
	public void setValorCaracteristica(String c,String valor)
	{
		int i = getIndiceCaracteristica(c);	
		if (i == -1)
		{
			System.out.print("***************\n*************\n**********************Inserindo uma caracteristica:"+c);
			addCaracteristica(c);
			vetorValorCaracteristicas.addElement(valor);
		}
		else
			vetorValorCaracteristicas.setElementAt(valor,i);
	}
	public String getValorCaracteristica(int i)
	{
		if(i<vetorValorCaracteristicas.size() && i>-1)
			return (String)vetorValorCaracteristicas.elementAt(i);
		return "";	
	}
	
	//Caracteristicas	
	

	/////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////
//	0           1            2            3                   4 			  5
//NomeDono&prod.Codigo()&prod.nome()&prod.detalhes()&prod.bvalorReserva()&prod.valorReserva()&
//       6                7             8                9
//l.valorInicial()&l.valorAtual()&l.valorVencedor()&l.Prazo()
	public void setCaracteristicas(String frase)
	{
		
		int i=0;
		String StringItem = Enviador.pegaParte(frase,i,'&');
		while(!StringItem.equalsIgnoreCase(""))
		{
				
			this.addCaracteristica(StringItem);			
			i++;
			StringItem = Enviador.pegaParte(frase,i,'&');
			this.addValorCaracteristica(StringItem);
			
			i++;
			StringItem = Enviador.pegaParte(frase,i,'&');
		}		
	}
	*/
}