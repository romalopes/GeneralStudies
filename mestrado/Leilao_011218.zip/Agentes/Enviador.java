import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;


public class Enviador
{
	public Enviador(){};

	static public void EnviaMensagem(String nomeHost,int portaEnvio,ObjetoEnviado Msg)
	{
/***************A partir daqui vai enviar pra alguem.  ***************/
		final String msgErroHost = "\nHost nao encontrado!\n";
		final String msgErroConexao = "\nConexao com Host nao pode ser estabelecida.\n";

		// ---declaracao dos objetos utilizados--- *
		nomeHost = "192.168.0.12";			//Nome do host para conexao, como estou trabalhando na minha m�quina nem preciso pegar o valor do parametro
	
		Socket SimplesSocket = null;			//Declaracao de objeto da classe Socket 

        ServerSocket socketServidor = null;
        Socket ClienteSocket = null;
		OutputStream os = null;
		ObjectOutputStream dos = null;
		ObjectInputStream is = null;

		PrintWriter saida = null;		//Fluxo de saida
		BufferedReader entrada = null;		//Fluxo de entrada

		try {
	   		SimplesSocket = new Socket(nomeHost, portaEnvio); 
					//Objeto sock criado atraves do construtor Socket
					//adequado a uma conexao TCP confiavel (stream).
					//Corresponde as instrucoes socket() e connect() 

		}
		catch(UnknownHostException e) 
		{		//Excecao: host nao e' encontrado
			System.err.println(msgErroHost);
			System.exit(1);
		}
		catch(java.io.IOException e) 
		{		//Excecao: conexao nao pode ser estabelecida
			System.err.println(msgErroConexao);
   			System.exit(1); 
		}

   
		try 
		{
			os = SimplesSocket.getOutputStream();
			dos = new ObjectOutputStream (os);
			is = new ObjectInputStream(SimplesSocket.getInputStream());

			
			dos.writeObject (Msg);

			dos.flush();
			dos.close();
			os.close();
			is.close();
			SimplesSocket.close();
	    }
   		catch (UnknownHostException e) 
		{
    			System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro Exception:  " + e);
		}
		
	}
		
	static public String pegaParte(String palavra, int pos) 
	{
		if(palavra == null)
			return "";
		int index=0,posParte=0,posIndex,i;
		String Parte =  new String();
		try
		{
			for(i = 0;i<=pos;i++)
			{
			    posIndex = palavra.indexOf(',',index);
				if (posIndex == -1)
				{
					Parte = palavra.substring(index,palavra.length());
					break;
				}
				else
				{
					Parte = palavra.substring(index,posIndex);				
					if(i == pos)
						return Parte;
					
				}
				index = posIndex+1;
			}
			if(i == pos)
				return Parte;
			
		}	
		catch (Exception e) {
					System.out.println ("\nErro no PegaParte\n");
		}     
		return "";	
		
	}

	
/*****************************/
}