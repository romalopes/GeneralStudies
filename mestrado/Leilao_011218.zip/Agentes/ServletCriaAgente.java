import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

//Servlet para login
public class ServletCriaAgente extends HttpServlet 
{
	String m_nomeAgente,m_nomeUsuario;
	String m_nomeProduto;

    public void init(ServletConfig servletConfig) throws ServletException
    {
	    super.init(servletConfig);
    }

//	public void doGet(HttpServletRequest request,
//                   HttpServletResponse response)
//  throws ServletException, IOException {  }

	public void printOk(HttpServletRequest request,
						HttpServletResponse response)
	throws ServletException, IOException 

	{
		//chama diretamente o jsp com os seguintes par�metros...
		response.sendRedirect("../jsp/configuracaoAgente.jsp?nomeUsuario="+m_nomeUsuario+"&nomeAgente="+m_nomeAgente+"&nomeProduto="+m_nomeProduto);		

	}
	
	public void printFalha(HttpServletResponse response)
	throws ServletException, IOException 

	{
		response.setContentType("text/html");
    	PrintWriter out = response.getWriter();
    	String title = "Login Falha";
		out.println("<html>");
		out.println("<head><title>Login Falha</title></head>");
		out.println("<BODY BGCOLOR=\"#FDF5E6\">\n" +
                "<H1 ALIGN=CENTER>" + title + "</H1>\n" +
                "<TABLE BORDER=1 ALIGN=CENTER>\n" +
                "<TH>Nome rejeitado" );
		out.println("</body></html>");
	}

	public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
      throws ServletException, IOException 
	{    
        m_nomeUsuario = request.getParameter("nomeUsuario");
        m_nomeAgente = request.getParameter("nomeAgente");
		m_nomeProduto = request.getParameter("nomeProduto");
  		String ip = request.getRemoteAddr();    		
		Mensagem Msg = new Mensagem(m_nomeUsuario,ip);
		Msg.setMensagem("criaagente");
		Msg.setMensagemAux(m_nomeAgente+","+m_nomeProduto);		
		Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
      	Mensagem mensagem = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);

/**********************************************/
		String valor = mensagem.mensagemAux();
		if ((valor != null) && (valor.equals("cadastrado")))
		{
			m_nomeUsuario = mensagem.nome();
			printOk(request,response);
	    }
            else
            {
            	printFalha(response);
            }			
	}
}