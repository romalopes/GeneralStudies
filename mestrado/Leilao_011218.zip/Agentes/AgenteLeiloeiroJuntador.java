/**classe Final Agente de Leiloeiro**/

import java.io.*;    //Package de classes para manipulacao de E/S

import java.util.*;

import java.net.*;

import ClassesGeral.Enviador;
import ClassesGeral.Mensagem;

/**
	Esse Leiloeiro junta v�rios leiloes a partir de uma determinada configura��o 
	e cria um novo e aconselha aos compradores.
	
Procedimento do Agente Leiloeiro
	Configurado Pelo Usu�rio
	Visita Agentes Compra(pode realizar isso atrav�s do site de leil�o)
			Verifica Perfis e tenta achar compradores com perfis parecidos e interessantes, nesse passo o agente leiloeiro j� deve saber o perfil que ele procura.

//	Visita Sites de Leil�es
//		Procura produtos para os agentes com os perfis interessantes

	Visita os Agentes de Venda

	Convida os Agentes
		Convida os agente 
		

	Inicia o Leil�o no ambiente AgILE
		O fato de Iniciar o leil�o pode implicar na entrada em algum leil�o de um site j� existente .
		Recebe notifica��o das ofertas dos agentes e de outros.
		Responde d�vidas.
	Fecha Leil�o
	Entra Entra em contato com o vendedor e oferece o pre�o com �gil para que ele diga o comprador
		D� o contato do comprador para o vendedor e visse-versa	
*/

final public class AgenteLeiloeiroJuntador extends AgenteLeiloeiro
{

public class Grupo extends Object implements Serializable
{
	public
		AgenteVenda vendedor1,vendedor2;
		
		/****************************** writeObject **********************************/
		private void writeObject(java.io.ObjectOutputStream out)
		     throws IOException
		{
			try
			{
			
				out.writeObject(vendedor1);
				out.writeObject(vendedor2);
				out.flush();
			}
			catch(IOException e)
			{
				System.err.println(e+ " Erro no write do Grupo do AgenteLeiloeiroJuntador" );
			}
		}
	
	/****************************** readObject **********************************/
		 private void readObject(java.io.ObjectInputStream in)  
		 	throws IOException, ClassNotFoundException
		 {
			try
			{
				vendedor1 = (AgenteVenda)in.readObject();
				vendedor2 = (AgenteVenda)in.readObject();
			 }
			 catch(IOException e)
			 {
			 	System.err.println(e+" Erro no read do Grupo AgenteLeiloeiroJuntador" );
			 }
		}
		
		
		
}

	private Vector vetorVetorCaracProdutos;//esse vai ser um vetor de vetor de �tens. cada vetor dentro do vetor vai conter v�rios itens que ser�o comprarados com os itens dos outros vetores para serem oferecidos aos compradores.
	private Vector m_vetorGrupos;

	public AgenteLeiloeiroJuntador(String usu,String n)
	{
		super(usu,n);
		try
		{	
			setTipo("Juntador");
//			setTipoLeiloeiro("Juntador");			
			
			//somente por enquanto, isso vai ser criado de forma externa
//			CriterioPreco c = new CriterioPreco((float)1);
//			listCriterios.addElement(c);	
			//adciona a p�gina AKRM.
			Pagina pag = addPagina("AKRM");
			pag.vetorCaracteristica.setValorCarac("tipoLeilao","Ingles");
			
			
			vetorVetorCaracProdutos = new Vector();
			Vector v = new  Vector();
			vetorVetorCaracProdutos.addElement(v);

			m_vetorGrupos = new Vector();
			
			setStringErro("no Agente LeiloeiroJuntador:"+nome());
			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro na Cria��o do AgenteLeiloeiroJuntador" );
		}
	}
	public AgenteLeiloeiroJuntador(String usu,String n,Gerente gerente)
	{
		super(usu,n,gerente);
		
		setTipo("Juntador");

		vetorVetorCaracProdutos = new Vector();
		m_vetorGrupos = new Vector();

//		setTipoLeiloeiro("Aconselhador");

		try
		{	
			Pagina pag = addPagina("AKRM");
			pag.vetorCaracteristica.setValorCarac("tipoLeilao","Ingles");			
			m_vetorGrupos = new Vector();
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro na Cria��o do AgenteLeiloeiroJuntador" );

		}
		//somente por enquanto, isso vai ser criado de forma externa
		CriterioPreco c = new CriterioPreco((float)1);
		listCriterios.addElement(c);	
	}


	/****************************** writeObject **********************************/
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{
			int i;		
			
			out.writeInt(vetorVetorCaracProdutos.size());
			for(i=0;i<vetorVetorCaracProdutos.size();i++)
			{
				Vector vetor = (Vector)vetorVetorCaracProdutos.elementAt(i);
				out.writeInt(vetor.size());
				for(int j=0;j<vetor.size();j++)
				{
					out.writeObject(vetor.elementAt(j));
				}
			}
			out.writeInt(m_vetorGrupos.size());
			Grupo g;
			for(i=0;i<m_vetorGrupos.size();i++)
			{
				g = (Grupo)m_vetorGrupos.elementAt(i);
				out.writeObject(g);
			}
			
			out.flush();
		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do AgenteLeiloeiroJuntador" );
		}
	}

/****************************** readObject **********************************/
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			int i;
			
			int size = in.readInt();
			vetorVetorCaracProdutos = new Vector();
			for(i=0;i<size;i++)
			{
				Vector vetor = new Vector();
				int size2 = in.readInt();
				for(int j=0;j<size2;j++)
				{
					vetor.addElement(in.readObject());
				}
				vetorVetorCaracProdutos.addElement(vetor);				
			}
			size = in.readInt();
			m_vetorGrupos = new Vector();
			for(i=0;i<size;i++)
			{
				m_vetorGrupos.addElement(in.readObject());
			}
		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read do AgenteLeiloeiroJuntador" );
		 }
	}


/**************** nomeProduto() ****************/
//junta os nomes que foram passados para a procura, tirando a v�rgula
	public String nomeProduto() 
	{
		String string,stringTotal = ""  ;
		try
		{	
			int i=0;
			
			String detalhes_1 = this.vetorCaracteristica.getValorCarac("detalhes_1");
			String detalhes_2 = this.vetorCaracteristica.getValorCarac("detalhes_2");
			String detalhes = detalhes_1+" "+detalhes_2;
			System.out.println("detalhes: "+detalhes);
			return detalhes;
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no nomeProduto do Leiloeiro juntador"+ nome() );
		}
		return null;
		
	}
	
	


/************************** encontraRelacaoAgente *****************************
//tenta achar a relacao entre os agentes e o Leiloeiro
//poderia verificar a relacao entre os agentes.	ou mesmo verificar alguma coisa que os agente podem possuir de correlatos.
	private boolean encontraRelacaoAgente(Agente ag)
	{
		try
		{
			return Enviador.encontraRelacaoPalavras(nomeProduto(),ag.nomeProduto());
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no encontraRelacaoAgente Agente de Leiloeiro " + nome());
		}
		return false;
	}
	
/************************** BuscaAgentesCompra *****************************
//Pesquisa os Agente de compra para ver se eles possuem as prefer�ncias especificadas 

	private String BuscaAgentesCompra()	throws Exception 
	{
		boolean relacao = true;
		int j=0,i;
		try
		{
			System.out.println ("Busca agentes de compra com: "+ nomeProduto());
			this.appendHistoria("Pesquisa os agentes de Compra com: "+ nomeProduto());

			setBuscando(true);

			//acho que o ideal seria enviar mensagens, mas fica dificil de conseguir consistencia
			for(i=0;i<m_gerente.m_listAgentes.size();i++)
			{
				Agente ag = (Agente)m_gerente.m_listAgentes.elementAt(i);
				if(!ag.tipo().equalsIgnoreCase("compra"))
					continue;

				//aqui analisa se os agentes possuem as caracteristicas desejadas para que o leiloeiro ofereca o produto.				
				relacao = encontraRelacaoAgente(ag);//poderia verificar a relacao entre os agentes.	

				if (relacao)
				{
					this.appendHistoria("Achou o agente de compra "+ ag.nome()+" interessante");
					listAgentesCompra.addElement(ag);
				}
			}
			setBuscando(false);

			i = estagio();
			setVezes(0);
			setEstagio(++i);	
			executaEstrategia();

//			EscolheAgentes();
		}
		catch(Exception e) 
		{

			System.err.println ("\nErro no Busca Ag Compra do Agente de Leiloeiro " + e);
			return "erro";
		}     
		EscolheItens();
		return "ok";
	}

	
	
/************************** buscaAgentesVenda *****************************/
//Pesquisa os Agente de venda para ver se eles oferecem os produtos especificados 
	private String buscaAgentesVenda()	throws Exception 
	{//deveria enviar uma mensagem para o gerente. 
		boolean relacao = true;
		int j=0,i;
		try
		{
//			System.out.println ("Busca por agentes de venda com:"+ nomeProduto());
			this.appendHistoria("Pesquisa os agentes de venda com: "+ nomeProduto());

			setBuscando(true);

			//acho que o ideal seria enviar mensagens, mas fica dificil de conseguir consistencia
			for(i=0;i<m_gerente.m_listAgentes.size();i++)
			{
				Agente ag = (Agente)m_gerente.m_listAgentes.elementAt(i);
				if(!ag.tipo().equalsIgnoreCase("venda"))
					continue;

				//aqui analisa se os agentes possuem as caracteristicas desejadas para que o leiloeiro ofereca o produto.				
				relacao = encontraRelacaoAgenteVenda(ag);//poderia verificar a relacao entre os agentes.	

				if (relacao)
				{
					this.appendHistoria("Achou o agente de venda "+ ag.nome()+" interessante");
					listAgentesVenda.addElement(ag);
				}
			}
			setBuscando(false);

			i = estagio();
			setVezes(0);
			setEstagio(++i);	
			executaEstrategia();
		}
		catch(Exception e) 
		{

			System.err.println ("\nErro no Busca Ag Venda do Agente de Leiloeiro " + e);
			return "erro";
		}     
		EscolheItens();
		return "ok";
	}

	
/************************** RemoveItensExcedentes *****************************
//Somente Deixa os que est�o na faixa do permitido(numMaxItens)
//No futuro vai remover os que tiver abaixo da satisfa��o desejada tamb�m.
//deve ser chamado depois da ordena��o.
	public void	RemoveItensExcedentes()
	{
		for(int i = numMaxItens(); i<listItens.size();i++)
		{

			Item it = (Item)listItens.elementAt(i);
			listItens.removeElementAt(i);

		}
	}


/************************** passaRestricoes *****************************/			
	public void	passaRestricoes()
	{
	}
	

/************************** OrdenaItens *****************************
/**O que tem maior avalia��o primeiro*
	public void OrdenaItens()
	{
		Item itAtual,it;
		int size = listItens.size();
		double avalMelhor;
		int posMelhor;
		

		//deppois melhoro essa ordena��o		
		for(int i = 0; i<listItens.size();i++)
		{
			itAtual = (Item)listItens.elementAt(i);
			avalMelhor = itAtual.somaAvaliacao();
			posMelhor = i;
			for(int j = i;j<listItens.size();j++)
			{
				it = (Item)listItens.elementAt(j);
				//se o item for maior insere nessa posi��o se n�o vai inserir mais pra baixo
				if (avalMelhor < it.somaAvaliacao())
				{			
					avalMelhor = it.somaAvaliacao();
					posMelhor = j;
				}
			}

			it = (Item)listItens.elementAt(posMelhor);
			listItens.removeElementAt(i);			
			listItens.insertElementAt(it,i);			
			listItens.removeElementAt(posMelhor);			
			listItens.insertElementAt(itAtual,posMelhor);			
		}
	}

	

/************************** EscolheItens *****************************
/**de todos os Itens j� pegos nas p�ginas ir� escolher algumas de acorod com os crit�rios e restri��es*
	public void EscolheItens()
	{
		Item item;
		//para cada Itens verifica a alternativa
		for(int i = 0; i<listItens.size();i++)
		{
			item = getItemAt(i);
			item.removeAllCriterios();
			for(int j = 0;j<listCriterios.size();j++)
			{
				Criterio c = (Criterio)listCriterios.elementAt(j);
				item.addValorCriterio(c.CalculaCriterio(item));
			}
			//soma os crit�rios para depois ordenar
			item.SomaCriterios();
		}
		//passa as restri��es...
		passaRestricoes();
		
		//Ordena
		OrdenaItens();
		
		//Remove
		RemoveItensExcedentes();
	}
	
/*********************** BuscaLeiloes() *****************************/
	protected String BuscaLeiloes() 	throws Exception 
	{
		Item item;
		int j=0;
	
		try
		{
		
//			System.out.println ("Busca por "+ nomeProduto());
			this.appendHistoria("Busca por "+ nomeProduto());

			setBuscando(true);

			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				pag.IniciaBusca();
//				System.out.println ("\nBusca na pagina "+pag.nome());
				do
				{
					j++;
					item = pag.Busca(nomeProduto());//aqui no futuro vai buscar com v�rios nomes diferentes para juntar.
					if(item!=null)
						this.addItem(item);
				}while (item != null );
				pag.finalizaConexao();
			}
			setBuscando(false);
			EscolheItens();
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no Busca do Agente de compra " );
			return "erro";
		}     
		return "ok";
	}
	
/*********************** RecebeMensagemBusca *****************************/	
	public Mensagem recebeReplyBuscaProdutos(Mensagem msg) 	throws Exception 
	{
		Item item;
		try
		{
			String StringItem;
			this.appendHistoria("Reply busca produtos ");
			msg.setMensagemRetorno(false);
			String	mensagemAux = msg.mensagemAux();
			msg.setReply(false);
			int i=0;
			Pagina pag = findPagina("AKRM");
			if (pag == null)
			{
				this.appendHistoria("Inconsistencia na p�ginha AKRM ");
				return msg;
			}
			i=0;
			StringItem = Enviador.pegaParte(mensagemAux,i,';');
			while(!StringItem.equalsIgnoreCase(""))
			{
//				System.out.println(StringItem);
				item = new Item(Enviador.pegaParte(StringItem,1,'&'),this,pag);
				addItem(item);
				String palavra;
				item.vetorCaracteristica.setCaracteristicas(StringItem);

				String nomeProd = item.vetorCaracteristica.getValorCarac("nomeProduto");
				if(!nomeProd.equals(""))
					item.setNome(nomeProd);
					
				item.vetorCaracteristica.setValorCarac("valorAtual",item.vetorCaracteristica.getValorCarac("valorinicial"));
				item.vetorCaracteristica.setValorCarac("valorVencedor",item.vetorCaracteristica.getValorCarac("valorinicial"));
//				System.out.println ("\nPegou prod" + StringItem);
				i++;
				StringItem = Enviador.pegaParte(mensagemAux,i,';');
			}		
			i = estagio();
			setVezes(0);
			setEstagio(++i);	
			executaEstrategia();
			mensagemAux = msg.mensagemAux();
			this.appendHistoria("Retornou da Busca com produtos");//Resultado Busca "+ mensagemAux);
			
			EscolheItens();
		}
		catch(Exception e) 
		{

			System.err.println ("\nErro no Busca do Agente de compra " + e);
		}     
		msg.setMensagemRetorno(true);

		return msg;
	}

/**************************	recebeReplyRegistroAKRM ********************/
	public Mensagem recebeReplyRegistroAKRM(Mensagem msg) 	throws Exception 
	{
		try
		{
			this.appendHistoria("Reply de Registro AKRM TRUE");
			msg.setReply(false);
			Pagina pag = findPagina("AKRM");
			if (msg.mensagemRetorno())
			{
				pag.setRegistrado(true);
				int i = estagio();
				setEstagio(++i);
				executaEstrategia();
			}
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no recebeReplyRegistroAKRM do Agente de compra " + e);
		}     
		
		return msg;	
	}	
/**************************	recebeReplyRecebeConviteLeilaoVenda ********************/
//Recebe o reply da oferta do leil�o ao agente de venda
	public Mensagem recebeReplyRecebeConviteLeilaoVenda(Mensagem msg)
	{
		try
		{
			this.appendHistoria("Reply de recebeReplyRecebeConviteLeilaoVenda resultado:"+msg.mensagemRetorno() + "vindo de "+msg.origem());
			msg.setReply(false);


			Item it = findItemNome(msg.mensagemAux());
			
			if (it == null)
			{
				it = new Item(msg.mensagemAux(),this,new PaginaAKRM(this));
				addItem(it);
				msg.setMensagemRetorno(false);
			}

			String nomeVendedores = it.vetorCaracteristica.getValorCarac("nomeVendedores");
			
			if(nomeVendedores.equals(""))
				nomeVendedores = msg.origem();
			else 
				nomeVendedores = msg.origem()+","+nomeVendedores;
				
			it.vetorCaracteristica.setValorCarac("nomeVendedores",nomeVendedores);
//			System.out.println(nomeVendedores);
			
			int quant = it.vetorCaracteristica.getValorCaracInteiro("QuantidadeVendedores");
			quant++;
			it.vetorCaracteristica.setValorCarac("QuantidadeVendedores",String.valueOf(quant));
			it.vetorCaracteristica.setValorCarac("podeFechar","1");
			
//			System.out.println("this.nomeUsuarioPagina():"+this.nomeUsuarioPagina());
			it.vetorCaracteristica.setValorCarac("nomeLeiloeiro",this.nomeUsuarioPagina());
			
			
//			System.out.println("msg.origem"+msg.origem());
			if (msg.mensagemRetorno())
			{
	//pode fazer alguma coisa
				int i= estagio();
				setVezes(0);
				setEstagio(++i);
				executaEstrategia();
			}
		}
		catch(Exception e) 
		{
			System.err.println ("\nErro no recebeReplyRecebeConviteLeilaoVenda do Agente de compra " + e);
		}     
		return msg;	//por enquanto vai apenas retornar a mesma msg
		
	}

/**************************	ofereceLeiloesAgenteVenda ********************/
	public boolean ofereceLeiloesAgenteVenda()
	{//talvez devesse enviar uma mensagem.
	//nao vamos pegar os agente diretamente, vamos usar somente os 
	//seus atributos pois no futuro nao utilizaremos a classe agente.
		try
		{
			AgenteVenda ag;
			Item it;
			String idItem,msgAux;
			int j,i;
			this.appendHistoria("Oferecendo novas oportunidades aos agentes de venda");
//			System.out.println(" estou Oferecendo novas oportunidades aos agentes de venda"+nome());
			if (listAgentesVenda.size() == 0)
			{
				this.appendHistoria("N�o h� agentes de venda na minha lista");
				return false;
				
			}
			
			
			Grupo grupo;
			for(i=0;i<m_vetorGrupos.size();i++)
			{
				grupo = (Grupo)m_vetorGrupos.elementAt(i);

				//se chegou at� aqui � porque vai oferecer.
				Mensagem msg = new Mensagem(this.nome(), Enviador.nomeHostGerente  );
				msg.setMensagem("recebeConviteLeilao");//vendedor
				msg.setOrigem(this.nomeUsuarioPagina());
				msg.setTipo("Agente");
//				msg.setReply(true);
				msg.setReply(false);
				msg.setMensagemRetorno(true);
//aqui devemos colocar as caracter�sticas. do leil�o para que o agente de venda possa verificar se o leil�o � satisfat�rio.				
//				System.out.println("this.nomeUsuarioPagina():"+this.nomeUsuarioPagina());
				msgAux = "nomeProduto,"+nomeProduto()+",nomeLeiloeiro,"+this.nomeUsuarioPagina()+",valorReservaTotal,"+this.vetorCaracteristica.getValorCarac("valorReserva");//caracteristicaProduto();//idItem+","+it.pagina().nome(); 
				msg.setMensagemAux(msgAux);//

//				System.out.println("vend1:"+grupo.vendedor1.nomeUsuarioPagina());
				
//jatLite				
				msg.setDestino(grupo.vendedor1.nomeUsuarioPagina());
				Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,msg);		
//				msg.setOrigem(this.nome());
//				msg.setDestino(grupo.vendedor1.nome());
//				agDelegate.enviaMensagem(msg);
//jatLite
				
				//ofere ao segundo vendedor
//				System.out.println("vend2:"+grupo.vendedor2.nomeUsuarioPagina());
				
//jatLite				
				msg.setDestino(grupo.vendedor2.nomeUsuarioPagina());
				Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,msg);		
//				msg.setOrigem(this.nome());
//				msg.setDestino(grupo.vendedor2.nome());
//				agDelegate.enviaMensagem(msg);								
//jatLite				
			}
			
		}
		catch(Exception e)
		{
			System.err.println(e+"Erro no ofereceLeiloesAgenteVenda do Leiloeiro");
		}
		
		return true;
	}


	
	/************************** juntaGruposAgenteVenda *****************************/	
	public void juntaGruposAgenteVenda()
	{
		try
		{
		
			Grupo grupo;
			
			if (listAgentesVenda.size()>1)//ainda est� muito preliminar.
			{
				String stringVend1,stringVend2;
				int intVend1,intVend2;
				double doubleVend1,doubleVend2;
				grupo = new Grupo();
				//por enquanto cada grupo s� pode ter dois vendedores.
				grupo.vendedor1 = (AgenteVenda)listAgentesVenda.elementAt(0);
				grupo.vendedor2 = (AgenteVenda)listAgentesVenda.elementAt(1);				
				m_vetorGrupos.addElement(grupo);
				
				this.vetorCaracteristica.setValorCarac("tipoLeilao","Ingles");

				//valor Inicial
				doubleVend1 = grupo.vendedor1.vetorCaracteristica.getValorCaracDouble("valorInicial");
				doubleVend2 = grupo.vendedor2.vetorCaracteristica.getValorCaracDouble("valorInicial");
				if(doubleVend1>doubleVend2)
					doubleVend1 = doubleVend2;
				this.vetorCaracteristica.setValorCarac("valorInicial",String.valueOf(doubleVend1+doubleVend2));//seta a soma dos valoresseta o menor pra
			
				//Prazo				
				intVend1 = grupo.vendedor1.vetorCaracteristica.getValorCaracInteiro("Prazo");
				intVend2 = grupo.vendedor2.vetorCaracteristica.getValorCaracInteiro("Prazo");
				if(intVend1>intVend2)//pega o menor prazo.
					intVend1 = intVend2;

				this.vetorCaracteristica.setValorCarac("Prazo",String.valueOf(intVend1));//seta o menor prazo

				//menor Diferenca				
				doubleVend1 = grupo.vendedor1.vetorCaracteristica.getValorCaracDouble("menordiferenca");
				doubleVend2 = grupo.vendedor2.vetorCaracteristica.getValorCaracDouble("menordiferenca");
				doubleVend1 = doubleVend1+doubleVend2;
				this.vetorCaracteristica.setValorCarac("menordiferenca",String.valueOf(doubleVend1));//seta a soma dasDiferenca

				//bValorReserva
				stringVend1 = grupo.vendedor1.vetorCaracteristica.getValorCarac("bValorReserva");
				stringVend2 = grupo.vendedor2.vetorCaracteristica.getValorCarac("bValorReserva");
				if(stringVend1.equalsIgnoreCase("true") || stringVend2.equalsIgnoreCase("true"))
					stringVend1 = "true";
				this.vetorCaracteristica.setValorCarac("bValorReserva",stringVend1);//se um dos dois tiverem valor reserva pega-se o valor reserva deles

				//valorReserva
				doubleVend1 = grupo.vendedor1.vetorCaracteristica.getValorCaracDouble("ValorReserva");
				doubleVend2 = grupo.vendedor2.vetorCaracteristica.getValorCaracDouble("ValorReserva");
				this.vetorCaracteristica.setValorCarac("valorReserva",String.valueOf(doubleVend1+doubleVend2));//seta a soma dos valores de reserva
				
				//detalhes
				stringVend1 = grupo.vendedor1.vetorCaracteristica.getValorCarac("detalhes");
				stringVend2 = grupo.vendedor2.vetorCaracteristica.getValorCarac("detalhes");
				this.vetorCaracteristica.setValorCarac("detalhes",stringVend1+".  "+stringVend2);//soma-se os detalhes dos dois.


				//numeroOfertasMinimo
				intVend1 = grupo.vendedor1.vetorCaracteristica.getValorCaracInteiro("numeroOfertasMinimo");
				intVend2 = grupo.vendedor2.vetorCaracteristica.getValorCaracInteiro("numeroOfertasMinimo");
				this.vetorCaracteristica.setValorCarac("numeroOfertasMinimo",String.valueOf(intVend1+intVend2));//soma-se os detalhes dos dois.
				
				//fatorNumeroEstrelas
				intVend1 = grupo.vendedor1.vetorCaracteristica.getValorCaracInteiro("fatorNumeroEstrelas");
				intVend2 = grupo.vendedor2.vetorCaracteristica.getValorCaracInteiro("fatorNumeroEstrelas");
				if(intVend1<intVend2)
					intVend1 = intVend2;
				this.vetorCaracteristica.setValorCarac("fatorNumeroEstrelas",String.valueOf(intVend1));//soma-se os detalhes dos dois.				

				//fatorValorReserva
				doubleVend1 = grupo.vendedor1.vetorCaracteristica.getValorCaracDouble("fatorValorReserva");
				doubleVend2 = grupo.vendedor2.vetorCaracteristica.getValorCaracDouble("fatorValorReserva");
				this.vetorCaracteristica.setValorCarac("fatorValorReserva",String.valueOf(doubleVend2+doubleVend2));//soma-se os detalhes dos dois.				

				//fatorValorReserva
				doubleVend1 = grupo.vendedor1.vetorCaracteristica.getValorCaracDouble("fatorPrazo");
				doubleVend2 = grupo.vendedor2.vetorCaracteristica.getValorCaracDouble("fatorPrazo");
				this.vetorCaracteristica.setValorCarac("fatorPrazo",String.valueOf(doubleVend2+doubleVend2));//soma-se os detalhes dos dois.				

				//nivelConcorrencia
				intVend1 = grupo.vendedor1.vetorCaracteristica.getValorCaracInteiro("nivelConcorrencia");
				intVend2 = grupo.vendedor2.vetorCaracteristica.getValorCaracInteiro("nivelConcorrencia");
				this.vetorCaracteristica.setValorCarac("nivelConcorrencia",String.valueOf(intVend1+intVend2));//soma-se os detalhes dos dois.				
				
				
			}
			int i = estagio()+1;
			setEstagio(i);
			executaEstrategia();
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no juntaGruposAgenteVenda de:"+nome());
		}
	}
	

/************************ ofereceVendaEfetuadaVendedores ************************/	
	public void ofereceVendaEfetuadaVendedores()
	{
		try
		{
		
		
		
		
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no ofereceVendaEfetuadaVendedores de:"+nome());
		}
		
	}			
/************************** fazContatos *****************************/	
	public void fazContatos()
	{
		try
		{
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no fazContatos de:"+nome());
		}
		
	}
	
	/************************** estagioString ***************************/			
	public String estagioString()
	{
		if(estagio() == 0)
			return "Est�gio de Busca por Leil�es";
		else if(estagio() == 1)
			return "Est�gio de Busca pelos agentes de Compra";
		else if(estagio() == 2)
				return "Est�gio de Busca pelos agentes de Venda";
		else if(estagio() == 3)
				return "Est�gio para relacionar os produtos dos vendedores";
		else if(estagio() == 4)
				return "Est�gio para oferecer os leil�es aos vendedores";
		else if(estagio() == 5)
				return "Est�gio de registro nos leil�es";
		else if(estagio() == 6)
				return "Est�gio de Insers�o dos produtos";
		else if(estagio() == 7)
				return "Est�gio de cria��o dos leil�es";
		else if(estagio() == 8)
				return "Est�gio para oferecer os leil�es aos agente de compra";
		else if(estagio() == 9)
				return "Est�gio para an�lise das ofertas";
		else if(estagio() == 10)
				return "Est�gio para negocia��o final com o vendedor";
		else if(estagio() == 11)
				return "Est�gio de contatos comprador-vendedor";
				
				
		return "Est�gio n�o relacionado";
	}
	
	/************************** executaEstrategia() ***************************/				
	//depois de receber o aviso verifica se j� est� trabalhando e continua a estrat�gia.
	public synchronized void executaEstrategia()
	{
		try
		{
			this.appendHistoria("Verifica estrat�gia. Estagio:"+estagioString()+" Vezes:"+vezes());
//			System.out.println(nome()+"Executando estrategia. estagio:"+estagioString()+" Vezes:"+vezes());
			int i = vezes();
			setVezes(++i);
			if (estagio() == 0)//busca pelos itens
			{
//				BuscaLeiloes();
				i = estagio()+1;
				setEstagio(i);
			}
			if (estagio() == 1)//busca pelos agentes
			{
				buscaAgentesCompra();//Busca os Agentes de compra;
			}
			else if (estagio() == 2)//busca pelos agentes de venda
			{
				buscaAgentesVenda();
			}
			else if (estagio() == 3)//junta os produtos dos vendedores em grupos
			{
				juntaGruposAgenteVenda();
			}
			else if (estagio()==4)//Oferece os produtos juntados aos vendedores.  Somente os produtos dos vendedores que permitirem a venda.
			{
				ofereceLeiloesAgenteVenda();
			}
			else if (estagio() == 5)//registrar
				registrar();
			else if (estagio() == 6)//InsereProdutosPaginas
				insereProdutosPaginas();
			else if (estagio() == 7)
				criaLeiloes();			
			else if (estagio() == 8)//oferece o produto aos agentes de compra
			{
				if (OfereceLeiloesAgenteCompra())
				{
					i = estagio()+1;
					setEstagio(i);
				}
			}
			else if (estagio() == 9)
			{//verificar se j� pode fechar os leil�es.
			
				if(estrategia() != null)
					estrategia().analisaSituacaoItens();

			}
			else if (estagio() >= 10)
			{
//				setTrabalhando(false);
//				ofereceVendaEfetuadaVendedores();
			}
			else if (estagio() == 11)
			{
				fazContatos();
			}
			
			else if (estagio()>11)
			{
				System.out.println ("Est�gio maior que 3:"+nome());
			}
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no executaEstrategia de:"+nome());
		}   
	}



	

	public void Init(){}




/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/*******************Parte do Agente de Venda que n�o d� pra pegar a Heran�a...
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/

/******************** criaLeiloes *****************************/	
	public synchronized void criaLeiloes()
	{
		try
		{
			boolean todosCriados=true;
			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				if(!pag.leilaoCriado())
					todosCriados = false;
			}
			if (todosCriados)
			{
				int i = estagio();
				setVezes(0);
				setEstagio(++i);	
				executaEstrategia();
				return;
			}
			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				pag.criaLeilao();
			}

		}
		catch (Exception e)
		{
			System.err.println(e+" Erro no Cria Leiloes do Agente LeiloeiroJuntador:"+stringErro());
		}
	}
	
	
	/******************** avisaVendedorCriacaoLeilao *****************************/	
	public void avisaVendedorCriacaoLeilao(Item it)
	{
		try
		{
			//na mensagem vai passar o it.nome como nome da mensagem para o vendedor saber sobre quem vai procurar...
			Mensagem msg = new Mensagem(it.nome(),Enviador.nomeHostGerente  );
			
			msg.setMensagem("recebeAvisoVendedorCriacaoLeilao");//vendedor
			msg.setOrigem(this.nomeUsuarioPagina());
			msg.setTipo("Agente");
			msg.setReply(false);
			msg.setMensagemAux(it.vetorCaracteristica.getBufferCaracteristica());//
			msg.setMensagemRetorno(true);
//jatLite			
			msg.setDestino(it.vetorCaracteristica.getValorCarac("nomeVendedores"));			
			Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,msg);		
/*			
			String nomeVend = it.vetorCaracteristica.getValorCarac("nomeVendedores");
			String s1;
			int i=0;
			msg.setOrigem(this.nome());
			while (!Enviador.pegaParte(nomeVend,i,',').equals("")  )
			{
				s1 = Enviador.pegaParte(nomeVend,i,',');
				i++;
				msg.setDestino(s1);
				agDelegate.enviaMensagem(msg);
			}
			*/
//jatLite			
		}
		catch (Exception e)
		{
			System.err.println(e+" Erro no avisaVendedorCriacaoLeilao do Agente LeiloeiroJuntador:"+stringErro());
		}
	
	}
	
	
	/******************** recebeReplyCriaLeilaoAKRM *****************************/	
	public Mensagem recebeReplyCriaLeilaoAKRM(Mensagem msg) 	throws Exception 
	{
		try
		{
			this.appendHistoria("Reply de recebeReplyCriaLeilaoAKRM resultado:"+msg.mensagemRetorno());
			msg.setReply(false);
			Pagina pag = findPagina("AKRM");
			String stringItem = msg.mensagemAux();			
			if (msg.mensagemRetorno())
			{
//Aqui cria o item para ficar no padr�o para oferecer ao agente de compra
				Item it;		//nome do produto, this do Agente e ponteiro para a pag.
				it = findItemNome(Enviador.pegaParte(stringItem,3,'&'));
				

				if (it == null)
				{
					System.err.println("Erro, pegou item errado");
					return msg;
				}
				
				String palavra;
				it.vetorCaracteristica.setCaracteristicas(stringItem);
				
//				addItem(it);
				
//				System.out.println ("valorInicial" + it.vetorCaracteristica.getValorCarac("valorinicial"));
				it.vetorCaracteristica.setValorCarac("nomeLeiloeiro",this.nomeUsuarioPagina());
				it.vetorCaracteristica.setValorCarac("valorAtual",it.vetorCaracteristica.getValorCarac("valorinicial"));
				it.vetorCaracteristica.setValorCarac("valorVencedor",it.vetorCaracteristica.getValorCarac("valorinicial"));
				///////////////////				

				avisaVendedorCriacaoLeilao(it);
				
				pag.setLeilaoCriado(true);
				int i= estagio();
				setVezes(0);
				setEstagio(++i);
				executaEstrategia();
			}
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no recebeReplyCriaLeilaoAKRM do Agente LeiloeiroJuntador " + e);
		}     
		return msg;	
	}	
	
	/************************** repassaInformacaoVendedores ***************************/		
	private void repassaInformacaoVendedores(Oferta oferta)
	{
		try//seria por mensagem.
		{
			String codProd = oferta.codProd();			
			
			Item it = findItemID(codProd);
	
			//se chegou at� aqui � porque vai oferecer.
			Mensagem msg = new Mensagem(this.nome(), Enviador.nomeHostGerente  );
			msg.setMensagem("recebeReplyOferta");
			msg.setOrigem(this.nomeUsuarioPagina());
			msg.setTipo("Agente");
			msg.setReply(false);
			msg.setMensagemRetorno(true);
			
			String msgAux = oferta.nomeUsuario()+","+oferta.codProd()+","+oferta.valorOferta()+","+oferta.numeroEstrelas();			
//			System.out.println(msgAux);
			msg.setMensagemAux(msgAux);

//jatLite			
			//ofere aos dois vendedores
			msg.setDestino(it.vetorCaracteristica.getValorCarac("nomeVendedores"));
			Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,msg);		
/*			String nomeVend = it.vetorCaracteristica.getValorCarac("nomeVendedores");
			String s1;
			int i=0;
			msg.setOrigem(this.nome());
			while (!Enviador.pegaParte(nomeVend,i,',').equals("")  )
			{
				s1 = Enviador.pegaParte(nomeVend,i,',');
				i++;
				msg.setDestino(s1);
				agDelegate.enviaMensagem(msg);
			}
			*/
//jatLite			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no repassaInformacaoVendedores "+stringErro());
		}
		
	
	}
	
	/************************** recebeReplyOfertaM ***************************/	
//Recebe a informa��o de que houve uma oferta.
	public void recebeReplyOferta(Mensagem msg) 	throws Exception 
	{//Quatro situacoes.  1 - Aceito, 2 - Outra Pessoa efetuou oferta, 3 - Nao aceito, 4- Leilao Inativo
		try
		{// MensagemAux 0=Agente 1=codProd 2=ValorOferta  3=Restricao
			String sAgente = Enviador.pegaParte(msg.mensagemAux(),0,',');
			String codProd = Enviador.pegaParte(msg.mensagemAux(),1,',');			
	
			if (msg.mensagemRetorno())//4
			{
//				msg.setMensagemRetorno(false);
				String	mensagemAux = msg.mensagemAux();
				Item it;
				//o item.
				it = findItemID(codProd);
									
				Oferta oferta = new Oferta(sAgente,Enviador.pegaParte(mensagemAux,2,','));
				oferta.setNumeroEstrelas(Enviador.pegaParteInteiro(mensagemAux,3,','));
							
				oferta.setCodProd(it.vetorCaracteristica.getValorCarac("codigo"));
				oferta.setNomeProd(it.nome());
								
				it.vetorOfertas.addElement(oferta);
				
				int numeroOfertas = it.vetorCaracteristica.getValorCaracInteiro("numeroOfertas");
				numeroOfertas++;
				it.vetorCaracteristica.setValorCarac("numeroOfertas",String.valueOf(numeroOfertas));
				
				
				//2 � o valor.
				int i=0;
//				Pagina pag = findPagina("AKRM");
//				if (pag == null)
//				{
//					this.appendHistoria("Inconsistencia na p�ginha AKRM ");
//					return;
//				}
//				System.out.println("Agente Recebeu informa��o de Oferta ao produto "+ codProd +" "+it.nome());
				this.appendHistoria("Agente Recebeu informa��o de Oferta ao produto "+ codProd +" "+it.nome());				

				repassaInformacaoVendedores(oferta);

				incrementaNumeroTotalOfertas();
				executaEstrategia();							
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no recebeReplyOfertaAKRM "+stringErro());
		}
	}

	
/******************** insereProdutosPaginas *****************************/	
	public synchronized void insereProdutosPaginas()
	{
		try
		{
			boolean todosInseridos=true;
			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				if(!pag.produtoInserido())
					todosInseridos = false;
			}
			if (todosInseridos)
			{
				int i = estagio();
				setVezes(0);
				setEstagio(++i);	
				executaEstrategia();
				return;
			}
			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				pag.insereProduto();
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no comeca a Trabalhar do agente LeiloeiroJuntador: "+nome());
		}
	}
	
	
/******************** analisaSituacaoItens *****************************/	
	public boolean analisaSituacaoItens()
	{
		try
		{
		
			System.out.println("AnalisaSituacaoItens");		
		
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no AnalisaSituacaoItens do Agente de Venda " + nome());
		}
		return false;
	}
	
	
/******************** fechaLeilao *****************************/	
	public synchronized void fechaLeilao(String nomeLeilao)
	{
		try
		{
			Pagina pag = findPagina(nomeLeilao);
			pag.fechaLeilao();
		}
		catch(Exception e)
		{
			System.err.println("Erro no Fecha Leilao do Agente LeiloeiroJuntador:"+nome()+ e);
		}
	}
	
/******************** recebeReplyFechaLeilaoAKRM *****************************/	
	public Mensagem recebeReplyFechaLeilaoAKRM(Mensagem msg) 	throws Exception 
	{
		Mensagem mensagem = new Mensagem("do Juntador recebeReplyFechaLeil","");
		try
		{
			int i=0;
///			System.out.println(msg.mensagemAux());			

			
			Item it = findItemID(Enviador.pegaParte(msg.mensagemAux(),0,','));
			msg.setReply(false);			
			if (it == null)
			{
				System.err.println("N�o achou o item em recebeReplyFechaLeilaoAKRM "+it.nome());
				return msg;
			}												
			this.appendHistoria("Reply de recebeReplyFechaLeilaoAKRM para "+it.nome()+" resultado:"+msg.mensagemRetorno());

			String nomeVencedor = Enviador.pegaParte(msg.mensagemAux(),1,',');
			String email = Enviador.pegaParte(msg.mensagemAux(),2,',');
			System.out.println(msg.mensagemAux()+"nomeVencedor:"+nomeVencedor+"  Email:"+email);

			it.vetorCaracteristica.setValorCarac("NomeVencedor",nomeVencedor);				
			it.vetorCaracteristica.setValorCarac("EmailVencedor",email);
			

			if (msg.mensagemRetorno())
			{
				mensagem.setMensagem("recebeReplyFechaLeilaoAKRM");//vendedor
				mensagem.setOrigem(this.nomeUsuarioPagina());
				mensagem.setTipo("Agente");
				mensagem.setReply(false);
				mensagem.setMensagemAux(msg.mensagemAux());//it.vetorCaracteristica.getValorCarac("codigo"));//it.nome()+","+it.vetorCaracteristica.getBufferCaracteristica());//
				mensagem.setMensagemRetorno(true);

//jatLite				
				//envia a mensagem para os dois vendedores
				mensagem.setDestino(it.vetorCaracteristica.getValorCarac("nomeVendedores"));
				Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,mensagem);		
/*				String nomeVend = it.vetorCaracteristica.getValorCarac("nomeVendedores");
				String s1;
				int i=0;
				msg.setOrigem(this.nome());
				while (!Enviador.pegaParte(nomeVend,i,',').equals("")  )
				{
					s1 = Enviador.pegaParte(nomeVend,i,',');
					i++;
					msg.setDestino(s1);
					agDelegate.enviaMensagem(msg);
				}*/
	//jatLite			
				

				it.setVendido(true);
//pode fazer alguma coisa
				i = estagio();
				setVezes(0);
				setEstagio(++i);
				executaEstrategia();
			}
		}
		catch(Exception e) 
		{
			System.err.println ("\nErro no recebeReplyRegistroAKRM do Agente Leiloeiro Juntador " + e);
		}     
		return mensagem;	
	}	

/******************** recebeVendedorFechaLeilao *****************************/	
//recebe mensamge do vendedor para fechar o leil�o, � necess�rio que todos fa�am isso.
	public Mensagem recebeVendedorFechaLeilao(Mensagem msg)
	{
		try
		{
			this.appendHistoria("Recebe permiss�o do agente "+msg.origem()+"\n para fechar o leil�o antecipadamente");
			msg.setReply(false);
			
			String codigo = Enviador.pegaParte(msg.mensagemAux(),0,',');;
			String nomeVendedor = msg.origem();			
			if (msg.mensagemRetorno())
			{
				Item it = findItemID(codigo);

				String vendedores = it.vetorCaracteristica.getValorCarac("nomeVendedores");				
				int i=0;
				System.out.println(nomeVendedor+"  "+vendedores);
				String vendedor = Enviador.pegaParte(vendedores,i,',');
				while (!vendedor.equals(""))
				{
					if (nomeVendedor.equals(vendedor))
					{
						int pode = it.vetorCaracteristica.getValorCaracInteiro("podeFechar");
						pode++;
//						System.out.println("pode "+String.valueOf(pode));
						it.vetorCaracteristica.setValorCarac("podeFechar",String.valueOf(pode));					
						return msg;
					}
					i++;
					vendedor = Enviador.pegaParte(vendedores,i,',');
				}			
				//se o podeFechar tiver o mesmo n�mero de vendedores associados ent�o o leiloeiro pode fechar o seu leil�o.
				executaEstrategia();
			}
		}
		catch(Exception e) 
		{
			System.err.println ("\nErro no recebeReplyRegistroAKRM do Agente Leiloeiro Juntador " + e);
		}     
		return msg;	
	}	
		

/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/*******************Parte do Agente de Venda que n�o d� pra pegar a Heran�a...
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/
/****************************************************************************/



	/************************** recebeMensagem *****************************/	
	public Mensagem recebeMensagem(Mensagem msg)
	{
		Mensagem mensagem = new Mensagem("","");
		try
		{
//			System.out.println (nome()+" Recebi a mensagem "+msg.mensagem());
			if (msg.mensagem().equalsIgnoreCase("recebeReplyBuscaProdutos"))
			{
				mensagem = recebeReplyBuscaProdutos(msg);
			}
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyRegistroAKRM"))
			{
				mensagem = recebeReplyRegistroAKRM(msg);
			}
			else if(msg.mensagem().equalsIgnoreCase("recebeReplyRecebeConviteLeilaoVenda"))
				mensagem = recebeReplyRecebeConviteLeilaoVenda(msg);
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyRegistroAKRM"))
			{
				mensagem = recebeReplyRegistroAKRM(msg);
			}
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyInsereProduto"))
			{
				mensagem = recebeReplyInsereProduto(msg);
			}
			else if(msg.mensagem().equalsIgnoreCase("recebeReplyCriaLeilaoAKRM"))
				mensagem = recebeReplyCriaLeilaoAKRM(msg);
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyOferta"))
			{
				recebeReplyOferta(msg);
				mensagem.setReply(false);					
			}			
			else if(msg.mensagem().equalsIgnoreCase("recebeReplyFechaLeilaoAKRM"))
				mensagem = recebeReplyFechaLeilaoAKRM(msg);
			else if(msg.mensagem().equalsIgnoreCase("recebeVendedorFechaLeilao"))
				mensagem = recebeVendedorFechaLeilao(msg);	
			else
				System.out.println("\nMensagem n�o reconhecida "+nome());	
				
			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no comeca a Trabalhar do "+nome());
		}
		return mensagem;
	}
}

	/**	
	busca();
	pegaPagina();
	ParsePalavrasChave();
	fazPergunta)seNecessario();
	atualizaFuncaoUtilizadade();
	insereReferenciasValores();//Uma lista de listas tipo www.xxx,valor 1, valor2....
								 que indica onde clicar e quais os valores a inserir. 
								 ex: login, senha.
	Nesse ponto ser� encontrado uma lista de refer�ncias ordenadas pela fun��o utilidade.

	NEGOCIA��O

	selecionaReferencias();
	iniciaNegociacao();
	verificaSePode();
	efetuaOferta();
	**/



/** 

	O valor da fun��o de Utilidade vai de 0 a 10, e n�o pode ser  valores comparativos 

	de acordo com as refer�ncias.  O valor est� relacionado apenascom a satisfa��o. 

	Ela pde ser a princ�pio RUIM, BOM, OTIMA.

	� considerado tamb�m o valor M�ximo dado pelo usu�rio, no momento da configura��o.

	Al�m dos dois deve se considerado o valor inicial, dado pelo leil�o(na refer�ncia).

**/




