class Restricao extends Object
{
}
