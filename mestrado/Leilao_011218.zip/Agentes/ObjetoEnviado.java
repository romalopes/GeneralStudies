import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;

abstract public class ObjetoEnviado extends Object implements Serializable
{
	String m_nome;

	public ObjetoEnviado () 
	{
	}
	public ObjetoEnviado (String Nome) 
	{ 
		m_nome  = Nome; 
	}
	
	/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
	
			out.writeObject(m_nome);
			out.flush();
		}	
		catch(IOException e)
		{
			System.out.println(e+ " Erro no write do ObjetoEnviado" );
		}			
	}
	
/****************************** readObject **********************************/		
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_nome =  (String)in.readObject();
		 }
		 catch(IOException e)
		 {
		 	System.out.println(e+" Erro no read do ObjetoEnviado" );
		 }
	 }

 
	public String nome()
	{
		return m_nome;
	}
	
	public void setNome(String Nome)
	{
		m_nome = Nome;
	}
	
}