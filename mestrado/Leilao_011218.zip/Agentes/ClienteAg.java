//progama para fazer a migracao de applet, 
//Bem simples, vou criar um objeto e depois passar para o servidor.

import java.io.*;				//Package de classes para manipulacao de E/S
import java.net.*;				//Package de classes para manipulacao de Sockets, IP, etc. 
import java.util.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

	public class ClienteAg {

	   public static void main (String[] args) throws IOException {

		/* ---declaracao de objetos constantes--- */
//		final int portaDefault = 8184,portaRecebimento = 8183;		//Definicao da porta default
		final String msgErroHost = "\nHost nao encontrado!\n";
		final String msgErroConexao = "\nConexao com Host nao pode ser estabelecida.\n";


		/* ---declaracao dos objetos utilizados--- */
		String nomeHost = "192.168.0.12";			//Nome do host para conexao
		
		Socket SimplesSocket = null;			//Declaracao de objeto da classe Socket 

		PrintWriter saida = null;		//Fluxo de saida
		BufferedReader entrada = null;		//Fluxo de entrada

		String MensagemAux,Mensagem, Nome;//Mensagem que vai ser passada
		if (args.length == 3)
		{
			Nome = args[0];
	 		Mensagem = args[1];
			MensagemAux = args[2];
		}
		else
		{
			Nome = "Administrador";
			Mensagem = "abre";
			MensagemAux = "AgILE.agl";
		}

		System.out.println("Nome "+Nome);
		System.out.println("Mensagem "+Mensagem);		
		System.out.println("MensagemAux "+MensagemAux);		
		try {
	   		SimplesSocket = new Socket(Enviador.nomeHostGerente, Enviador.PortaRecebimentoServidorGerente); 
					//Objeto sock criado atraves do construtor Socket
					//adequado a uma conexao TCP confiavel (stream).
					//Corresponde as instrucoes socket() e connect() 

		}
		catch(UnknownHostException e) 
		{		//Excecao: host nao e' encontrado
			System.err.println(msgErroHost);
			System.exit(1);
		}
		catch(java.io.IOException e) 
		{		//Excecao: conexao nao pode ser estabelecida
			System.err.println(msgErroConexao + e);
// 			System.exit(1); 
		}

   
		try 
		{
			OutputStream os = SimplesSocket.getOutputStream();
			ObjectOutputStream dos = new ObjectOutputStream (os);
			ObjectInputStream is = new ObjectInputStream(SimplesSocket.getInputStream());

			InetAddress Inet = InetAddress.getLocalHost();
			Mensagem Msg = new Mensagem(Nome,Inet.toString());

			Msg.setMensagem(Mensagem);
			Msg.setMensagemAux(MensagemAux);

			dos.writeObject (Msg);

			dos.flush();
			dos.close();
			os.close();
			is.close();
			SimplesSocket.close();
	    }
   		catch (UnknownHostException e) 
		{
    			System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Exception:  " + e);
		}

/*************************************/
//        Agora vai aguardar a resposta
		
		int backlog = 5;                 // tamanho da fila de requisicoes

       
        /* --- objetos sockets --- */


        ServerSocket socketServidor = null;
        Socket ClienteSocket = null;
		OutputStream os = null;
		ObjectOutputStream dos = null;
		ObjectInputStream is = null;

        /* --- associacao da porta utilizada pelo servidor --- */
       try {
         socketServidor = new ServerSocket(Enviador.PortaRecebimentoClienteGerente, backlog);
       
        System.out.println ("\nCliente de Leilao reativado. " + 
                            "Aguardando Servidor na porta " + Enviador.PortaRecebimentoClienteGerente+ "...\n");
		}
		catch(Exception e) {
		System.out.println ("\nPorta n�o pode ser liberada\n");
		}

        
		ClienteSocket = null;
        try {
	        System.out.println ("\nCliente Espera alguma coisa...\n");
            ClienteSocket = socketServidor.accept();  // listen() + accept()
         } 
         catch (IOException e) {
		 System.out.println ("\nCliente nao recebeu direito\n");

                 System.err.println("Erro de E/S " + e);
                 System.exit(1);
         }     
		 try 
		 {
					
		     System.out.println ("\nCliente Recebe alguma coisa...\n");
		     os = ClienteSocket.getOutputStream();
		     dos = new ObjectOutputStream (os);
		     is = new ObjectInputStream(ClienteSocket.getInputStream());

		     Mensagem Msg = (Mensagem) is.readObject(); 

   	         System.out.println("Recebi "+Msg.nome()+ " mensagem "+Msg.mensagem() + "IP "+Msg.ip());
		     dos.flush();	

		     os.flush();           
		     dos.close();
		     os.close();
	         is.close();
		     ClienteSocket.close();
	    } catch (Exception e) {System.err.println("Erro"); }

		/************************************/
	}
}