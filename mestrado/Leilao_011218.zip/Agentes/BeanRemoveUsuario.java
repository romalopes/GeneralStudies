//import java.io.*;
//import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;


public class BeanRemoveUsuario extends BeanGeral
{
	StringBuffer stringBuffer = new StringBuffer();
	Usuario m_usuario;
	Agente ag;

	public boolean removeusuario(String nomeUsuarioRemovido)
	{
		Mensagem msg;
		System.out.println("RemoveUsuario");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			msg = new Mensagem(getNomeUsuario(),Inet.getHostAddress());

			//AINDA n�o estou passando o password.
			
			int i=0;
			imprimeHeader();
			msg.setMensagem("RemoveUsuario");
			msg.setMensagemAux(nomeUsuarioRemovido);
			Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,msg);
			msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);			
			return msg.mensagemRetorno();
		
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanPegaUsuario Exception:  " + e);
		}
		return false;		
	
	}

	//imprime Agente, pode ser para remover ou simplesmente mostrar
		//setArquivo("VerificaAgente.jsp");
//		ou setArquivo("RemoveAgente.jsp");
	public String imprimeUsuario()
	{
	
		try
		{
			if (m_usuario == null)					
			{
				return "";
			}
						
			stringBuffer.append("<tr>\n");
			stringBuffer.append("<td width=\"21%\" height=\"31\">\n");			
			stringBuffer.append("<div align=\"left\"> <a href=\"/agile/jsp/RemoveUsuarioIndividual.jsp?nomeUsuarioRemovido="+m_usuario.nome()+"\">"+ m_usuario.nome()+"</a></div></td>\n");
			stringBuffer.append("<td width=\"18%\" height=\"31\">Ro</td>\n");
			stringBuffer.append("<td width=\"37%\" height=\"31\">telnet</td>\n");			
			stringBuffer.append("<td width=\"37%\" height=\"31\">telnet</td>\n");			
			stringBuffer.append("</tr>\n");						
			stringBuffer.append("\n");						
		}
		catch (Exception e) 
		{
			System.err.println("Erro o imprimeUsuario do BeanRemoveUsuario Exception:  " + e);
			return stringBuffer.toString();
		}


		return stringBuffer.toString();
	}

	public void imprimeHeader()
	{
		stringBuffer.append("<div id=\"Layer1\" style=\"position:absolute; width:200px; height:115px; z-index:1; left: 165px; top: 148px\">"); 
		stringBuffer.append("<table width=\"63%\" border=\"2\">");
		stringBuffer.append("<tr>"); 
		stringBuffer.append("<td width=\"21%\" height=\"43\">"); 
		stringBuffer.append("<div align=\"left\">Usuario</div>");
		stringBuffer.append("</td>");
		stringBuffer.append("<td width=\"18%\" height=\"43\">Tipo</td>");
		stringBuffer.append("<td width=\"37%\" height=\"43\">Produto</td>");
		stringBuffer.append("<td width=\"37%\" height=\"43\">Trabalhando</td>");
		stringBuffer.append("</tr>");
	}
	
	public String processa()
	{
		System.out.println("Procesando BeanPegaUsuario");
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(getNomeUsuario(),Inet.getHostAddress());
			//AINDA n�o estou passando o password.

			
			int i=0;
			imprimeHeader();
			Msg.setMensagem("PegaUsuarioAt");
			Msg.setMensagemAux(String.valueOf(i));
			Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
			m_usuario = (Usuario)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);			
			while(m_usuario != null)
			{	
				i++;
				imprimeUsuario();
				Msg.setMensagem("PegaUsuarioAt");
				Msg.setMensagemAux(String.valueOf(i));
				Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
				m_usuario = (Usuario)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);			
			}
			stringBuffer.append("</table>");
			stringBuffer.append("</div>");
			
			return stringBuffer.toString();

		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanPegaUsuario Exception:  " + e);
		}
		return "";		
	}
}
