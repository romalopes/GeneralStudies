/**classe Final Agente de compra**/

import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.VetorCaracteristica;
import ClassesGeral.Caracteristica;

/**
� uma estrat�gia.

Nessa estrat�gia e feita uma analise do tempo e valores ideiais para a oferta e 
compradados com os valores do momento
**/

public class EstrategiaCompraTempoValor extends Estrategia
{
	public Vector vetorVetorCaracUsu;

	public EstrategiaCompraTempoValor(AgenteCompra ag)
	{
		super(ag);
		try
		{	
			vetorVetorCaracUsu = new Vector();
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro na Cria��o do EstrategiaCompraTempoValor" );
		}
	}

	

	/****************************** writeObject **********************************/
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{
			out.writeObject(m_agente);	

			int i;		
			out.writeInt(vetorVetorCaracUsu.size());
			for(i=0;i<vetorVetorCaracUsu.size();i++)
			{
				out.writeObject(vetorVetorCaracUsu.elementAt(i));
			}

			out.flush();

		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write da EstrategiaCompraTempoValor" );
		}
	}



/****************************** readObject **********************************/

	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_agente = (AgenteCompra)in.readObject();	

			vetorVetorCaracUsu = new Vector();		
			
			int i,size = in.readInt();
			for(i=0;i<size;i++)
			{
				int j;		
				vetorVetorCaracUsu.addElement(in.readObject());
			}

			
		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read da EstrategiaCompraTempoValor" );
		 }
	}

	private VetorCaracteristica findVetorUsuario(String nomeConcorrente)
	{
		try
		{
			VetorCaracteristica vetorCarac;
			for(int i=0;i<vetorVetorCaracUsu.size();i++)
			{
				vetorCarac = (VetorCaracteristica)vetorVetorCaracUsu.elementAt(i);
				if(nomeConcorrente.equals(vetorCarac.getValorCarac("nomeParticipante")))
					return vetorCarac;
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no read da findVetorUsuario" );
		}
		return null;
	
	}
	
/****************** recebeReplyBuscaParticipanteIndividual *********************/	
//vai modificar as informa��es do perfil de um usu�rio espec�fico.   
	private void recebeReplyBuscaParticipanteIndividual(Mensagem msg)
	{
		String nomeConcorrente = Enviador.pegaParte(msg.mensagemAux(),0,',');
		VetorCaracteristica vetorCarac;
		vetorCarac = findVetorUsuario(nomeConcorrente);
		if (vetorCarac == null)
		{
			vetorCarac = new VetorCaracteristica();
			vetorVetorCaracUsu.addElement(vetorCarac);
		}
		vetorCarac.setCaracteristicas(msg.mensagemAux());
		ag().executaEstrategia();
	}


/**decide o melhor momento para realizar a oferta.  Se for anterior ao momento atual, ent�o deve-se aumentar o pre�o da oferta.  Retorna o minuto que deve ser realizada a oferta*/							
	private double achaMomento(Item it)
	{
		try
		{
			AgenteCompra ag = (AgenteCompra)ag();

			Pagina pag = ag.findPagina(it.pagina().nome());
			if (pag == null)
			{
				System.err.println("P�gina n�o existe no item:"+it.vetorCaracteristica.getValorCarac("codigo")+"  "+it.vetorCaracteristica.getValorCarac("nomeDono"));
				return 0;
			}
			double valorInicial = it.vetorCaracteristica.getValorCaracDouble("valorInicial");
			
			double valorAtual = it.vetorCaracteristica.getValorCaracDouble("valorAtual");

			double precoMax = ag().vetorCaracteristica.getValorCaracDouble("precoMax");
		
			//pegou o pre�o maximo mas vai verificar atrav�s da avalia��o qual o precoMaximo aceito para o item.
			precoMax = precoMax*it.somaAvaliacao();

			//agora verifica se deve continuar 
			int tempoLeilao = it.tempoLeilao();//esse valor nao est'a sendo considerado pois estamos procurando o valor ideal.
			
			double tempoTrabalho = 	ag().vetorCaracteristica.getValorCaracDouble("tempoTrabalho");
			
			double menorDiferenca = it.vetorCaracteristica.getValorCaracDouble("menordiferenca");
	
			int tempoInicio=0;

			double tempo = (double)(tempoLeilao*(valorAtual - valorInicial));
			System.out.println("tempo:"+tempo);
			tempo = tempo/(precoMax - valorInicial);//peguei o tempo.  se o tempo em relacao ao valor for maior que o atual entao deve esperar
		
			it.vetorCaracteristica.setValorCarac("tempoOferta",String.valueOf(tempo));
		
			System.out.println("tempoLeilao:"+tempoLeilao+" tempo:"+tempo+" valorAtual"+valorAtual+" tempoTrab"+tempoTrabalho+" tempoInicio:"+tempoInicio+" precoMax:"+precoMax);
			return tempo;
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no achaMomento da EstrategiaCompraTempoValor do Agente de compra :"+ag().nome());
		}
		return 0.0;	
	}
	
	
/**acha o valor para realizar a oferta, se for maior que o valor m�ximo, ent�o pode-se realizar uma oferta maior que a menor diferen�a, por�m menor que o pre�o m�ximo permitido*/
	private double achaValor(double minutoOferta,Item it)
	{
		try
		{
	
			Pagina pag = ag().findPagina(it.pagina().nome());
			if (pag == null)
			{
				System.err.println("P�gina n�o existe no item:"+it.vetorCaracteristica.getValorCarac("codigo")+"  "+it.vetorCaracteristica.getValorCarac("nomeDono"));
				return 0;
			}
			double valorInicial = it.vetorCaracteristica.getValorCaracDouble("valorInicial");
			
			double valorAtual = it.vetorCaracteristica.getValorCaracDouble("valorAtual");

			double precoMax = ag().vetorCaracteristica.getValorCaracDouble("precoMax");
	
			//pegou o pre�o maximo mas vai verificar atrav�s da avalia��o qual o precoMaximo aceito para o item.
			precoMax = precoMax*it.somaAvaliacao();
	
			//agora verifica se deve continuar 
			int tempoLeilao = it.tempoLeilao();
			
			double tempoTrabalho = ag().vetorCaracteristica.getValorCaracDouble("tempoTrabalho");
			
			double menorDiferenca = it.vetorCaracteristica.getValorCaracDouble("menordiferenca");
			
			double valorOferta = valorInicial*tempoTrabalho + tempoLeilao*(precoMax + valorInicial);			
			valorOferta = valorOferta/tempoTrabalho;
		
			it.vetorCaracteristica.setValorCarac("valorOferta",String.valueOf(valorOferta));

		
			return valorOferta;	
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no achaValor da EstrategiaCompraTempoValor do agente " + ag().nome());
		}

		return (float)0;	
	}	
	
/*********************** analisaSituacaoItemIndividual ***********************/	
	private double avaliacaoItem(Item it)
	{
		try
		{

			double valorOferta = (double)it.vetorCaracteristica.getValorCaracDouble("valorOferta");
				
			double tempoOferta = (double)it.vetorCaracteristica.getValorCaracDouble("tempoOferta");
		
		
			double valorAtual = it.vetorCaracteristica.getValorCaracDouble("valorAtual");
		
			//agora verifica se deve continuar 
			int tempoLeilao = it.tempoLeilao();

			if(tempoLeilao == 0.0)	
				tempoOferta = 0.0;
			else
				tempoOferta = tempoOferta/tempoLeilao; 
			
			if(valorAtual == 0.0)
				valorOferta = 0.0;
			else
				valorOferta = valorOferta/valorAtual;

			double v = tempoOferta+valorOferta;
			it.vetorCaracteristica.setValorCarac("avaliacaoOferta",String.valueOf(v));
			return v;
			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no avaliacaoItem da EstrategiaCompraTempoValor do agente " + ag().nome());
		}
		return 0;
	}
	
			
/*********************** analisaSituacaoItemIndividual ***********************/	
	public double analisaSituacaoItemIndividual(Item it)
	{
		AgenteCompra ag = (AgenteCompra)ag();
		try
		{
			String s;
			int size = it.vetorOfertas.size();
			if (size > 0)
			{
				Oferta oferta = (Oferta)it.vetorOfertas.elementAt(size - 1);	
				if(oferta != null)
					if(ag.nomeUsuarioPagina().equalsIgnoreCase(oferta.nomeUsuario()))
						return 0;//o vencedor atual � o pr�prio agente
			}				
			
			//decide o melhor momento para realizar a oferta.  Se for anterior ao momento atual, ent�o deve-se aumentar o pre�o da oferta.
			double minutoOferta = achaMomento(it);			
			
			//acha o valor para realizar a oferta, se for maior que o valor m�ximo, ent�o pode-se realizar uma oferta maior que a menor diferen�a, por�m menor que o pre�o m�ximo permitido						
			double valorOferta = achaValor(minutoOferta,it);
			
			System.out.println("minutoOferta:"+minutoOferta+" valorOferta:"+valorOferta);
			
			return avaliacaoItem(it);	
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no analisaSituacaoItemIndividual da EstrategiaCompraTempoValor do Agente de compra :"+ag().nome());
		}
		return 0;
	}


	/*********************** realizaOfertaItem ***********************/	
	public void realizaOfertaItem(Item it)
	{
		try
		{
			AgenteCompra ag = (AgenteCompra)ag();
		
			double avaliacaoMinimaOferta = it.vetorCaracteristica.getValorCaracDouble("avaliacaoMinimaOferta");
			double avaliacaoOferta = it.vetorCaracteristica.getValorCaracDouble("avaliacaoOferta");
			
			double valorOferta = it.vetorCaracteristica.getValorCaracDouble("valorOferta");
			double tempoOferta = it.vetorCaracteristica.getValorCaracDouble("tempoOferta");
			
			Pagina pag = ag.findPagina(it.pagina().nome());
			if (pag == null)
			{
				System.err.println("P�gina n�o existe no item:"+it.vetorCaracteristica.getValorCarac("codigo")+"  "+it.vetorCaracteristica.getValorCarac("nomeDono"));
				return;
			}
			
			if(avaliacaoOferta > avaliacaoMinimaOferta)
			{
				System.out.println("*****************\n*************\n Nao realiza oferta agora pois as avaliacoes nao sao boas"+avaliacaoOferta+"********************" );
				return;
			}
		
			double precoMax = ag().vetorCaracteristica.getValorCaracDouble("precoMax");
			precoMax = precoMax*it.somaAvaliacao();
	
			double valorAtual = it.vetorCaracteristica.getValorCaracDouble("valorAtual");
			
			String s = it.vetorCaracteristica.getValorCarac("menordiferenca");
			Integer valor = new Integer(Integer.parseInt(s, 10));
			int menorDiferenca = (int)valor.intValue();
			
			if(valorOferta>precoMax)
				valorOferta = valorAtual + menorDiferenca+(precoMax-valorOferta);//fiz alguma coisa so pra fazer com que a oferta seja maior.
			else
				valorOferta = valorOferta + menorDiferenca;
				
			
			ag.realizaOfertaItem(it,valorOferta);	
		}
		catch(Exception e)
		{
			System.out.println(e+" Erro no realizaOfertaItem da EstrategiaCompraTempoValor do agente " + ag().nome());

		}	
	}
			

/************************** analisaSituacaoItens *****************************/	
	public synchronized void analisaSituacaoItens()
	{//aqui que vem o racioc�nio
		try
		{			
		
			AgenteCompra ag = (AgenteCompra)ag();
			if(!ag.verificaRestricaoConfiguracaoOferta())
				return;
			
			Item it= null,itemMelhor=null;
			double avaliacaoAtual,avaliacaoMelhor = 0;
			
			if(	ag().listItens.size() > 0)
				itemMelhor = (Item)ag().listItens.elementAt(0);
			else 
				return;//sai porque n�o tem nenhum item.	

			for(int i=0;i<ag().listItens.size();i++)
			{
				it = (Item)ag().listItens.elementAt(i);
				if(it.vendido())
					continue;
				avaliacaoAtual = this.analisaSituacaoItemIndividual(it);
				if (avaliacaoAtual > avaliacaoMelhor)			
				{
					itemMelhor = it;
					avaliacaoMelhor = avaliacaoAtual;
				}
				System.out.println(avaliacaoAtual);
			}
			if(itemMelhor != null)
				realizaOfertaItem(itemMelhor);

			//retira as duas caracteristicas			
			for(int i=0;i<ag().listItens.size();i++)
			{
				it = (Item)ag().listItens.elementAt(i);
				it.vetorCaracteristica.removeCarac("valorOferta");
				it.vetorCaracteristica.removeCarac("tempoOferta");
			}
			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no analisaSituacaoItens da EstrategiaCompraTempoValor do agene "+ag().nome());
		}

	}

//agora analisa para ver sobre qual leil�o vai realizar a oferta.  Essa an�lise ser� feita baseada na avalia��o do produto na atualidade.
	

	/************************** recebeMensagem *****************************/	
	public Mensagem recebeMensagem(Mensagem msg)
	{
		Mensagem mensagem = new Mensagem("","");
		try
		{
		
			if (msg.mensagem().equalsIgnoreCase("recebeReplyBuscaParticipanteIndividual"))
			{
				recebeReplyBuscaParticipanteIndividual(msg);
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no comeca da recebeMensagem EstrategiaCompraTempoValor do "+ag().nome());
		}
		

		return mensagem;
	}
}