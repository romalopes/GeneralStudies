import java.io.*;
import java.util.*;
import java.net.*;
import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;

public class beanConfiguracaoAgente extends BeanGeral
{
	private String autonomia="";
	private String sites[] = new String[] { "AKRM", "LOKAU", "ARREMATE", "4" };
	private String precoMin="",precoMax="";


    public String getAutonomia() 
	{
		return autonomia;
    }

    public void setAutonomia(String a) 
	{
		autonomia = a;
    }
    public String[] getSites() 
	{
		return sites;
    }

    public void setSites(String [] b) 
	{
		sites = b;
    }
    public String getPrecoMin() 
	{
		return precoMin;
    }

    public void setPrecoMin(String p) 
	{
		precoMin = p;
    }
	public String getPrecoMax() 
	{
		return precoMax;
    }

    public void setprecoMax(String p) 
	{
		precoMax = p;
    }		

//(NomeAgente,autonomia,...,sites,...,precoMin,.,precoMax,.)
	public String concatenaStrings()
	{
		try
		{
			StringBuffer string = new StringBuffer();
			string.append(getNomeAgente()+",");
			string.append(autonomia+",");
			if(!sites[0].equals("1"))
				for(int i=0;i<sites.length;i++)
					string.append(sites[i]+",");
			string.append("&"+",");	
			string.append(precoMin+",");
			string.append(precoMax);
			return string.toString();
			
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanTrataMensagem Exception:  " + e);
		}
		return "";	
	}
	
	public String processa(String stringMensagem,String stringMensgemAux)
	{
		Mensagem Msg = new Mensagem(getNomeUsuario(),getIP());
		
		Msg.setMensagem(stringMensagem);
		
//"ConfiguracaoAgenteCompra"//
		Msg.setMensagemAux(stringMensgemAux);
		Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
		
		//nem precisava retornar o agente...
     	Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);
		return "processado com sucesso no beanConfiguracaoAgenteCompra";	
	}
}


