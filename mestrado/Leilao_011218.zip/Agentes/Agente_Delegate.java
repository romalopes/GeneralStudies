/**classe Abstrata Agente**/
	
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.InetAddress;

//jat
import Abstract.*;
import KQMLLayer.*;
import RouterLayer.AgentClient.*;
//jat


import ClassesGeral.ObjetoEnviado;
import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;
import ClassesGeral.VetorCaracteristica;
import ClassesGeral.Caracteristica;


/**
* Classe abstrate de Agentes.  Encapsula as principais funcionalidades dos agentes
*/

public class Agente_Delegate extends  RouterClientAction {
    public static String localhost = "192.168.0.12";

	public Agente m_agente;
    public Agente_Delegate(String id, String pw, String host, int port) throws Exception {
        super();    //RouterClientAction constructor

        //id,host,port,type,description
        String s = id+" , "+host+","+port+",MessageRouter,(agent-info :password "+pw+")";
		
		System.out.println("S:"+s);
		
		Address myAddress = new Address(s);
        s = "Router,192.168.0.25,4444,MessageRouter,(MessageRouter)";
        Address routerAddress = new Address(s);
        s = "RouterRegistrar,192.168.0.25,4445,MessageRouter,(MessageRouterRegistrar)";
        Address registrarAddress = new Address(s);

        setMyAddress(myAddress);    //agent address
        setRouterAddress(routerAddress);    //Router address
        setRegistrarAddress(registrarAddress);    //registrar address

        try {
          createServerThread(myAddress.getID(), Thread.NORM_PRIORITY);    //server listener
          register();    //register to Router
          connect();    //connect to Router
        } catch(ConnectionException e) {
            throw new Exception(e.toString());
        }
    }
	
	public void setAgente(Agente ag)
	{
		m_agente = ag;
	}
	
	public Agente agente()
	{
		return m_agente;
	}

	public boolean Act(Object o) {    //invoked automatically when a message is received
    
	    String message = (String) o;
		System.out.println(this.getName()+" Act");
        try {
            KQMLmail mail = new KQMLmail(message, 0);    //KQMLmail wrap the KQMLmessage
            _mailQueue.addElement(mail);    //message repository (to delete message after)
            KQMLmessage kqml = mail.getKQMLmessage();    //get KQMLmessage object

            String perf = kqml.getValue("performative");

            String content = kqml.getValue("content");
			
			Mensagem msg = new Mensagem("","");
			msg.deCodificaMensagem(content);
			
			m_agente.setMensagem(msg);
			Mensagem mensagemRecebida = m_agente.recebeMensagem(m_agente.mensagem());
			m_agente.setMensagem(null);
			
			/*
			
			if (msg.reply() == true)
			{
					m_gerente.processaMensagemAgente((Mensagem)obj);
	//						Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,obj);
			}
					
			*/		
//			System.out.println(perf+ "  "+content);
//          if(perf.equals("tell") && content != null) {
//            System.out.println(content);
//          acknowledge(kqml.getValue("sender"), content);
//                addToDeleteBuffer(0);    //send delete message to Router
//            }
//            else {
//                sendErrorMessage(kqml);
///               return false;
//            }
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public void processMessage(String command, Object obj)
	{
		System.out.println(this.getName()+" acknowledge");
         System.out.println("ProcessMessage");
	}    
	
	protected void enviaMensagem(Mensagem msg) throws Exception 
	{
	
		String sMensagem = msg.codificaMensagem();
		System.out.println(this.getName()+" acknowledge");
		
	    KQMLmessage sendkqml = new KQMLmessage();
	    sendkqml.addFieldValuePair("performative", "tell");
	    sendkqml.addFieldValuePair("sender", this.getName());
	    sendkqml.addFieldValuePair("receiver", msg.destino());
	    //...
//	    if(toContent.equals("(ping)")) sendkqml.addFieldValuePair("content", "(pong)");
//	    else sendkqml.addFieldValuePair("content", "(ping)");
//	        sendMessage(sendkqml);    //send message to Router: throws ConnectionException
		sendkqml.addFieldValuePair("content", sMensagem);
        sendMessage(sendkqml);    //send message to Router: throws ConnectionException
		

	}
	
	protected void acknowledge(String receiver, String toContent) throws Exception {
	
		System.out.println(this.getName()+" acknowledge");
		
        KQMLmessage sendkqml = new KQMLmessage();
        sendkqml.addFieldValuePair("performative", "tell");
        sendkqml.addFieldValuePair("sender", this.getName());
        sendkqml.addFieldValuePair("receiver", receiver);
        //...
        if(toContent.equals("(ping)")) sendkqml.addFieldValuePair("content", "(pong)");
        else sendkqml.addFieldValuePair("content", "(ping)");
	        sendMessage(sendkqml);    //send message to Router: throws ConnectionException
    }

    protected void sendErrorMessage(KQMLmessage kqml) throws Exception {
        String msg = "(error :sender " + this.getName() + " :receiver " +
                     kqml.getValue("sender") + " :content (" + kqml.getSendString() + "))";
        sendMessage(msg);    //send Router: throws ConnectionException and ParseException
        addToDeleteBuffer(0);    //send delete message to Router
    }

/*
    public static void main(String argv[]) throws Exception {
	agDelegate_Ping,agDelegate_Pong
		System.out.println("Comecando");
        PingPong pingA = new PingPong("ping", "xyz", localhost, 2222);    //create pingA
        PingPong pongA = new PingPong("pong", "hjk", localhost, 2223);    //create pongA
        pingA.start();    
		pongA.start();    //start agent action
        pingA.sendKQMLMessage("(tell :sender " + pingA.getName() + " :receiver " +
                              pongA.getName() + " :content (ping))");    //or sendMessage
        sleep(6000);
		System.out.println("Saindo");
        pingA.disconnect();    pongA.disconnect();    //disconnect from Router
        pingA.unregister();    pongA.unregister();    //unregister from Router
        pingA.endAction();    pongA.endAction();    //clean up and stop agent action
        System.exit(0);
    }*/
}
 




	 
/******************/
