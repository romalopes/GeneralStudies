/**classe P�ginas indica a p�gina que vamos entrar**/
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;


public class PaginaAKRM extends Pagina
{
	
	int m_iBusca;
	Mensagem msg = new Mensagem("","");
	String m_mensagemAux;
	


	public PaginaAKRM(Agente ag) throws Exception 
	{
		super(ag);
		m_nome = "AKRM";
		m_base = "http://www.AKRM.com.br/";
	};

	/************************** IniciaBusca *****************************/	
	/**Inicia a busca para o AKRM.com */	
	public void IniciaBusca() 
	{
		m_iBusca = 0;
	}
	
	/************************** finaliza a conex�o para a busca ************/
	public void finalizaConexao()
	{
	
	}
	
	/************************** BuscaDetalhes *****************************/
	/**faz a busca dos destalhes como descri��o e a foto para o AKRM.com */
	private void BuscaDetalhes(Item item)//	throws Exception 
	{
	}
	
	/************************** Busca *****************************/	
	/**faz a busca para o AKRM.com */	
	public Item Busca(String nomeProd)//o nome deve ser passado pois o agente pode ter mais de uma referencia.
	{
	
		if (m_iBusca == 0)//efetua a busca propriamente dita
		{
			agente().appendHistoria("Vai Buscar informa��es no site AKRM");
			String s = agente().nomeUsuarioPagina();//esse vai ser o login do agente no site
			Mensagem Msg = new Mensagem(s, Enviador.nomeHostGerente  );
			System.out.println("nomeUsuario"+s);
			Msg.setMensagem("BUSCAPRODUTOS");
			Msg.setOrigem(s);
			Msg.setTipo("Agente");
			Msg.setReply(true);
			String valor = agente().vetorCaracteristica.getValorCarac("detalhes");
			
			Msg.setMensagemAux(nomeProd);//+","+valor);
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);		
		}
		else//retorna os outros itens.
		{
		
		}
		return null;
	}
	/******************* BuscaProdutoIndividual *****************************/		
	public void buscaProdutoIndividual(String codProd)
	{
		try
		{
			agente().appendHistoria("Vai Buscar informa��es no site AKRM sobre o produto com id:"+codProd);
			String s = agente().nomeUsuarioPagina();//esse vai ser o login do agente no site
			Mensagem Msg = new Mensagem(s, Enviador.nomeHostGerente  );
			Msg.setMensagem("BuscaProdutoIndividual");
			Msg.setOrigem(s);
			Msg.setTipo("Agente");
			Msg.setReply(true);
			Msg.setMensagemAux(codProd);
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);		
		}
		catch(Exception e)
		{
			System.err.println("Erro no buscaProdutoIndividual da PaginaAKRM :"+codProd);
		}
	}
	
	
	public void fechaLeilao()
	{
		try
		{
			Mensagem msg = new Mensagem(agente().nomeUsuarioPagina(), Enviador.nomeHostGerente  );
			msg.setMensagem("AgenteFechaLeilao");
			msg.setOrigem(agente().nomeUsuarioPagina());
			msg.setTipo("Agente");
			msg.setReply(true);
			msg.setMensagemAux(vetorCaracteristica.getValorCarac("codigo"));
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,msg);		
		}
		catch(Exception e)
		{
			System.err.println("Erro no Fecha Leilao da PaginaAKRM :"+agente().nomeProduto());
		}
	}			
	public void criaLeilao()
	{
		try
		{
			agente().appendHistoria("Criando produto:"+agente().nomeProduto()+" no site AKRM");
			String s = agente().nomeUsuarioPagina();//esse vai ser o login do agente no site
			Mensagem Msg = new Mensagem(s, Enviador.nomeHostGerente  );
			Msg.setMensagem("TRATAL");
			Msg.setOrigem(s);
			Msg.setTipo("Agente");
			Msg.setReply(true);
			String valor;
			StringBuffer buffer = new StringBuffer();
			//nomeProd,detalhes,tipoLeilao,prazo,valorInicial,menorDiferenca,bValorReserva,ValorReserva

			buffer.append("nomeProduto&"+agente().nomeProduto()+"&");
			System.out.println(vetorCaracteristica.getValorCarac("codigo"));
			buffer.append("codigo&"+vetorCaracteristica.getValorCarac("codigo")+"&");			
			valor = this.vetorCaracteristica.getValorCarac("tipoLeilao");
			buffer.append("tipoLeilao&"+valor+"&");
			buffer.append("detalhes&"+agente().vetorCaracteristica.getValorCarac("detalhes")+"&");
			valor = agente().vetorCaracteristica.getValorCarac("prazo");
			buffer.append("prazo&"+valor+"&");
			valor = agente().vetorCaracteristica.getValorCarac("valorInicial");
			buffer.append("valorInicial&"+valor+"&");			
			valor = agente().vetorCaracteristica.getValorCarac("menordiferenca");
			buffer.append("menordiferenca&"+valor+"&");			
			valor = agente().vetorCaracteristica.getValorCarac("bValorReserva");
			buffer.append("bValorReserva&"+valor+"&");			
			valor = agente().vetorCaracteristica.getValorCarac("ValorReserva");
			buffer.append("ValorReserva&"+valor+"&");			
						
			System.out.println(buffer.toString());
			Msg.setMensagemAux(buffer.toString());
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);		
		}
		catch(Exception e)
		{
			System.err.println("Erro no CriaLeilao Pagina AKRM :"+agente().nomeProduto());
		}
	}
	
	
	
	public void insereProduto()
	{
		try
		{
			agente().appendHistoria("Inserindo produto:"+agente().nomeProduto()+" no site AKRM");
			System.out.println("nomePagina: "+agente().nomeUsuarioPagina());
			String s = agente().nomeUsuarioPagina();//esse vai ser o login do agente no site
			Mensagem Msg = new Mensagem(s, Enviador.nomeHostGerente  );
			Msg.setMensagem("RGPROD");
			Msg.setOrigem(s);
			Msg.setTipo("Agente");
			Msg.setReply(true);
			String valor = agente().vetorCaracteristica.getValorCarac("detalhes");
			Msg.setMensagemAux(agente().nomeProduto()+","+valor);
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);		
		}
		catch(Exception e)
		{
			System.err.println("Erro no Insere Produto da Pagina AKRM");
		}
	}
	
	/************************** IniciaOferta *****************************/	
	/*********************************************************************/	
	public void IniciaOferta() 
	{
	}
	
	/************************** realizaOferta ****************************/
	/*********************************************************************/
	public boolean realizaOfertaItem(Item it,double valorOferta)
	{
		try
		{
			String s = new String();
			s = "Realiza Oferta para cod:"+it.vetorCaracteristica.getValorCarac("codigo")+" nome:"+it.nome()+"Pagina:"+it.vetorCaracteristica.getValorCarac("nomePagina");
			m_agente.appendHistoria(s);
			s = agente().nomeUsuarioPagina();//esse vai ser o login do agente no site
			Mensagem Msg = new Mensagem(s, Enviador.nomeHostGerente  );
			Msg.setMensagem("OFERTA");
			Msg.setTipo("Agente");
			
			Msg.setReply(true);
			System.out.println("Oferta para nome "+it.nome());
			s = it.vetorCaracteristica.getValorCarac("codigo")+","+String.valueOf(valorOferta);
			Msg.setMensagemAux(s);
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);
						
			//verifica se a oferta foi aceita, se sim faz mais alguma coisa...
		}
		catch(Exception e)
		{
			System.err.println("Erro no RealizaOferta do PaginaAKRM para "+it.vetorCaracteristica.getValorCarac("codigo") + " "+ e );
			return false;
		}
		return true;
	}
	
	
	////////////////////////////recebeRegistraLeilaoAgILE()////////////////
//Recebi o aviso de que se passou um minuto
	public void registraLeilao()
	{
		try
		{
			if(agente().vezes()>1)
				agente().appendHistoria("N�o conseguiu se registrar no site AKRM com o nome:"+agente().nomeUsuarioPagina());
		
			agente().setNomeUsuarioPagina(agente().nomeUsuario()+"_"+agente().nome()+"_"+agente().vezes());// o numero de vezes serve para o caso de j� existir um agente com o mesmo nome
		
			agente().appendHistoria("Tenta se registra em "+nome()+" com o Nome:"+agente().nomeUsuarioPagina());
			String s = agente().nomeUsuarioPagina();//esse vai ser o login do agente no site
			Mensagem Msg = new Mensagem(s, Enviador.nomeHostGerente  );
			Msg.setMensagem("RGPART");
			Msg.setTipo("Agente");
			Msg.setReply(true);
			Msg.setMensagemAux(agente().nomeUsuario()+","+agente().email());
			Enviador.EnviaMensagem(Enviador.nomeHostProcessador,Enviador.PortaRecebimentoServidorProcessador,Msg);
		}	
		catch(Exception e) 
		{

			System.err.println ("\nErro no registraLeilaoAgILE() do Agente " + e + "  "+nome());

			return ;

		}     
	}
	
	
	public int prazo(Item it)
	{
		try
		{
			return it.vetorCaracteristica.getValorCaracInteiro("prazo");
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em prazo de "+agente().stringErro());
		}
		return 0;
	}
	
	
	public int tempoRestante(Item it)
	{
		try
		{
		
			String dataInicio = it.vetorCaracteristica.getValorCarac("dataInicio");
			
			if(dataInicio.equals(""))
				return 0;
			int prazo = it.vetorCaracteristica.getValorCaracInteiro("prazo");

			System.out.println(dataInicio+"   "+prazo);		

			int minutoInicio = (int)Enviador.pegaParteInteiro(dataInicio,0,'/');
			int horaInicio = (int)Enviador.pegaParteInteiro(dataInicio,1,'/');	
			int diaInicio = (int)Enviador.pegaParteInteiro(dataInicio,2,'/');		
			int AnoInicio = (int)Enviador.pegaParteInteiro(dataInicio,3,'/');			
		
			System.out.println(minutoInicio+" "+horaInicio+" "+diaInicio+" "+AnoInicio);
			int minutos=0;
			Calendar calendar = new GregorianCalendar();	
				
			minutos = (calendar.get(Calendar.YEAR) - AnoInicio)*365*24*60;
			minutos += (calendar.get(Calendar.DAY_OF_YEAR) - diaInicio)*24*60;
			minutos += (calendar.get(Calendar.HOUR_OF_DAY) - horaInicio)*60;		
			minutos += (calendar.get(Calendar.MINUTE) - minutoInicio);		
			
			prazo = prazo-minutos;
			System.out.println(prazo+" "+minutos);
			if(prazo>0)
				return prazo;

		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em tempoRestante(String,int) de "+agente().stringErro());
		}
		return 0;
	}
	public int tempoRodando(Item it)
	{
		try
		{
			int minutos=0;
			Calendar calendar = new GregorianCalendar();	
		
			String dataInicio = it.vetorCaracteristica.getValorCarac("dataInicio");

			if(dataInicio.equals(""))
				return 0;
			int minutoInicio = (int)Enviador.pegaParteInteiro(dataInicio,0,'/');
			int horaInicio = (int)Enviador.pegaParteInteiro(dataInicio,1,'/');	
			int diaInicio = (int)Enviador.pegaParteInteiro(dataInicio,2,'/');		
			int AnoInicio = (int)Enviador.pegaParteInteiro(dataInicio,3,'/');			
		
//			int minutoFim = (int)Enviador.pegaParteInteiro(dataInicio,0,'/');
//			int horaFim = (int)Enviador.pegaParteInteiro(dataInicio,1,'/');	
//			int diaFim = (int)Enviador.pegaParteInteiro(dataInicio,2,'/');		
//			int AnoFim = (int)Enviador.pegaParteInteiro(dataInicio,3,'/');			

			minutos = (calendar.get(Calendar.YEAR) - AnoInicio)*365*24*60;
			minutos += (calendar.get(Calendar.DAY_OF_YEAR) - diaInicio)*24*60;
			minutos += (calendar.get(Calendar.HOUR_OF_DAY) - horaInicio)*60;		
			minutos += (calendar.get(Calendar.MINUTE) - minutoInicio);		

			System.out.println("Tempo rodando: "+minutos);
			if(minutos>0)
				return minutos;

		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em tempoRodando de "+agente().stringErro());
		}
		return 0;
	}
	
	
}



