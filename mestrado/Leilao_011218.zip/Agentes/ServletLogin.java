import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;


//Servlet para login
public class ServletLogin extends HttpServlet 
{
	String m_usrlogin;
	String m_nome;
    public void init(ServletConfig servletConfig) throws ServletException
    {
	    super.init(servletConfig);
        System.out.println("Cria Usuario ****************************************************************************************************************");
    }

//	public void doGet(HttpServletRequest request,
//                   HttpServletResponse response)
//    throws ServletException, IOException {  }

	
	public void printAceito(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException 

	{
		// Set the attribute and Forward to usuariologado.jsp
		String caminho = "/jsp/usuariologado.jsp";
		getServletConfig().getServletContext().getRequestDispatcher(caminho).forward(request, response);
	}

	
	public void printFalha(HttpServletResponse response)
	throws ServletException, IOException 

	{
		response.setContentType("text/html");
    	PrintWriter out = response.getWriter();
    	String title = "Login Falha";
		out.println("<html>");
		out.println("<head><title>Login Falha</title></head>");
		out.println("<BODY BGCOLOR=\"#FDF5E6\">\n" +
                "<h1 ALIGN=CENTER>" + title + "</h1>\n" +
                "<TABLE BORDER=1 ALIGN=CENTER>\n" +
                "<TH>Nome rejeitado" );
		out.println("</body></html>");
	}

	public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
    throws ServletException, IOException 
	{    
        m_usrlogin = request.getParameter("nomeUsuario");
		String usrsenha = request.getParameter("senha_usuario");
	    
		String ip = request.getRemoteAddr();    	
		Mensagem Msg = new Mensagem(m_usrlogin,ip);
		Msg.setMensagem("login");
		Msg.setMensagemAux(usrsenha);
		
		Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
		Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);

/**********************************************/

		if(Msg.mensagemRetorno())
        {
			System.out.println("\nRetornou do ServletLogin **********************");					
          	printAceito(request,response);
        }
		else
        {
          	printFalha( response);
        }
	}
}