/**classe P�ginas indica a p�gina que vamos entrar**/
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;


import ClassesGeral.Enviador;
import ClassesGeral.Mensagem;

public class PaginaEVenda extends Pagina
{

	public PaginaEVenda(Agente ag) throws Exception 
	{
		super(ag);
		m_nome = "EVENDA";
		m_base = "http://www.evenda.com/";
		m_biniciaBusca = false;
		setLogin("romalopes2");
		setSenha("novembro");		
	};
	public void buscaProdutoIndividual(String CodProd)
	{
	}
	public void registraLeilao()
	{
		int i;
		i = agente().estagio()+1;
		agente().setEstagio(i);
	};
	
	
	/******************** PegaNumeroCategoria *****************************/			
	private String PegaNumeroCategoria(String categoria)
	{
		String string="1";
	
//		System.out.println("categoria:"+categoria);
		
		if(categoria.equalsIgnoreCase("antiguidades"))
			string="1";
		else if(categoria.equalsIgnoreCase("automovel"))
			string="2";
		else if(categoria.equalsIgnoreCase("brinquedo"))
			string="3";
		else if(categoria.equalsIgnoreCase("colecionaveis"))
			string="4";
		else if(categoria.equalsIgnoreCase("discos"))
			string="5";
		else if(categoria.equalsIgnoreCase("eletroodomesticos"))
			string="6";
		else if(categoria.equalsIgnoreCase("audio"))
			string="7";
		else if(categoria.equalsIgnoreCase("video"))
			string="8";
		else if(categoria.equalsIgnoreCase("foto"))
			string="9";
		else if(categoria.equalsIgnoreCase("imovel"))
			string="10";
		else if(categoria.equalsIgnoreCase("informatica"))
			string="11";
		else if(categoria.equalsIgnoreCase("musical"))
			string="12";
		else if(categoria.equalsIgnoreCase("joalheria"))
			string="13";
		else if(categoria.equalsIgnoreCase("livro"))
			string="14";
		else if(categoria.equalsIgnoreCase("moeda"))
			string="15";
		else if(categoria.equalsIgnoreCase("telefonia"))
			string="16";
		else if(categoria.equalsIgnoreCase("outros"))
			string="17";
		return string;
	}
	
	
	/******************** insereProduto *****************************/		
	public void insereProduto()
	{
		try
		{
		
			int index,fim;

//VerificaNovoItem.asp			
			
			String valor = agente().vetorCaracteristica.getValorCarac("detalhes");
			//abre conex�o ... e j� realiza a oferta.
			//abre conex�o ...
			String stringTotal="";
			stringTotal = "Username="+this.login()+"&";
			stringTotal += "Password="+this.senha()+"&";
			stringTotal += "Titulo="+agente().nomeProduto()+"&";
			stringTotal += "Categoria="+this.PegaNumeroCategoria(agente().vetorCaracteristica.getValorCarac("categoria"))+"&";
			stringTotal += "Descricao="+agente().vetorCaracteristica.getValorCarac("detalhes")+"&";			
			stringTotal += "Figura=&";			
			stringTotal += "Localizacao=Niteroi&";

//     <input type="checkbox"name="formaDeposito" value="Deposito Bancario" checked> " name="formaCheque" value="Cheque">  name="formaCartao" value="Cart�o de cr�dito">   name="formaOrderm" value="Ordem de pagamento">   name="formaVeja" value="Veja descricao do item">  name="formaOutros" value="Outros">
			stringTotal += "formaDeposito=Deposito Bancario&";			
			stringTotal += "formaCheque=&";			
			stringTotal += "formaCartao=&";
			stringTotal += "formaOrderm=&";
			stringTotal += "formaVeja=&";
			stringTotal += "formaOutros=&";			
//			 <input type="checkbox" name="quemVendedor" value="Vendedor">  name="quemCombinar" value="A combinar">   name="quemComprador" name="quemDescricao"  value="Veja descri��o do item" 
			stringTotal += "quemVendedor=Vendedor&";						 
			stringTotal += "quemCombinar=&";						 
			stringTotal += "quemComprador=&";						 
			stringTotal += "quemDescricao=&";						 			
			
			stringTotal += "Quantidade=1&";						 
			stringTotal += "Minimo="+Enviador.transformaNumeroVirgulaNumeroPonto(agente().vetorCaracteristica.getValorCarac("valorInicial"))+"&";						 			
			stringTotal += "duracao="+agente().vetorCaracteristica.getValorCarac("Prazo")+"&";//1&";Prazo						 			
			stringTotal += "Negrito=&";						 			
//			stringTotal += "B2=&";						 												
			stringTotal += "submit=aqui";						 						

			DataOutputStream    printout;	  
			
			System.out.println(stringTotal);
			URLConnection siteConnection;
			BufferedReader in;
			// URL of CGI-Bin script.
			String s = base()+"AddNewItem.asp";
			System.out.println(s);
			URL url = new URL (s);
			// URL connection channel.
			siteConnection = url.openConnection();
			// Let the run-time system (RTS) know that we want input.
			siteConnection.setDoInput (true);
			// Let the RTS know that we want to do output.
			siteConnection.setDoOutput (true);
			// No caching, we want the real thing.
			siteConnection.setUseCaches (false);
			// Specify the content type.
			siteConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
//			siteConnection.setRequestProperty("Content-Type", "multipart/form-data");//"application/x-www-form-urlencoded");			
			// Send POST output.
			printout = new DataOutputStream (siteConnection.getOutputStream ());
			printout.writeBytes (stringTotal);
			printout.flush ();
			printout.close ();
			
//			siteConnection.getInputStream();
			m_in = new BufferedReader(
						new InputStreamReader(siteConnection.getInputStream()));
		
			//verifica se a oferta foi aceita, se sim faz mais alguma coisa...
			//while para pegar cada linha
			while ( (m_inputLine = m_in.readLine()) != null )
			{
				System.out.println(m_inputLine);
				
				if (m_inputLine.indexOf("Seu item foi registrado com sucesso",0)>0)
				{
					while ( (m_inputLine = m_in.readLine()) != null )
					{
		//				<td width=25% >N�mero do seu item: </td>					
						System.out.println(m_inputLine);
						if (m_inputLine.indexOf("do seu item:",0)>0)
						{
			//				<td width=75% ><strong> 725</strong></td>
							m_inputLine = m_in.readLine();
							index = m_inputLine.indexOf("ong>",0);//<strong>
							if (index>0)
							{
								index = index+4;
								fim = m_inputLine.indexOf("</stron",index);//</strong>
								String codigo	= m_inputLine.substring(index,fim);						

								Mensagem msg = new Mensagem("","");
								msg.setMensagemRetorno(true);								
								msg.setReply(false);								
								msg.setMensagemAux(codigo+",EVENDA");
								((AgenteVenda)agente()).recebeReplyInsereProduto(msg);
								setLeilaoCriado(true);
							}
													
						}
					}
				}
			}
			finalizaConexao();		
			return;

		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no insereProduto do PaginaLokau para "+agente().nomeProduto() + " " + agente().stringErro() );
		}
		return ;
	
	}			
/*

			// URL of CGI-Bin script.
			m_url = new URL (base()+"VerificaNovoItem.asp");
			// URL connection channel.
			m_siteConnection = m_url.openConnection();
			// Let the run-time system (RTS) know that we want input.
			m_siteConnection.setDoInput (true);
			// Let the RTS know that we want to do output.
			m_siteConnection.setDoOutput (true);
			// No caching, we want the real thing.
			m_siteConnection.setUseCaches (false);
			
			// Specify the content type.
//			<form action="VerificaNovoItem.asp" method="post" enctype="multipart/form-data">
			m_siteConnection.setRequestProperty("Content-Type", "multipart/form-data");//"application/x-www-form-urlencoded");
			
			// Send POST output.
			printout = new DataOutputStream (m_siteConnection.getOutputStream ());
			printout.writeBytes (stringTotal);
			printout.flush ();
			printout.close ();
			m_in = new BufferedReader(
						new InputStreamReader(m_siteConnection.getInputStream()));
		
			
			while ( (m_inputLine = m_in.readLine()) != null )
			{
//				eVenda problemas para registrar novo item
//Usu�rio n�o cadastrado 
//Nenhum dos campos obrigat�rios 

//Por favor, verifique se todas //<title> Verifica
//O balan�o de sua conta antes 
				System.out.println(m_inputLine);
				AgenteCompra ag = (AgenteCompra) agente();				
				if (m_inputLine.indexOf("Por favor, verifique se todas",0)>0)
				{
					stringTotal="";
					stringTotal = "Username="+this.login()+"&";
					stringTotal += "Password="+this.senha()+"&";
					stringTotal += "Titulo="+agente().nomeProduto()+"&";
					stringTotal += "Categoria="+this.PegaNumeroCategoria(vetorCaracteristica.getValorCarac("categoria"))+"&";
					stringTotal += "Descricao="+vetorCaracteristica.getValorCarac("detalhes")+"&";			
					stringTotal += "Figura=&";			
					stringTotal += "Localizacao=Niteroi&";
		
		//     <input type="checkbox"name="formaDeposito" value="Deposito Bancario" checked> " name="formaCheque" value="Cheque">  name="formaCartao" value="Cart�o de cr�dito">   name="formaOrderm" value="Ordem de pagamento">   name="formaVeja" value="Veja descricao do item">  name="formaOutros" value="Outros">
					stringTotal += "formaDeposito=Deposito Bancario&";			
					stringTotal += "formaCheque=&";			
					stringTotal += "formaCartao=&";
					stringTotal += "formaOrderm=&";
					stringTotal += "formaVeja=&";
					stringTotal += "formaOutros=&";			
	//			 <input type="checkbox" name="quemVendedor" value="Vendedor">  name="quemCombinar" value="A combinar">   name="quemComprador" name="quemDescricao"  value="Veja descri��o do item" 
					stringTotal += "quemVendedor=Vendedor&";						 
					stringTotal += "quemCombinar=&";						 
					stringTotal += "quemComprador=&";						 
					stringTotal += "quemDescricao=&";						 			
					
					stringTotal += "Quantidade=1&";						 
					stringTotal += "Minimo="+Enviador.transformaNumeroVirgulaNumeroPonto(vetorCaracteristica.getValorCarac("valorInicial"))+"&";						 			
					stringTotal += "duracao=1&";						 			
					stringTotal += "Negrito=&";						 			
					stringTotal += "submit=aqui";
               <form method="post" action="http://www.evenda.com/AddNewItem.asp">
               <input type="hidden" name=Username value="romalopes">
               <input type="hidden" name=Password value="novembro">
               <input type="hidden" name=Titulo value="mequetrefe">
               <input type="hidden" name=Figura value="">
               <input type="hidden" name=Localizacao value="Niteroi">
               <input type="hidden" name=formaDeposito value="Deposito Bancario">
               <input type="hidden" name=formaCheque value="">
               <input type="hidden" name=formaCartao value="">
               <input type="hidden" name=formaOrderm value="">
               <input type="hidden" name=formaVeja value="">
               <input type="hidden" name=formaOutros value="">
               <input type="hidden" name=quemVendedor value="">
               <input type="hidden" name=quemCombinar value="">
               <input type="hidden" name=quemComprador value="Comprador">
               <input type="hidden" name=quemDescricao value="">
               <input type="hidden" name=Minimo value="5">
               <input type="hidden" name=duracao value="3">
               <input type="hidden" name=Negrito value="">
               <input type="hidden" name=Quantidade value="1">
               <input type="hidden" name=Categoria value="1">
               <input type="hidden" name=Descricao value="Mequetrefe bom pacas">

               <table border="0" cellpadding="0" cellspacing="0" width="600" align="center">
               <tr> 
               <td><a href="http://www.evenda.com/help/index.htm">Click aqui para cancelar.</a></td>
               </tr>
               <tr> 
               <td>&nbsp;</td>
               </tr>
               <tr> 
               <td>Click 
               <input type=submit value=aqui name=submit>
               para iniciar o leil�o</td>
               </tr>

			}
			*/
	/******************** criaLeilao *****************************/			
	public void criaLeilao()
	{
	
	};
	
	/******************** fechaLeilao *****************************/				
	public void fechaLeilao()
	{
	};
	
	
	/************************** IniciaBusca *****************************/	
	/**Inicia a busca para o Lokau.com */	
	public void IniciaBusca() 
	{
		try
		{
			setIniciaBusca(true);
			//abre conex�o ...
/*			<form name=form1 method=post action=BuscaItens.asp>
			<div align=center><center>
			<table border=1 width=600 cellspacing=0 cellpadding=4>
			<tr>
			<td width=25% bgcolor=#E7D5B4>Pesquisar pelo t�tulo</td>
			<td width=75%><p><input type=text name=Query size=40 maxlength=100>
			<input type=submit value=Pesquisar>
			
			
			</tr>
			<tr>
			<td width=25% bgcolor=#E7D5B4>Faixa de pre�o </td>
			<td>Entre R$ <input type=text name=PrecoMin value size=12 maxlength=12> &nbsp; e R$ <input type=text name=PrecoMax value size=12 maxlength=12> &nbsp; </td>
			</tr>
			<tr>
			<td width=25% bgcolor=#E7D5B4>Ordenado por:</td>
			<td width=75%><select name=Ordenar size=1>
			<option selected value=Fim>Data final</option>
			<option value=Inicio>Data inicial</option>
			<option value=Preco>Pre�o corrente</option>
			</select>
			<input type=radio name=Ordem value=[c] checked>crescente <input type=radio name=Ordem value=[d]>decrescente</td>
			</tr>
			<tr>
			<td width=25% bgcolor=#E7D5B4>&nbsp; </td>
			<td width=75%><input type=checkbox name=srchdesc value=y>Pesquisar t�tulo e descri��o</td>
			</tr>
			</table>
			</center></div>
			
*/

			String stringTotal="";
			stringTotal = "Query="+URLEncoder.encode(m_agente.nomeProduto())+"&";
			stringTotal += "submit=Pesquisar&";
			stringTotal += "PrecoMin=&";
			stringTotal += "Ordenar=Fim&";
			stringTotal += "Ordem=[c]&";
			stringTotal += "srchdesc=y";
//			stringTotal = URLEncoder.encode(stringTotal);			
			
			System.out.println(stringTotal);

			DataOutputStream    printout;
	
			// URL of CGI-Bin script.
			m_url = new URL (base()+"BuscaItens.asp");
			// URL connection channel.
			m_siteConnection = m_url.openConnection();
			// Let the run-time system (RTS) know that we want input.
			m_siteConnection.setDoInput (true);
			// Let the RTS know that we want to do output.
			m_siteConnection.setDoOutput (true);
			// No caching, we want the real thing.
			m_siteConnection.setUseCaches (false);
			// Specify the content type.
			m_siteConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			// Send POST output.
			printout = new DataOutputStream (m_siteConnection.getOutputStream ());
			printout.writeBytes (stringTotal);
			printout.flush ();
			printout.close ();
			m_in = new BufferedReader(
						new InputStreamReader(m_siteConnection.getInputStream()));
		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no IniciaBusca"+agente().stringErro() );
			setIniciaBusca(false);
		}			
	}
	
	/************************** finaliza a conex�o para a busca ************/
	public void finalizaConexao()
	{
		try
		{
			m_in.close();
			m_in = null;
		}
		catch(Exception e)
		{}
	
	}
	public Oferta verificaOferta(Item it)
	{
		Oferta oferta = null;
		try
		{
			double valorAtual = it.vetorCaracteristica.getValorCaracDouble("valorAtual");
			
			
			BuscaDetalhes(it);//	throws Exception 
			
			
			double valorAtual2 = it.vetorCaracteristica.getValorCaracDouble("valorAtual");
			if (valorAtual != valorAtual2)
			{
				oferta = new Oferta("Nome",String.valueOf(valorAtual2));
				
				oferta.setNumeroEstrelas(0);
							
				oferta.setCodProd(it.vetorCaracteristica.getValorCarac("codigo"));
				oferta.setNomeProd(it.vetorCaracteristica.getValorCarac("nomeProduto"));				
								
			
			
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no verificaOferta do PaginaLokau "+agente().stringErro());
		}
		return oferta;
		
	}
	

	
/********************** transformaDataEVendaParaAgILE *****************************/	
	static private String transformaDataEVendaParaAgILE(String string)
	{
		int minuto=0, hora=0, dia=0, mes=0, ano=0 ,posIndex=0, posIndexAtual=0;
		String stringAtual;
	
		try
		{//31/10/2001 �s 06:28:09		
		    posIndex = string.indexOf('/',posIndexAtual);
			stringAtual = string.substring(posIndexAtual,posIndex);
			Integer valor = new Integer(Integer.parseInt(stringAtual, 10));
			dia = (int)valor.intValue();
			
			posIndexAtual = posIndex+1;
			posIndex = string.indexOf('/',posIndexAtual);
			stringAtual = string.substring(posIndexAtual,posIndex);
			valor = new Integer(Integer.parseInt(stringAtual, 10));
			mes = (int)valor.intValue();


			posIndexAtual = posIndex+1;
			posIndex = string.indexOf(' ',posIndexAtual);
			stringAtual = string.substring(posIndexAtual,posIndex);
			valor = new Integer(Integer.parseInt(stringAtual, 10));
			ano = (int)valor.intValue();


			posIndex = string.indexOf(':',posIndexAtual);
			posIndexAtual = posIndex-2;
			stringAtual = string.substring(posIndexAtual,posIndex);
			valor = new Integer(Integer.parseInt(stringAtual, 10));
			hora = (int)valor.intValue();
		
			stringAtual = string.substring(posIndex+1,posIndex+3);
			valor = new Integer(Integer.parseInt(stringAtual, 10));
			minuto = (int)valor.intValue();
		
			System.out.println(minuto+"/"+hora+"/"+dia+"/"+mes+"/"+ano);

			int mes31 = 31;
			int mes30= 30;
			int mes28=28;
			
			if(mes==1) 
				mes =0;
			else if(mes == 2)
				mes = mes31;
			else if(mes == 3)
				mes = mes31+mes28;
			else if(mes == 4)	
				mes = 2*mes31+mes28;
			else if(mes == 5)	
				mes = 2*mes31+mes30+mes28;
			else if(mes == 6)	
				mes = 3*mes31+mes30+mes28;
			else if(mes == 7)	
					mes = 3*mes31+2*mes30+mes28;
			else if(mes == 8)	
				mes = 4*mes31+2*mes30+mes28;
			else if(mes == 9)	
				mes = 5*mes31+2*mes30+mes28;
			else if(mes == 10)	
				mes = 5*mes31+3*mes30+mes28;
			else if(mes == 11)	
				mes = 6*mes31+3*mes30+mes28;
			else if(mes == 12)
				mes = 6*mes31+4*mes30+mes28;
			
			string = minuto+"/"+hora+"/"+String.valueOf(dia+mes)+"/"+ano;		
			System.out.println("string:"+string);
			return string;
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no transformaDataEVendaParaAgILE" + string+" "+posIndex+" "+posIndexAtual);
		}
		return "";
	}
	
	/************************** BuscaDetalhes *****************************/
	/**faz a busca dos destalhes como descri��o e a foto para o lokau.com */
	private void BuscaDetalhes(Item item)//	throws Exception 
	{
		BufferedReader in;
		try
		{
					//Abre a conex�o, para pegar os detalhes de cada produto(fotos e descricao)
			String stringTotal;
//http://www.evenda.com/VerItem.asp?Item=722
			stringTotal = "Item="+item.vetorCaracteristica.getValorCarac("codigo");

//			stringTotal = URLEncoder.encode(stringTotal);			


			String s = base()+"VerItem.asp?"+stringTotal;
			URL site = new URL(s);
			URLConnection siteConnection = site.openConnection();
			in = new BufferedReader(
						new InputStreamReader(
						site.openStream()));
			String inputLine;
			int fromIndex = 0;
			int index;
			int fim,inic;
			String string;
		
			//pega cada linha
			while ((inputLine = in.readLine()) != null)
			{
				System.out.println (inputLine);

				//categoria		
				//href=http://www.evenda.com/listas/listagens/categoria1/index.htm><font Narrow>Antiguidades</font></a></div>
				if ((index = inputLine.indexOf("Narrow>",0)) > 0 )
				{
					//pega o 
					inic = inputLine.indexOf(">",index);
					if ( inic > 0)
					{
						inic++;
						fim = inputLine.indexOf("<",inic);
						string =  inputLine.substring(inic,fim);
						item.vetorCaracteristica.setValorCarac("categoria",string);
					}
				}
//				<td width=146><strong>Maior oferta:</strong></td>
//				<td width=180>R$ 5,00</td>
				else if ((index = inputLine.indexOf("Maior oferta:",0)) > 0 )//valorAtual
				{
					inputLine = in.readLine();
					System.out.println(inputLine);
					//pega o 
					inic = inputLine.indexOf(">",0);
					if ( inic > 0)
					{
						inic = inic=inic+4;
						fim = inputLine.indexOf("<",inic);
						string =  inputLine.substring(inic,fim);
						string = Enviador.transformaNumeroVirgulaNumeroPonto(string);
						item.vetorCaracteristica.setValorCarac("valorAtual",string);
					}
				}
//				<td width=158><strong>Pre�o inicial:</strong></td>
//				<td width=172>R$ 5,00</td>
				else if ((index = inputLine.indexOf("inicial:",0)) > 0 )//valorInicial
				{
					inputLine = in.readLine();
					System.out.println(inputLine);
					//pega o 
					inic = inputLine.indexOf("$",0);
					if ( inic > 0)
					{
						inic = inic=inic+2;
						fim = inputLine.indexOf("<",inic);
						string =  inputLine.substring(inic,fim);
						string = Enviador.transformaNumeroVirgulaNumeroPonto(string);						
						item.vetorCaracteristica.setValorCarac("valorInicial",string);
					}
				}				
//				<td width=158><strong># de ofertas:</strong></td>
//				<td width=172>0 <a 
				else if ((index = inputLine.indexOf("ofertas:",0)) > 0 )//numeroOfertas
				{
					inputLine = in.readLine();
					System.out.println(inputLine);					
					inic = inputLine.indexOf("width",index);
					inic = inputLine.indexOf(">",0);
					if ( inic > 0)
					{
						inic = inic=inic+1;
						fim = inputLine.indexOf(" ",inic);
						string =  inputLine.substring(inic,fim);
						item.vetorCaracteristica.setValorCarac("numeroOfertas",string);
					}
				}				
//				<td width=146><strong>Inicio:</strong></td>
//				<td width=180>30/10/2001 07:31:30</td>
				else if ((index = inputLine.indexOf("Inicio:",0)) > 0 )//dataInicio
				{
					inputLine = in.readLine();
					System.out.println(inputLine);
					inic = inputLine.indexOf("width",0);
					inic = inputLine.indexOf(">",inic);
					if ( inic > 0)
					{
						inic = inic=inic+1;
						fim = inputLine.indexOf("<",inic);
						string =  inputLine.substring(inic,fim);
						string = transformaDataEVendaParaAgILE(string);
						item.vetorCaracteristica.setValorCarac("dataInicio",string);
					}
				}				
//				<td width=158><strong>Fim:</strong></td>
//				<td width=172>2/11/2001 07:31:30</td>
				else if ((index = inputLine.indexOf("Fim:",0)) > 0 )//DataFim
				{
					inputLine = in.readLine();
					System.out.println(inputLine);
					inic = inputLine.indexOf("width",0);
					inic = inputLine.indexOf(">",inic);
					if ( inic > 0)
					{
						inic = inic=inic+1;
						fim = inputLine.indexOf("<",inic);
						string =  inputLine.substring(inic,fim);
						string = transformaDataEVendaParaAgILE(string);
						item.vetorCaracteristica.setValorCarac("dataFim",string);
					}
				}				

//				<td width=110>Incremento:</td>
//				<td width=79>R$ 0,50</td>
				else if ((index = inputLine.indexOf("Incremento:",0)) > 0 )//DataFim
				{
					inputLine = in.readLine();
					System.out.println(inputLine);
					inic = inputLine.indexOf(">",0);
					if ( inic > 0)
					{
						inic = inic=inic+4;
						fim = inputLine.indexOf("<",inic);
						string =  inputLine.substring(inic,fim);
						string = Enviador.transformaNumeroVirgulaNumeroPonto(string);
						item.vetorCaracteristica.setValorCarac("menorDiferenca",string);
					}
				}
//				<td width=146><strong>Vendedor:</strong></td>
//				    <td width=180> <a href = http://www.evenda.com/PerguntaEmail.asp?Username=romalopes>romalopes</a> 
//				    <a href=http://www.evenda.com/VerComentarios.asp?Username=romalopes>(0)</a></td>
				else if ((index = inputLine.indexOf(">Vendedor:",0)) > 0 )//NomeVendedor e Estrelas Vendedor
				{
					inputLine = in.readLine();
					System.out.println(inputLine);
					inic = inputLine.indexOf("me=",0);//Username=
					if ( inic > 0)
					{
						inic = inic=inic+3;
						fim = inputLine.indexOf("<",inic);
						string =  inputLine.substring(inic,fim);
						item.vetorCaracteristica.setValorCarac("nomeDono",string);
					}
					inputLine = in.readLine();
					System.out.println(inputLine);
					inic = inputLine.indexOf(">(",0);
					if ( inic > 0)
					{
						inic = inic=inic+2;
						fim = inputLine.indexOf("(",inic);
						string =  inputLine.substring(inic,fim);
						item.vetorCaracteristica.setValorCarac("numeroEstrelasVendedor",string);
					}
				}												
//				<td width=146><strong>Maior oferta de:</strong></td>
//				<td width=180> <a href = http://www.evenda.com/PerguntaEmail.asp?Username=romalopes>romalopes</a> 
//				<a href = http://www.evenda.com/VerComentarios.asp?Username=romalopes>(0)</a> 
				else if ((index = inputLine.indexOf("oferta de:",0)) > 0 )//NomeVencedor e Estrelas Vencedor
				{
					inputLine = in.readLine();
					System.out.println(inputLine);
					inic = inputLine.indexOf("me=",0);//Username=
					if ( inic > 0)
					{
						inic = inic=inic+3;
						fim = inputLine.indexOf("<",inic);
						string =  inputLine.substring(inic,fim);
						item.vetorCaracteristica.setValorCarac("participanteAtual",string);
					}
					inputLine = in.readLine();
					System.out.println(inputLine);
					inic = inputLine.indexOf(">(",0);
					if ( inic > 0)
					{
						inic = inic=inic+2;
						fim = inputLine.indexOf("(",inic);
						string =  inputLine.substring(inic,fim);
						System.out.println("string:"+inic+" "+fim+" "+string);
						item.vetorCaracteristica.setValorCarac("numeroEstrelasVencedor",string);
					}
				}																

			}			
			in.close();
		}
		catch(Exception e)
		{
			System.err.println(e+ " Erro em buscaDetalhes"+agente().stringErro());
		}

	}

	/************************** Busca *****************************/	
	/**faz a busca para o lokau.com **/
	public Item Busca(String nomeProd)
	{
		Item item = null;

		try
		{
		
			int num = 0;
			
			//while para pegar cada linha
			while ( (m_inputLine = m_in.readLine()) != null && item ==null)
			{
				System.out.println (m_inputLine);
//				m_inputLine = URLDecoder.decode(m_inputLine);
				int fromIndex = 0;
				
//           <a href = http://www.evenda.com/VerItem.asp?Item=722>mequetrefe</a>
				int index = m_inputLine.indexOf("Item=",fromIndex);
				if (index>0)
				{
					fromIndex = 0;
					int fim,inic = index+5;
					//pega o codigo
					fim = m_inputLine.indexOf(">",inic);
					System.out.println ("\n\n*******************************\n*****"+inic+" "+fim+"******\n\n*******************************");
					String codigoProd =  m_inputLine.substring(inic,fim);
					System.out.println ("\n\n*******************************\n*****"+codigoProd+"******\n\n*******************************");
					num++;
						
					//pega o nome do produto
					inic = fim+1;
					fim = m_inputLine.indexOf("</a",inic);
					String stringNome;
					if(fim >=0)
						stringNome =  m_inputLine.substring(inic,fim);
					else
						continue;
					System.out.println ("Nome = "+stringNome);
					
						
					//cria o item seta o codigo e o nome
					item = new Item(stringNome,agente(),this);
					item.vetorCaracteristica.setValorCarac("codigo",codigoProd);

					GregorianCalendar dataAtual = new GregorianCalendar();
					item.setData(dataAtual);
						
					BuscaDetalhes(item);
					return item;
				}
			}	
		}
		catch(Exception e)
		{
			System.err.println(e+ " Erro no Busca do PagiaLokau"+agente().stringErro() );
			return null;
		}			
	
//		this.finalizaConexao();
		
		return item;
	}

	
	/************************** IniciaOferta *****************************/	
	/*********************************************************************/	
	public void IniciaOferta() 
	{
		try
		{
		/*
			//abre conex�o ...
			String stringTotal="";
			stringTotal = "Username="+this.login()+"&";
			stringTotal += "Password="+this.senha()+"&";
			stringTotal += "OfertaMaxima="++"&";
			stringTotal += "Ordem=[c]&";
			stringTotal += "srchdesc=y";
/*                <tr> 
                    <input type=text name=Username size=18>
                  <td width=169><input type=password name=Password size=18></td>
                  <td width=169><input type=text name=OfertaMaxima size=18></td>
                  <td width=110><b>Oferta m�nima:</b></td>
                   
                  <td width=79><b>R$ 5,00</b></td>
                   </tr>
                 
              </table>
            </center>
          </div>
          <div align=center> 
            <center>
              <p><input type=submit value=Enviar name=B1></p>
*			  
			
			DataOutputStream    printout;

			// URL of CGI-Bin script.
			m_url = new URL (base()+"BuscaItens.asp");
			// URL connection channel.
			m_siteConnection = m_url.openConnection();
			// Let the run-time system (RTS) know that we want input.
			m_siteConnection.setDoInput (true);
			// Let the RTS know that we want to do output.
			m_siteConnection.setDoOutput (true);
			// No caching, we want the real thing.
			m_siteConnection.setUseCaches (false);
			// Specify the content type.
			m_siteConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			// Send POST output.
			printout = new DataOutputStream (m_siteConnection.getOutputStream ());
			printout.writeBytes (stringTotal);
			printout.flush ();
			printout.close ();
			m_in = new BufferedReader(
						new InputStreamReader(m_siteConnection.getInputStream()));
	*/	}
		catch(Exception e)
		{
			System.out.println(e+ " Erro no IniciaOferta" );
		}			
	}
	
	/************************** realizaOferta ****************************/
	/*********************************************************************/
	public boolean realizaOfertaItem(Item item,double valorOferta)
	{
		try
		{
		
			int index;
			IniciaOferta();
			
			//abre conex�o ... e j� realiza a oferta.
			//abre conex�o ...
			String stringTotal="";
			stringTotal = "Username="+this.login()+"&";
			stringTotal += "Password="+this.senha()+"&";
			stringTotal += "Quantidade=1&";
			stringTotal += "OfertaMaxima="+Enviador.transformaNumeroPontoNumeroVirgula(String.valueOf(valorOferta))+"&";

			stringTotal += "submit=Enviar";
/*                <tr> 
	                <input type=hidden name=Quantidade value=1>
			        <input type=text name=Username size=18>
			      <td width=169><input type=password name=Password size=18></td>
			      <td width=169><input type=text name=OfertaMaxima size=18></td>
			  <p><input type=submit value=Enviar name=B1></p>
*/			  
			
			System.out.println(stringTotal);
			DataOutputStream    printout;

			// URL of CGI-Bin script.
			String s = base()+"GravaOferta.asp?Item="+item.vetorCaracteristica.getValorCarac("codigo");
			System.out.println(s);
			m_url = new URL (s);
			// URL connection channel.
			m_siteConnection = m_url.openConnection();
			// Let the run-time system (RTS) know that we want input.
			m_siteConnection.setDoInput (true);
			// Let the RTS know that we want to do output.
			m_siteConnection.setDoOutput (true);
			// No caching, we want the real thing.
			m_siteConnection.setUseCaches (false);
			// Specify the content type.
			m_siteConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			// Send POST output.
			printout = new DataOutputStream (m_siteConnection.getOutputStream ());
			printout.writeBytes (stringTotal);
			printout.flush ();
			printout.close ();
			m_in = new BufferedReader(
						new InputStreamReader(m_siteConnection.getInputStream()));
		
			//verifica se a oferta foi aceita, se sim faz mais alguma coisa...
			//while para pegar cada linha
			Mensagem msg = new Mensagem(agente().nomeUsuarioPagina(),Enviador.nomeHostGerente);
			
			while ( (m_inputLine = m_in.readLine()) != null )
			{
				
				AgenteCompra ag = (AgenteCompra) agente();				
				if (m_inputLine.indexOf("Obrigado pela sua",0)>0)
				{
					msg.setMensagemRetorno(true);
					String msgAux = agente().nomeUsuarioPagina()+","+item.vetorCaracteristica.getValorCarac("codigo")+","+String.valueOf(valorOferta)+",0";//+oferta.numeroEstrelas();					
					msg.setMensagemAux(msgAux);
					ag.recebeReplyOferta(msg);				
  					 return true;
				}
				else if (m_inputLine.indexOf("Desculpe mas sua",0)>0)//oferta n�o aceita
				{
					double valorAtual;
					valorAtual = valorOferta + item.vetorCaracteristica.getValorCaracDouble("menorDiferenca");
					msg.setMensagemAux("outro"+","+item.vetorCaracteristica.getValorCarac("codigo")+","+String.valueOf(valorAtual)+",restricoes");
					ag.recebeReplyOferta(msg);				
					return true;
				}
//				else//leilao fechado
//				{
//					msg.setMensagemAux(""+","+it.vetorCaracteristica.getValorCarac("codigo")+","+it.vetorCaracteristica.getValorCarac("valorAtual")+",fechado");
//				}
	
			}
			finalizaConexao();
		}
		catch(Exception e)
		{
			System.err.println(e+"Erro no RealizaOferta do PaginaLokau para "+item.vetorCaracteristica.getValorCarac("codigo") + " " + agente().stringErro() );
			return false;
		}
		return true;
	}
	
	
	public int tempoRestante(Item it)
	{
		try
		{
			int minutosInicio=0,minutosFim;
			Calendar calendar = new GregorianCalendar();	
		
/*			String dataInicio = it.vetorCaracteristica.getValorCarac("dataInicio");

			int minutoInicio = (int)Enviador.pegaParteInteiro(dataInicio,0,'/');
			int horaInicio = (int)Enviador.pegaParteInteiro(dataInicio,1,'/');	
			int diaInicio = (int)Enviador.pegaParteInteiro(dataInicio,2,'/');		
			int AnoInicio = (int)Enviador.pegaParteInteiro(dataInicio,3,'/');			
		
			minutosInicio = (calendar.get(Calendar.YEAR) - Ano)*365*24*60;
			minutosInicio += (calendar.get(Calendar.DAY_OF_YEAR) - dia)*24*60;
			minutosInicio += (calendar.get(Calendar.HOUR_OF_DAY) - hora)*60;		
			minutosInicio += (calendar.get(Calendar.MINUTE) - minuto);		
			
			String("dataInicio: "+dataInicio+" minutos:"+minutosInicio);
*/
			String dataFim = it.vetorCaracteristica.getValorCarac("dataFim");

			int minuto = (int)Enviador.pegaParteInteiro(dataFim,0,'/');
			int hora = (int)Enviador.pegaParteInteiro(dataFim,1,'/');	
			int dia = (int)Enviador.pegaParteInteiro(dataFim,2,'/');		
			int Ano = (int)Enviador.pegaParteInteiro(dataFim,3,'/');					
				
			minutosFim = (Ano - calendar.get(Calendar.YEAR))*365*24*60;
			minutosFim += (dia-calendar.get(Calendar.DAY_OF_YEAR))*24*60;
			minutosFim += (hora-calendar.get(Calendar.HOUR_OF_DAY))*60;		
			minutosFim += (minuto-calendar.get(Calendar.MINUTE));		
			
	
			System.out.println("Tempo restante: "+minutosFim);
			if(minutosFim>0)
				return minutosFim;

		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em tempoRestante(String,int) de "+agente().stringErro());
		}
		return 0;
	}
	
	
	public int prazo(Item it)
	{
		try
		{
			int minutosInicio=0,minutosFim;
			Calendar calendar = new GregorianCalendar();	
		
			String dataInicio = it.vetorCaracteristica.getValorCarac("dataInicio");

			int minutoInicio = (int)Enviador.pegaParteInteiro(dataInicio,0,'/');
			int horaInicio = (int)Enviador.pegaParteInteiro(dataInicio,1,'/');	
			int diaInicio = (int)Enviador.pegaParteInteiro(dataInicio,2,'/');		
			int AnoInicio = (int)Enviador.pegaParteInteiro(dataInicio,3,'/');			
		

			System.out.println("dataInicio: "+dataInicio);

			String dataFim = it.vetorCaracteristica.getValorCarac("dataFim");

			int minutoFim = (int)Enviador.pegaParteInteiro(dataFim,0,'/');
			int horaFim = (int)Enviador.pegaParteInteiro(dataFim,1,'/');	
			int diaFim = (int)Enviador.pegaParteInteiro(dataFim,2,'/');		
			int AnoFim = (int)Enviador.pegaParteInteiro(dataFim,3,'/');					
				
			minutosFim = (AnoFim - AnoInicio)*365*24*60;
			minutosFim += (diaFim - diaInicio)*24*60;
			minutosFim += (horaFim - horaInicio)*60;		
			minutosFim += (minutoFim - minutoInicio);		
			
	
			System.out.println("Prazo: "+minutosFim);
			if(minutosFim>0)
				return minutosFim;

		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em prazo(item) de "+agente().stringErro());
		}
		return 0;
	}
	
	public int tempoRodando(Item it)
	{
		try
		{
			int minutos=0;
			Calendar calendar = new GregorianCalendar();	
		
			String dataInicio = it.vetorCaracteristica.getValorCarac("dataInicio");

			int minutoInicio = (int)Enviador.pegaParteInteiro(dataInicio,0,'/');
			int horaInicio = (int)Enviador.pegaParteInteiro(dataInicio,1,'/');	
			int diaInicio = (int)Enviador.pegaParteInteiro(dataInicio,2,'/');		
			int AnoInicio = (int)Enviador.pegaParteInteiro(dataInicio,3,'/');			
		
//			int minutoFim = (int)Enviador.pegaParteInteiro(dataInicio,0,'/');
//			int horaFim = (int)Enviador.pegaParteInteiro(dataInicio,1,'/');	
//			int diaFim = (int)Enviador.pegaParteInteiro(dataInicio,2,'/');		
//			int AnoFim = (int)Enviador.pegaParteInteiro(dataInicio,3,'/');			

			minutos = (calendar.get(Calendar.YEAR) - AnoInicio)*365*24*60;
			minutos += (calendar.get(Calendar.DAY_OF_YEAR) - diaInicio)*24*60;
			minutos += (calendar.get(Calendar.HOUR_OF_DAY) - horaInicio)*60;		
			minutos += (calendar.get(Calendar.MINUTE) - minutoInicio);		

			System.out.println("Tempo rodando: "+minutos);
			if(minutos>0)
				return minutos;

		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em tempoRodando(String,int) de "+agente().stringErro());
		}
		return 0;
	}
	
}


