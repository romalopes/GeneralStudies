/**classe Abstrata Agente**/
	
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;


public class IP_Remote
{	
	protected Usuario m_usuario;
	String m_ip;
	/**Crit�rios e Restri��es.**/
	public IP_Remote(){	}
	public IP_Remote(String ip,Usuario u)
	{
		m_ip = ip;
		m_usuario = u;
		
	};
	
	public Usuario usuario(){return m_usuario;};
	public String ip(){return m_ip;};
	

	public void init(){}

}