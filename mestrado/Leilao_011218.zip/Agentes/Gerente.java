
import java.io.*;    //-Package de classes para manipulacao de E/S
import java.net.*;   //Package de classes para manipulacao de Sockets, IP, etc.
import java.util.*;

import ClassesGeral.ObjetoEnviado;
import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;


public class Gerente implements Serializable
{
//	final static int PortaRecebimentoServidor = 8182;
//	final static int PortaRecebimentoCliente = 8181;
//	final static String nomeHost = "192.168.0.12";
	final String nomeAdministrador = "roma";
	final String senhaAdministrador = "lopes";


 //Listas de Participantes do leilao e produtos
  	Vector m_listAgentes;
 	Vector m_listUsuarios;
	Vector m_listUsLogados;
	RelogioAgente m_relogioAgente;
//Listas de Participantes do leilao e produtos

	boolean m_blogado;//verifica se o usu�rio que chamou a mensagem est� logado.
	
	
	public Gerente()
			throws IOException, ClassNotFoundException
	{
	
		Enviador.nomeHostProcessador = "192.168.0.25";
		Enviador.nomeHostGerente = "192.168.0.25";	
	
	
		m_listAgentes = new Vector();
		m_listUsuarios = new Vector();
		m_listUsLogados = new Vector();
		m_blogado = false;
		scriptInicial();
	}
	

	private void scriptInicial()
	{
		try
		{
			Mensagem msg = new Mensagem("","");
			m_blogado = true;
			//cria usuario
			StringBuffer string = new StringBuffer();
//////////////Venda
//////////////
//cria Agente VENDA
	
			msg.setNome("roma1");
			msg.setMensagemAux("lopes,roma1@addlabs");
			processaMensagemNovoUsuario(msg);//usuario

			msg.setMensagemAux("Venda,romaVenda");
			processaMensagemCriaAgente(msg);
//ro,autonomia,2,sites,arremate,mlivre,akrm,precoMin,precoMax,
//Modifica a configura��o com base na mensagem que foi passado pelo usu�rio
			
			string.append("romaVenda,");//nomeAgente
			string.append("2,");//autonomia
			string.append("PerfilConcorrente,");
//			string.append("Simples,");
			string.append("nomeProduto,");			
			string.append("carro,");
			string.append("valorInicial,");
			string.append("50,");
			string.append("Prazo,");
			string.append("8,");
			string.append("bValorReserva,");
			string.append("true,");
			string.append("ValorReserva,");
			string.append("800,");
			string.append("MenorDiferenca,");
			string.append("40,");
			string.append("detalhes,");
			string.append("carro que tamb�m funciona,");
			string.append("categoria,");
			string.append("automovel,");
			string.append("numeroOfertasMinimo,");
			string.append("1,");
			string.append("fatorNumeroEstrelas,");
			string.append("3,");
			string.append("fatorValorReserva,");
			string.append("0.3,");
			string.append("fatorPrazo,");
			string.append("1.8,");
			string.append("avaliacaoItemMinima,");
			string.append("0.3,");
			string.append("nivelConcorrencia,");
			string.append("0,");			
						
			
			string.append("site,");
			string.append("AKRM,");//nomeSite  // � um desse para cada p�gina.			
			string.append("tipoLeilao,");
			string.append("Ingles,");	

			msg.setMensagemAux(string.toString());
//			msg.setNome("roma");
			msg.setMensagem("ConfiguracaoAgenteVenda");
			this.processaMensagem(msg);		

			//Trabalhar
			msg.setNome("roma");			
			msg.setMensagemAux("romaVenda");			
			processaTrabalhar(msg);
			
			
//////////////Venda 2
//////////////			
//cria Agente de Venda 2  VENDA
			msg.setNome("roma2");
			msg.setMensagemAux("lopes,roma2@addlabs");
			processaMensagemNovoUsuario(msg);//usuario

//			msg.setNome("roma");
			msg.setMensagemAux("Venda,romaVenda_Segundo");
			processaMensagemCriaAgente(msg);
//ro,autonomia,2,sites,arremate,mlivre,akrm,precoMin,precoMax,
//Modifica a configura��o com base na mensagem que foi passado pelo usu�rio
			string = new StringBuffer();
			string.append("romaVenda_Segundo,");//nomeAgente
			string.append("2,");//autonomia
			string.append("PerfilConcorrente,");
			string.append("nomeProduto,");			
			string.append("radio,");
			string.append("valorInicial,");
			string.append("10,");
			string.append("Prazo,");
			string.append("8,");
			string.append("bValorReserva,");
			string.append("true,");
			string.append("ValorReserva,");
			string.append("300,");
			string.append("MenorDiferenca,");
			string.append("30,");
			string.append("detalhes,");
			string.append("radio com CD para carro,");
			string.append("categoria,");
			string.append("automovel,");
			string.append("numeroOfertasMinimo,");
			string.append("1,");
			string.append("fatorNumeroEstrelas,");
			string.append("3,");
			string.append("fatorValorReserva,");
			string.append("0.3,");
			string.append("fatorPrazo,");
			string.append("1.8,");
			string.append("avaliacaoItemMinima,");
			string.append("0.3,");
			string.append("nivelConcorrencia,");
			string.append("25,");			
//			string.append("site,");//nomeSite			
//			string.append("EVENDA,");//nomeSite
//			string.append("login,");
//			string.append("romalopes,");
//			string.append("senha,");
//			string.append("novembro,");
//			string.append("tipoLeilao,");
//			string.append("Ingles,");	
			
			string.append("site,");//nomeSite			
			string.append("AKRM,");//nomeSite
			string.append("tipoLeilao,");
			string.append("Ingles,");				

			msg.setMensagemAux(string.toString());
//			msg.setNome("roma");
			msg.setMensagem("ConfiguracaoAgenteVenda");
			this.processaMensagem(msg);		
			//Trabalhar
			msg.setMensagemAux("romaVenda_Segundo");			
			processaTrabalhar(msg);


// */
//////////romaCompra
//////////		
			//cria Agente
			msg.setNome("roma3");
			msg.setMensagemAux("lopes,roma3@addlabs");
			processaMensagemNovoUsuario(msg);//usuario			
			
//			msg.setNome("roma");
			msg.setMensagemAux("Compra,ReCompra,Carro");
			processaMensagemCriaAgente(msg);

//ro,autonomia,2,sites,arremate,mlivre,akrm,precoMin,precoMax,
//Modifica a configura��o com base na mensagem que foi passado pelo usu�rio
			string = new StringBuffer();
			string.append("ReCompra,");//nomeAgente
			string.append("2,");//autonomia
			string.append("PerfilConcorrente,");			
//			string.append("Simples,");			
			string.append("nomeProduto,");
			string.append("radio,");
			string.append("PrecoMax,");
			string.append("1700,");
			string.append("PrecoMin,");
			string.append("5,");
			string.append("tempoTrabalho,");
			string.append("7,");
			string.append("detalhes,");
			string.append("carro que funcione um pouquinho,");
			string.append("categoria,");
			string.append("Antiguidades,");
			string.append("avaliacaoItemMinima,");			
			string.append("0.3,");						
			string.append("fatorNumeroConcorrentes,");			
			string.append("0,");
			string.append("fatorEstrelasConcorrentes,");			
			string.append("2,");
			string.append("subTipoEstrategia,");
//			string.append("moderado,");						
			string.append("arriscado,");			
			
//			string.append("site,");//nomeSite			
//			string.append("EVENDA,");//nomeSite
//			string.append("login,");
//			string.append("romalopes,");
//			string.append("senha,");
//			string.append("novembro,");
//			string.append("tipoLeilao,");
//			string.append("Ingles,");	
//			string.append("&,");


			msg.setMensagemAux(string.toString());
//			msg.setNome("roma");
			msg.setMensagem("ConfiguracaoAgenteCompra");
			this.processaMensagem(msg);		

			//Trabalhar
//			msg.setNome("roma");			
			msg.setMensagemAux("ReCompra");			
			processaTrabalhar(msg);
// 

			
//////////romaCompra
//////////		
			//cria Agente
			msg.setNome("roma6");
			msg.setMensagemAux("lopes,roma6@addlabs");
			processaMensagemNovoUsuario(msg);//usuario			

			//cria Agente
			msg.setNome("roma6");
			msg.setMensagemAux("Compra,romaCompra,carro");
			processaMensagemCriaAgente(msg);

//ro,autonomia,2,sites,arremate,mlivre,akrm,precoMin,precoMax,
//Modifica a configura��o com base na mensagem que foi passado pelo usu�rio
			string = new StringBuffer();
			string.append("romaCompra,");//nomeAgente
			string.append("2,");//autonomia
			string.append("PerfilConcorrente,");//TempoValor,");			
//			string.append("AKRM,");//nomeSite
//			string.append("tipoLeilao,");
//			string.append("Ingles,");	
			string.append("nomeProduto,");
			string.append("carro,");
			string.append("PrecoMax,");
			string.append("1700,");
			string.append("PrecoMin,");
			string.append("10,");
			string.append("tempoTrabalho,");
			string.append("20,");
			string.append("detalhes,");
			string.append("carro que funcione um pouquinho,");
			string.append("categoria,");
			string.append("Antiguidades,");
			string.append("avaliacaoItemMinima,");			
			string.append("0.3,");						
			string.append("fatorNumeroConcorrentes,");			
			string.append("0,");
			string.append("fatorEstrelasConcorrentes,");			
			string.append("2,");
			string.append("subTipoEstrategia,");
//			string.append("NORMAL,");						
			string.append("arriscado,");						
//			string.append("site,");
//			string.append("EVENDA,");//nomeSite
//			string.append("login,");
//			string.append("romalopes2,");
//			string.append("senha,");
//			string.append("novembro,");
//			string.append("tipoLeilao,");
//			string.append("Ingles,");	
//			string.append("&,");
//			
			string.append("site,");//nomeSite			
			string.append("AKRM,");//nomeSite
			string.append("tipoLeilao,");
			string.append("Ingles,");	
			
			msg.setMensagemAux(string.toString());
			msg.setNome("roma6");
			msg.setMensagem("ConfiguracaoAgenteCompra");
			this.processaMensagem(msg);		

			//Trabalhar
			msg.setNome("roma6");			
			msg.setMensagemAux("romaCompra");			
			processaTrabalhar(msg);


///////////////MariaCompra
//////////////

			//cria Agente
			msg.setNome("romario");
			msg.setMensagemAux("lopes,roma4@addlabs");
			processaMensagemNovoUsuario(msg);//usuario
						
//			msg.setNome("roma");//nome do usuario
			msg.setMensagemAux("Compra,Romarinho_Agente");
			processaMensagemCriaAgente(msg);

//ro,autonomia,2,sites,arremate,mlivre,akrm,precoMin,precoMax,
//Modifica a configura��o com base na mensagem que foi passado pelo usu�rio
			string = new StringBuffer();
//			string.append("MariaCompra,");//nomeAgente
			string.append("Romarinho_Agente,");//nomeAgente
			string.append("2,");//autonomia
			string.append("PerfilConcorrente,");
//			string.append("simples,");			
			string.append("nomeProduto,");
			string.append("carro,");
			string.append("PrecoMax,");
			string.append("1400,");
			string.append("PrecoMin,");
			string.append("10,");
			string.append("tempoTrabalho,");
			string.append("5,");			
			string.append("detalhes,");
			string.append("carro que funcione um pouquinho,");
			string.append("categoria,");
			string.append("automovel,");
			string.append("avaliacaoItemMinima,");			
			string.append("0.3,");
			string.append("fatorNumeroConcorrentes,");			
			string.append("3,");
			string.append("fatorEstrelasConcorrentes,");			
			string.append("4,");
			string.append("subTipoEstrategia,");
//			string.append("moderado,");			
			string.append("arriscado,");						
			
//			string.append("site,");
//			string.append("EVENDA,");//nomeSite
//			string.append("login,");
//			string.append("romalopes2,");
//			string.append("senha,");
//			string.append("novembro,");
//			string.append("tipoLeilao,");
//			string.append("Ingles,");	
//			string.append("site,");
//			string.append("AKRM,");//nomeSite
//			string.append("tipoLeilao,");
//			string.append("Ingles,");	

			msg.setMensagemAux(string.toString());
			msg.setMensagem("ConfiguracaoAgenteCompra");
			this.processaMensagem(msg);		

			//Trabalhar
			msg.setMensagemAux("Romarinho_Agente");			
			processaTrabalhar(msg);

// /*
/////////////Venda 2
//////////////			
//cria Agente de Venda 2  VENDA
			msg.setNome("roma10");
			msg.setMensagemAux("lopes,roma10@addlabs.uff.br");
			processaMensagemNovoUsuario(msg);//usuario
//
//			msg.setNome("roma");
			msg.setMensagemAux("Venda,roma_10_Venda");
			processaMensagemCriaAgente(msg);
//ro,autonomia,2,sites,arremate,mlivre,akrm,precoMin,precoMax,
//Modifica a configura��o com base na mensagem que foi passado pelo usu�rio
			string = new StringBuffer();
			string.append("roma_10_Venda,");//nomeAgente
			string.append("2,");//autonomia
			string.append("PerfilConcorrente,");
			string.append("nomeProduto,");			
			string.append("carro bom,");
			string.append("valorInicial,");
			string.append("100,");
			string.append("Prazo,");
			string.append("5,");
			string.append("bValorReserva,");
			string.append("true,");
			string.append("ValorReserva,");
			string.append("2000,");
			string.append("MenorDiferenca,");
			string.append("20,");
			string.append("detalhes,");
			string.append("carro do roma 10,");
			string.append("categoria,");
			string.append("automovel,");
			string.append("numeroOfertasMinimo,");
			string.append("3,");
			string.append("fatorNumeroEstrelas,");
			string.append("3,");
			string.append("fatorNumeroEstrelas,");
			string.append("3,");
			string.append("fatorValorReserva,");
			string.append("0.1,");
			string.append("fatorPrazo,");
			string.append("1.2,");
			string.append("avaliacaoItemMinima,");
			string.append("0.1,");			
			string.append("nivelConcorrencia,");
			string.append("25,");					
//			string.append("site,");//nomeSite			
//			string.append("EVENDA,");//nomeSite
//			string.append("login,");
//			string.append("romalopes,");
//			string.append("senha,");
//			string.append("novembro,");
//			string.append("tipoLeilao,");
//			string.append("Ingles,");	
			
			string.append("site,");//nomeSite			
			string.append("AKRM,");//nomeSite
			string.append("tipoLeilao,");
			string.append("Ingles,");				

			msg.setMensagemAux(string.toString());
//			msg.setNome("roma");
			msg.setMensagem("ConfiguracaoAgenteVenda");
			this.processaMensagem(msg);		
			//Trabalhar
			msg.setMensagemAux("roma_10_Venda");			
			processaTrabalhar(msg);

// *
////////////TesteLeiloeiro
////////////



//cria Agente
			msg.setNome("romario_leilo");
			msg.setMensagemAux("lopes,romario_leilo@addlabs");
			processaMensagemNovoUsuario(msg);//usuario

//			msg.setNome("roma");//nome do usuario
			msg.setMensagemAux("Juntador,rominha_leilo_Agente");
			processaMensagemCriaAgente(msg);

			//Trabalhar
//			msg.setNome("roma");			
			string = new StringBuffer();
			string.append("rominha_leilo_Agente,");//nomeAgente
			string.append("2,");//autonomia
			string.append("PerfilConcorrente,");			
			string.append("detalhes_1,");
			string.append("carro,");
			string.append("detalhes_2,");
			string.append("radio,");
			string.append("categoria,");
			string.append("automovel,");

			msg.setMensagem("ConfiguracaoAgenteLeiloeiro");
			msg.setMensagemAux(string.toString());
			this.processaMensagem(msg);		


			msg.setMensagemAux("rominha_leilo_Agente");			
			processaTrabalhar(msg);
// */			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no scriptInicial");
		}
	}

/************************* serialize ***************************************/
	public boolean serialize(String arquivo) throws IOException
	{
		try
		{
			if (arquivo.length() == 0 )
			{
				arquivo = "nomeDefault.agl";
			}
			
			FileOutputStream ostream = new FileOutputStream(arquivo);
			ObjectOutputStream p = new ObjectOutputStream(ostream);	

			int size = m_listAgentes.size();
			p.writeInt(size);
			for(int i = 0;i<size;i++)
			{
				p.writeObject(m_listAgentes.elementAt(i));
			}

			
			size = m_listUsuarios.size();
			p.writeInt(size);
			for(int i = 0;i<size;i++)
			{
				p.writeObject(m_listUsuarios.elementAt(i));
			}

			ostream.close();
			return true;
		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no serialize do Gerente" );
			return false;
		}			
	}
	
/********************* Salvar *************************************/
//Salvar o Arquivo
	public Mensagem processaMensagemSalvar(Mensagem msg) throws IOException,ClassNotFoundException
	{
		System.out.println("Entra em processaMensagemSalvar" );
		
		try
		{	
			msg.setMensagemRetorno(false);		
			String nome,string,parte;
			
			nome = msg.nome();
			string = msg.mensagemAux();
		
			if(!nome.equalsIgnoreCase(nomeAdministrador))
			{
				System.out.println("Usu�rio n�o � o administrador"+ nome);
				return msg;
			}	
			
			parte = Enviador.pegaParte(string,0,',');
			if (!serialize(parte))
			{
				return msg;

			}
		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no Salvar do Gerente" );
			return msg;
		}	
				
		msg.setMensagemRetorno(true);
		return msg;
	}	


/************************* deSerialize ***************************************/
	public boolean deSerialize(String arquivo)
		throws IOException, ClassNotFoundException
	{
		if (arquivo.length() == 0 )
		{
			return false;
		}

		try
		{

			FileInputStream istream = new FileInputStream(arquivo);
			ObjectInputStream p = new ObjectInputStream(istream);

			m_listAgentes.removeAllElements();
			int size = p.readInt();
			for(int i = 0;i<size;i++)
				m_listAgentes.addElement((Agente)p.readObject());
			
			m_listUsuarios.removeAllElements();
			size = p.readInt();
			for(int i = 0;i<size;i++)
				m_listUsuarios.addElement((Usuario)p.readObject());
	
			istream.close();	
		}
		catch(IOException e)
		{
			System.err.println(e);
			return false;
		}
		catch (ClassNotFoundException Ce)
		{
			System.err.println(Ce);
			return false;
		}
		
		return true;		
	}
	
/********************* Removetudo ********************************/
//Tira todos os usu�rios dos gerente
	public	void RemoveTudo()
	{
		m_listUsuarios.removeAllElements();
		m_listUsLogados.removeAllElements();
	
	}
	

/********************* Abrir *************************************/
//Abre o Arquivo e abre um contexto.
	public Mensagem processaMensagemAbrir(Mensagem msg) 
		throws IOException,ClassNotFoundException
	{
		System.out.println("Entra em processaMensagemAbrir" );	
		try
		{	
			String nome,string,parte;
			msg.setMensagemRetorno(false);			
			nome = msg.nome();
			string = msg.mensagemAux();
			
		
			if(!nome.equalsIgnoreCase(nomeAdministrador))
			{
				System.out.println("Usu�rio n�o � o administrador"+ nome);
				return msg;
			}	
			
			//remove tudo do gerente
			this.RemoveTudo();					
			parte = Enviador.pegaParte(string,0,',');					
			if (deSerialize(parte) == false)
			{
				return msg;
			}
		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no Salvar do Gerente" );
			return msg;
		}			
		catch (ClassNotFoundException Ce)
		{
			System.out.println(Ce);
			return msg;
		}
	
		msg.setMensagemRetorno(true);
		return msg;
	}	


/********************* processaAcessoPrivado *************************************/
//Verifica a senha para acesso privado
	public Mensagem processaAcessoPrivado(Mensagem msg) 
	{
		System.out.println("Entra em processaAcessoPrivado" );	
		try
		{	
			String nome,string;
			
			nome = msg.nome();
			string = msg.mensagemAux();
			msg.setMensagemRetorno(true);			
		
			if(!nome.equalsIgnoreCase(nomeAdministrador))
			{
				System.out.println("Usu�rio n�o � o administrador"+ nome);
				return msg;
			}	
			
			String parte = Enviador.pegaParte(string,0,',');
			if(!parte.equalsIgnoreCase(senhaAdministrador))
			{
				System.out.println("Senha Errada"+ nome);
				return msg;
			}	
			//remove tudo do gerente
		}
		catch(Exception e)
		{
			System.err.println(e+ " Erro no Salvar do Gerente" );
			return msg;
		}			
	
		msg.setMensagemRetorno(true);
		return msg;
	}	

	public synchronized void startRelogio()
	{
		if (m_relogioAgente == null)
		{
			m_relogioAgente = new RelogioAgente(this);
			m_relogioAgente.start();//come�ou buscar... 
		}
	}
	
/**********************************recebeAvisoRelogio()*********************/
	//Recebe o aviso do relogio que se passaram 1 min e repassa ao usu�rio 
	//para que ele repasse aos seus agentes.
	public synchronized void recebeAvisoRelogio()
	{
		try
		{
			// create a GregorianCalendar 
			System.out.println("\n\nGerente foi avisado em : "+ Enviador.getStringData(new GregorianCalendar()));//calendar.get(Calendar.SECOND)+"/"+calendar.get(Calendar.MINUTE)+"/"+calendar.get(Calendar.HOUR_OF_DAY)+"/" +calendar.get(Calendar.DAY_OF_YEAR)+"/"+ calendar.get(Calendar.YEAR) );
			
			//Escrever a Data.
			int size = m_listUsuarios.size();
			Usuario usu;
			for(int i = 0;i<size;i++)
			{
				usu = (Usuario)m_listUsuarios.elementAt(i);
				usu.recebeAvisoRelogio();
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no recebe AvisoRelogio");
		}
	}
	
	
/********************* FindParticipante *************************************/
	public Usuario findUsuarioLogado(String ip)
	{
		for(int i=0;i<m_listUsLogados.size();i++)
		{
			IP_Remote ipAtual = (IP_Remote)m_listUsLogados.elementAt(i);
//			System.out.println(ipAtual.ip() +" "+ ip);
			if((ipAtual.ip()).equals(ip))
				   return ipAtual.usuario();
				
		}
		return null;
	}


/********************* FindParticipante *************************************/
	public Usuario findUsuario(String Nome)
	{
		
		for(int i=0;i<m_listUsuarios.size();i++)
		{
			Usuario usuario = (Usuario)m_listUsuarios.elementAt(i);
			if(usuario.nome().equalsIgnoreCase(Nome))
				   return usuario;
		}
		return null;
	}

/********************* FindAgente *************************************/
	public Agente findAgente(String nome)//procura o agente a partir do nome na p�gina
	{
		String s;	
		Agente ag;			
		for(int i=0;i<m_listAgentes.size();i++)
		{
			ag = (Agente)m_listAgentes.elementAt(i);
			s = ag.nomeUsuarioPagina();
			if (nome.equals(s))
			{
				return ag;
			}
		}
		return null;
	}
	
/********************* registraAgente *************************************/
	public void registraAgente(Agente ag)
	{
		m_listAgentes.addElement(ag);
	}
	
	
/********************* retiraAgenteRegistro *************************************/
	public void retiraAgenteRegistro(Agente agente)
	{
		Agente ag;
		for(int i=0;i<m_listAgentes.size();i++)
		{
			ag = (Agente)m_listAgentes.elementAt(i);
			if (ag == agente) 
			{
				m_listAgentes.removeElementAt(i);
				return;
			}
		}		
	}

/********************* FindParticipante *************************************/
	public Usuario findUsuarioAt(int i)
	{
		int a = m_listUsuarios.size();
		
		if(i>=a)
			return null;
		
		return (Usuario)m_listUsuarios.elementAt(i);
	}

/********************* logoutUsuario *************************************/
	public void logoutUsuario(Usuario u)
	{
		if(u == null)
			return;
		for(int i=0;i<m_listUsLogados.size();i++)
		{
			IP_Remote ipAtual = (IP_Remote)m_listUsLogados.elementAt(i);
			if(ipAtual.usuario() == u)
			{
			   m_listUsLogados.removeElementAt(i);
			   return;
			}
			   
		}
	}



/********************* loginUsuario *************************************/
	public boolean loginUsuario(Mensagem msg)
	{
		Usuario usuario,usuarioLogado;
		String nome,senha,ip;

		nome = msg.nome();
		senha = Enviador.pegaParte(msg.mensagemAux(),0,',');
		ip = msg.ip();

		usuario = findUsuarioLogado(msg.ip());
		logoutUsuario(usuario);
		
		//verificar Senha.
		usuario = findUsuario(nome);
		if( usuario != null)
		{
			if(usuario.senha().equals(senha))
			{
				IP_Remote ip_remote = new IP_Remote(ip,usuario);
				m_listUsLogados.addElement(ip_remote);
				return true;
			}
		}
		return false;
		
	}


/***************** processaMensagemCriaAgente *************************/
//tipoAgente,nomeAgente,nomeProduto
	public Mensagem processaMensagemCriaAgente(Mensagem msg)
	{
		try
		{
			msg.setMensagemRetorno(false);
			Agente ag;
//			System.out.println("Entra em processaMensagemCriaAgente" );	
			String nome = msg.nome();
			String mensagemAux = msg.mensagemAux();
			Usuario usuario;
			String nomeAgente;
			
			
			nomeAgente = Enviador.pegaParte(msg.mensagemAux(),1,',');
			usuario = findUsuario(nome);
			
			
			if(usuario == null)
				return msg;
				
			
			if (usuario.existeAgentes())
			{
				msg.setMensagemRetorno(false);			
				msg.setMensagemAux("Usu�rio n�o pode ter mais de um Agente");
				return msg;
			}
			
			if (findAgente(usuario.nome()+nomeAgente) == null)
			{
				ag = usuario.criaAgenteMensagem(mensagemAux,this);//aqui que define qual o tido do agente		
				if (ag != null)
				{
					registraAgente(ag);
					msg.setNome(usuario.nome());
					msg.setMensagemRetorno(true);
					msg.setMensagemAux("Usu�rio n�o pode ter mais de um Agente");
				}
			}
			else
			{
				System.out.println("Agente "+nomeAgente+ "nao pode ser criado existe para o usuario " + nome);
				return msg;
			}
		}
		catch(Exception e)
		{
			System.err.println(e+"Erro em processaMensagemCriaAgente");
		}
		return msg;
	}
	
	




///********************* processaMensagemNovoUsuario ****************************************
//Se o participante nao existir cria e insere na lista de participantes
//Nao temos diferenca entre comprador ou vendedor(pelo menos por enquanto)
	public Mensagem processaMensagemNovoUsuario(Mensagem msg)  throws IOException
	{
	
		try
		{
			msg.setMensagemRetorno(false);
			String nome = msg.nome();
//			System.out.println("Entra em processaMensagemNovoUsuario ");

			Usuario usuario = findUsuario(nome);
			if( usuario != null)
			{
				return msg;
			}

			usuario =findUsuarioLogado(msg.ip());
			logoutUsuario(usuario);
		
			usuario = new Usuario(nome);
			
			usuario.senha(Enviador.pegaParte(msg.mensagemAux(),0,','));//senha
			usuario.setEmail(Enviador.pegaParte(msg.mensagemAux(),1,','));//email
			System.out.println(msg.mensagemAux());
			
			m_listUsuarios.addElement(usuario);

			int a = m_listUsuarios.size();
//			System.out.println("Quantidade de usuarios " + a);
			
			if (loginUsuario(msg))
			{
				System.out.println("Participante logado "+ usuario.nome()+" Ip:"+msg.ip());
				msg.setMensagemRetorno(true);
			}
		}
		catch(Exception e) 
		{
			System.err.println ("\nErro no processaMensagemNovoUsuario\n");
		}     
		
		return msg;
		
		
	}
	/********************* processaMensagemLogin *************************************/	
	public Mensagem processaMensagemLogout(Mensagem msg)throws Exception
	{
		msg.setMensagemRetorno(false);
		try
		{
			System.out.println("Entra em processaMensagemLogout "+msg.nome() );	

			Usuario usuario;
			usuario = findUsuarioLogado(msg.ip());
			logoutUsuario(usuario);
			usuario = findUsuario(msg.nome());
			logoutUsuario(usuario);
			msg.setMensagemRetorno(true);
		}
		catch (Exception e) 
		{
			System.err.println ("\nErro em processaMensagemLogin\n");
		}     
		return msg;
	}

	
/********************* processaMensagemLogin *************************************/	
	public Mensagem processaMensagemLogin(Mensagem msg)throws Exception
	{
		msg.setMensagemRetorno(false);
		try
		{

//			System.out.println("Entra em processaMensagemLogin "+msg.nome() );	
			Usuario usuario;
			usuario = findUsuarioLogado(msg.ip());
			logoutUsuario(usuario);
			if (loginUsuario(msg))
			{				
				msg.setMensagemRetorno(true);
			}

		}
		catch (Exception e) 
		{
			System.err.println ("\nErro em processaMensagemLogin\n");
		}     
		return msg;
	}

/********************* processaMensagemPegaUsuario *************************************/
public ObjetoEnviado processaMensagemPegaUsuario(Mensagem msg)
{
	try
	{ 
		System.out.println("Entra em processaMensagemPegaUsuario "+msg.nome() );	
		Usuario usuario;
		String nomeUsuario,nomeAgente;
		String ip;
		nomeUsuario = msg.nome();
		nomeAgente = msg.mensagemAux();
		usuario = findUsuario(nomeUsuario);
		if(usuario != null)
			System.out.println ("Pegou "+ usuario.nome());
		else	
			System.out.println ("N�o Pegou usuario");
		return usuario;	
	}
	catch(Exception e) 
	{
		System.err.println ("\nErro no processaMensagemPegaAgente\n");
	}     
	return null;
	
}


/********************* processaMensagemPegaUsuarioAt *************************************/
public ObjetoEnviado processaMensagemPegaUsuarioAt(Mensagem msg)
{
	try
	{ 
		System.out.println("Entra em processaMensagemPegaUsuarioAt "+msg.nome() );		
		Usuario usuario;
		String nomeUsuario,nomeAgente;
		String ip;
		
		Integer valor;
		valor = Integer.decode(msg.mensagemAux());
		int i = (int)valor.intValue();
		
		usuario = findUsuarioAt(i);
		if(usuario != null)
			System.out.println ("Pegou "+ usuario.nome());
		else	
			System.out.println ("N�o Pegou usuario");
		return usuario;	
	}
	catch(Exception e) 
	{
		System.err.println ("\nErro no processaMensagemPegaAgente");
	}     
	return null;
}

/********************* removeUsuario *************************************/
public boolean removeUsuario(String nome)
{

	try
	{
		Usuario usuario;
		for(int i=0;i<m_listUsuarios.size();i++)
		{
			usuario = (Usuario)m_listUsuarios.elementAt(i);
			if (usuario.nome().equals(nome))
			{
				m_listUsuarios.removeElementAt(i);
				return true;
			}
		} 
		for(int i=0;i<m_listUsLogados.size();i++)
		{
			IP_Remote ipAtual = (IP_Remote)m_listUsLogados.elementAt(i);
			if ((ipAtual.usuario().nome()).equals(nome))
			{
			 	m_listUsLogados.removeElementAt(i);
				return true;
			}
			
		} 		
	}		
	catch(Exception e) 
	{
		System.err.println ("\nErro no removeUsuario");
	}     
	return false;

}
	

/********************* processaMensagemRemoveUsuario *************************************/
public ObjetoEnviado processaMensagemRemoveUsuario(Mensagem msg)
{
	try
	{ 
		System.out.println("Entra em processaMensagemRemoveUsuario "+msg.nome() );		
		Usuario usuario;
		String nomeUsuario,nomeAgente;
		String ip;
		msg.setMensagemRetorno(false);		
		if(!msg.nome().equalsIgnoreCase(nomeAdministrador))
		{
			System.out.println("Usu�rio n�o � o administrador"+ msg.nome());
			return msg;
		}	
		
		
		nomeUsuario = msg.mensagemAux();
		if (!removeUsuario(nomeUsuario))
		{
			return msg;
		}

	
	}
	catch(Exception e) 
	{
		System.err.println ("\nErro no processaMensagemPegaAgente\n");
		return msg;

	}     
	msg.setMensagemRetorno(true);
	return msg;
}


/*********************** processaConfiguracaoAgenteCompra **************************/	
	public Mensagem processaConfiguracaoAgenteCompra(Mensagem msg) throws IOException
	{
		String ip;
		Agente ag;
		
		try
		{ 
			System.out.println("Entra em processaConfiguracaoAgenteCompra "+msg.nome() );				
			Usuario usuarioLogado,usuario;
			String nomeUsuario,nomeAgente;
			msg.setMensagemRetorno(false);
			nomeUsuario = msg.nome();

			nomeAgente = Enviador.pegaParte(msg.mensagemAux(),0,',');//nomeAgente
			ip = msg.ip();
			usuarioLogado = findUsuarioLogado(ip);
			usuario = findUsuario(nomeUsuario);
			if (usuarioLogado != usuario)
			{
				return msg;//O usu�rio logado deve ser o mesmo que o nome do usu�rio que pediu.
			}
			//pega o agente de compra
			ag = usuario.findAgente(nomeAgente);

			System.out.println ("Usu�rio="+nomeUsuario+" Agente="+nomeAgente);
			if (ag == null)
			{
				return msg;
			}
			ag.ModificaConfiguracaoMensagem(msg.mensagemAux());
		}
		catch(Exception e) 
		{
			System.err.println ("\nErro no processaConfiguracaoAgenteCompra\n");
		}     
		msg.setMensagemRetorno(true);
		return msg;
	}

/*********************** processaConfiguracaoAgenteVenda **************************/	
	public Mensagem processaConfiguracaoAgenteVenda(Mensagem msg) throws IOException
	{
		String ip;
		Agente ag;
		
		try
		{ 
			System.out.println("Entra em processaConfiguracaoAgenteVenda "+ msg.nome()+" "+msg.mensagemAux() );				
			Usuario usuarioLogado,usuario;
			String nomeUsuario,nomeAgente;
			msg.setMensagemRetorno(false);
			nomeUsuario = msg.nome();

			nomeAgente = Enviador.pegaParte(msg.mensagemAux(),0,',');
			ip = msg.ip();
			usuarioLogado = findUsuarioLogado(ip);
			usuario = findUsuario(nomeUsuario);
			if (usuarioLogado != usuario)
			{
				return msg;//O usu�rio logado deve ser o mesmo que o nome do usu�rio que pediu.
			}
			//pega o agente de venda
			ag = usuario.findAgente(nomeAgente);

			if (ag == null)
			{
				return msg;
			}
			ag.ModificaConfiguracaoMensagem(msg.mensagemAux());
		}
		catch(Exception e) 
		{
			System.err.println ("\nErro no processaConfiguracaoAgenteVenda\n");
		}     
		msg.setMensagemRetorno(true);
		return msg;
	}
	
/************ processaConfiguracaoAgenteLeiloeiro ************/
	public Mensagem processaConfiguracaoAgenteLeiloeiro(Mensagem msg) throws IOException
	{
		String ip;
		Agente ag;
		
		try
		{ 
			System.out.println("Entra em processaConfiguracaoAgenteLeiloeiro "+ msg.nome()+" "+msg.mensagemAux() );				
			Usuario usuarioLogado,usuario;
			String nomeUsuario,nomeAgente;
			msg.setMensagemRetorno(false);
			nomeUsuario = msg.nome();

			nomeAgente = Enviador.pegaParte(msg.mensagemAux(),0,',');
			ip = msg.ip();
			usuarioLogado = findUsuarioLogado(ip);
			usuario = findUsuario(nomeUsuario);
			if (usuarioLogado != usuario)
			{
				System.out.println(usuarioLogado +"  "+usuario);
				return msg;//O usu�rio logado deve ser o mesmo que o nome do usu�rio que pediu.
			}
			//pega o agente leiloeiro
			ag = usuario.findAgente(nomeAgente);

			if (ag == null)
			{
				return msg;
			}
			ag.ModificaConfiguracaoMensagem(msg.mensagemAux());
		}
		catch(Exception e) 
		{
			System.err.println ("\nErro no processaConfiguracaoAgenteVenda\n");
		}     
		msg.setMensagemRetorno(true);
		return msg;
	}

/***************** processaTrabalhar *************************/
	public Mensagem processaTrabalhar( Mensagem msg) throws IOException
	{
		String ip;
		Agente ag;

		try
		{ 
			System.out.println("Entra em processaTrabalhar "+msg.nome() );							
			Usuario usuario;
			String nomeUsuario,nomeAgente;
			msg.setMensagemRetorno(false);					
			nomeUsuario = msg.nome();

			nomeAgente = Enviador.pegaParte(msg.mensagemAux(),0,',');
			if (m_blogado == false)
			{
				return msg;
			}

			usuario = findUsuario(nomeUsuario);
			//pega o agente
			ag = usuario.findAgente(nomeAgente);

			if (ag == null)
			{
				System.out.println("N�o conseguiu fazer o agente trabalhar: "+msg.nome() );							
				return msg;	
			}
			
			ag.setTrabalhando(true);
			//Prepara o Agente para comecar a trabalhar.
			if (ag.jaRodou() == false)
			{
				Thread t = new Thread (ag);			
				t.start();//come�ou buscar... 
			}
			msg.setNome(ag.nome());
			msg.setMensagemRetorno(true);
			return msg;
		}
		catch(Exception e) 
		{
			System.err.println ("\nErro no processaBusca\n");
		}     
		return msg;

	}
	
/***************** precessaParaTrabalhar *************************/	
	public Mensagem precessaParaTrabalhar( Mensagem msg) throws IOException
	{
		String ip;
		Agente ag;

		try
		{ 
			System.out.println("Entra em processaParaTrabalhar "+msg.nome() );
			Usuario usuarioLogado,usuario;
			String nomeUsuario,nomeAgente;
			msg.setMensagemRetorno(false);					
			nomeUsuario = msg.nome();

			nomeAgente = Enviador.pegaParte(msg.mensagemAux(),0,',');
			if (m_blogado == false)
			{
				return msg;//O usu�rio logado deve ser o mesmo que o nome do usu�rio que pediu.
			}
			
			usuario = findUsuario(nomeUsuario);
			
			//pega o agente
			ag = usuario.findAgente(nomeAgente);

			System.out.println ("Usu�rio="+nomeUsuario+" Agente="+nomeAgente);
			if (ag == null)
			{
				return msg;
			}
			
			ag.setTrabalhando(false);
			//Prepara o Agente para comecar a trabalhar.
			
			msg.setNome(ag.nome());
			msg.setMensagemRetorno(true);
			return msg;
		}
		catch(Exception e) 
		{
			System.err.println ("\nErro no processaTrabalhar\n");
		}     
		return msg;

	}


/********************* processaMensagemRemoveAgente **************/
	public Mensagem processaMensagemRemoveAgente( Mensagem msg) throws IOException
	{
		String ip;
		Agente ag;

		try
		{ 
			msg.setMensagemRetorno(false);
			System.out.println("Entra em processaMensagemRemoveAgente "+msg.nome() );									
			Usuario usuarioLogado,usuario;
			String nomeUsuario,nomeAgente;
					
			nomeUsuario = msg.nome();

			nomeAgente = Enviador.pegaParte(msg.mensagemAux(),0,',');

			if (m_blogado == false)
			{		
				return msg;//O usu�rio logado deve ser o mesmo que o nome do usu�rio que pediu.				
			}


			usuario = findUsuario(nomeUsuario);
			
			//pega o agente
			ag = usuario.findAgente(nomeAgente);


			System.out.println ("Usu�rio="+nomeUsuario+" Agente="+nomeAgente);
			if(ag == null)
				return msg;

			retiraAgenteRegistro(ag);
			
			msg.setMensagemRetorno(true);
			return msg;
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no processaMensagemRemoveAgente\n");
		}     
		return msg;
	}



/********************* processaMensagem *************************************/
	public synchronized ObjetoEnviado processaMensagem(Mensagem msg) throws IOException
	{
	
		try
		{
			String nome,sMensagem,sMensagemAux;
			
			boolean bOk = false;
			String ip;
			nome = msg.nome();
			sMensagem = msg.mensagem();
			sMensagemAux = msg.mensagemAux();
			
			
			Usuario usuario;
			usuario = findUsuario(msg.nome());
			m_blogado = false;
			if(usuario == null)
			     System.out.println("Participante nao existe "+ msg.nome()); 
			else 
			{
//			    System.out.println("Participante encontrado "+ msg.nome() ); 
				ip = msg.ip();
	 			Usuario usuarioLogado = findUsuarioLogado(ip);

				System.out.println(usuarioLogado+ "  "+ usuario.nome() ); 
				m_blogado = true;
						
			}

		    System.out.println("Nome="+msg.nome()+" Mensagem="+msg.mensagem()+" MensagemAux="+msg.mensagemAux() + " IP="+msg.ip());

			if(sMensagem.equalsIgnoreCase("login"))
			{
				return processaMensagemLogin( msg);
			}
			else if(sMensagem.equalsIgnoreCase("logout"))
			{
				return processaMensagemLogout( msg);
			}
			else if(sMensagem.equalsIgnoreCase("NovoUsuario"))
			{
				return processaMensagemNovoUsuario(msg);
			}
			else if(sMensagem.equalsIgnoreCase("RemoveUsuario"))
			{
				processaMensagemRemoveUsuario( msg);
			}
			else if(sMensagem.equalsIgnoreCase("pegaUsuarioAt"))
			{
				return processaMensagemPegaUsuarioAt( msg);
			}
			else if(sMensagem.equalsIgnoreCase("PegaUsuario"))
			{
				return processaMensagemPegaUsuario(msg);
			}
			else if(sMensagem.equalsIgnoreCase("salvar"))
			{
				return processaMensagemSalvar( msg);
			}
			else if(sMensagem.equalsIgnoreCase("abrir"))
			{
				return processaMensagemAbrir( msg);
			}
			else if(sMensagem.equalsIgnoreCase("acessoprivado"))
			{
				return processaAcessoPrivado(msg);
			}
			else if (sMensagem.equalsIgnoreCase("criaagente"))
			{
			      return processaMensagemCriaAgente(msg);
			}
			else if(sMensagem.equalsIgnoreCase("ConfiguracaoAgenteCompra"))
			{
				return processaConfiguracaoAgenteCompra(msg);
			}
			else if(sMensagem.equalsIgnoreCase("ConfiguracaoAgenteVenda"))
			{
				return processaConfiguracaoAgenteVenda(msg);
			}
			else if(sMensagem.equalsIgnoreCase("ConfiguracaoAgenteLeiloeiro"))
			{
				return processaConfiguracaoAgenteLeiloeiro(msg);
			}
			
			else if(sMensagem.equalsIgnoreCase("trabalhar"))
			{
				processaTrabalhar( msg);
			}
			else if(sMensagem.equalsIgnoreCase("paraTrabalhar"))
			{
				precessaParaTrabalhar( msg);
			}
			else if(sMensagem.equalsIgnoreCase("RemoveAgente"))
			{
				processaMensagemRemoveAgente( msg);
			}
			else
			{
				System.out.println("\nMensagem n�o reconhecida "+msg.mensagem());			
			}
			
//			else if (sMensagem.equalsIgnoreCase("busca"))
//			{
//				return processaBusca(msg);
//			}
//			else if(sMensagem.equalsIgnoreCase("ReplyBuscaProdutos"))
//			{
//				processaReplyBusca(msg);
//			}			
			msg.setMensagemRetorno(true);
		}//try
		catch (Exception e) 
		{
			System.err.println ("\nErro no processa Mensagem "+e);
		}     
		return msg;
	}
	//		Mensagem processaMensagem
	

/********************* processaMensagemAgente *************************************/
	public synchronized ObjetoEnviado processaMensagemAgente(Mensagem msg) throws IOException
	{
		try
		{
//			msg.setMensagemRetorno(false);
			Mensagem mensagem = new Mensagem("","");
			Agente ag = findAgente(msg.destino());
			if (ag != null)
			{
				System.out.println (" Recebi a mensagem"+msg.mensagem());
			
				mensagem = ag.recebeMensagem(msg);
//				mensagem.setMensagemRetorno(true);
				return mensagem;
			}
			else
			{//podem ser v�rios destinos.
				int i=0;
				System.out.println(msg.mensagem()+"mensagem para v�rios agentes:"+msg.destino());
				String sAgente = Enviador.pegaParte(msg.destino(),i,',');
				boolean achou = false;
				while (!sAgente.equals("") )
				{
					mensagem = msg;
					ag = findAgente(sAgente);
					if (ag != null)
					{
						achou = true;
						ag.setMensagem(mensagem);
					}
					i++;
					sAgente = Enviador.pegaParte(msg.destino(),i,',');
				}
				if (!achou)
				{
					System.out.println("*****************  \nN�o achou nenhum agente para "+mensagem.mensagem()+"****"+msg.destino()+"******"+mensagem.mensagemAux()+"*******"); 
				}
			}
		}//try
		catch (Exception e) 
		{
			System.err.println ("\nErro no processa Mensagem Roma"+e);
		}

		return msg;
	}
	
	
}//da classe
