/**classe EstrategiaPerfilConcorrente**/

import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.VetorCaracteristica;
import ClassesGeral.Caracteristica;

/**
� uma estrat�gia.

Nessa estrat�gia comprasse os perfis dos concorrentes e verifica 
o tempo restante para o t�rmino do leil�o.

Os oponetes serao divididos de duas formas relacionadas. 
A primeira e o numero de estrelas e a outra e a quantidade de ofertas.
Estrelas : informacao vinda do leilao.  quanto mais estrelas melhor o oponente, poucas estrelas ele n'ao 'e confi[avel
Numero oferta : Se tiver muitas quer muito o produto.

Devemos considerar se o oponete esta vencendo o leilao.

Procedimento:
muitas estrelas - muitas ofertas - atue pouco, mas fazendo uma oferta grande para ver a disposicao
muitas estrelas - poucas ofertas -  atue muito com ofertas simples
poucas estrelas - muitas oferta - especulador, atue pouco com ofertas minimas
poucas estrelas - poucas ofertas - atue pouco com ofertas simples.
**/

public class EstrategiaVendaPerfilConcorrente extends Estrategia
{
	Vector vetorUsuariosOfertas;//o vetor com objetos da classe acima.
	Vector listItensOfertas;
		
	public EstrategiaVendaPerfilConcorrente(AgenteVenda ag)
	{
		super(ag);
		try
		{	
			vetorUsuariosOfertas = new Vector();
			listItensOfertas = new Vector();
			
			ag.vetorCaracteristica.setValorCarac("fatorFechamento","3");
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro na Cria��o do EstrategiaCompraPerfilConcorrente" );
		}
	}
	

	/****************************** writeObject **********************************/
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{
		
			int i;		
			out.writeInt(vetorUsuariosOfertas.size());
			for(i=0;i<vetorUsuariosOfertas.size();i++)
			{
				out.writeObject(vetorUsuariosOfertas.elementAt(i));
			}
			out.writeInt(listItensOfertas.size());
			for(i=0;i<listItensOfertas.size();i++)
			{
				out.writeObject(listItensOfertas.elementAt(i));
			}


			out.flush();

		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write da EstrategiaCompraPerfilConcorrente" );
		}
	}

/****************************** readObject **********************************/
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			
			vetorUsuariosOfertas = new Vector();		
			int i,size = in.readInt();
			for(i=0;i<size;i++)
			{
				vetorUsuariosOfertas.addElement(in.readObject());
			}
			
			size = in.readInt();
			listItensOfertas = new Vector();
			for(i=0;i<size;i++)
			{
				listItensOfertas.addElement(in.readObject());
			}
		}
		catch(IOException e)
		{
			System.err.println(e+" Erro no read da EstrategiaCompraPerfilConcorrente" );
		}
	}
	
		
/****************** findVetorUsuariosOfertas *********************/	
	private VetorOferta findVetorUsuariosOfertas(String nomeConcorrente)
	{
		try
		{
			VetorOferta vetorOferta;
			for(int i=0;i<vetorUsuariosOfertas.size();i++)
			{
				vetorOferta = (VetorOferta)vetorUsuariosOfertas.elementAt(i);
				if(nomeConcorrente.equals(vetorOferta.vetorVetorCaracUsu.getValorCarac("nome")))
					return vetorOferta;
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no read da findVetorUsuariosOfertas" );
		}
		return null;
	}

	
/****************** recebeReplyBuscaParticipanteIndividual *********************/	
//vai modificar as informa��es do perfil de um usu�rio espec�fico.   
	private void recebeReplyBuscaParticipanteIndividual(Mensagem msg)
	{
		String nomeConcorrente = Enviador.pegaParte(msg.mensagemAux(),0,',');
		VetorOferta vetorOferta;
		vetorOferta = findVetorUsuariosOfertas(nomeConcorrente);
		if (vetorOferta == null)
		{
			vetorOferta = new VetorOferta();
			vetorUsuariosOfertas.addElement(vetorOferta);//cada vetor oferta 'e relativa a um usuario

		}
		vetorOferta.vetorVetorCaracUsu.setCaracteristicas(msg.mensagemAux());

		ag().executaEstrategia();
	}

/************************** findMaiorOferta ********************/
//acha a maior oferta ao item.
	public Oferta findMaiorOferta(Item it)
	{
		String nome = null;
		Oferta oferta=null,ofertaMelhor=null;		
		try
		{
		
			String codProdAtual,codProd = it.vetorCaracteristica.getValorCarac("codigo");
					
			VetorOferta vetorOferta = null;
			double valorOferta=0,valorOfertaAtual=0;
			for(int i=0;i<vetorUsuariosOfertas.size();i++)
			{

				vetorOferta = (VetorOferta)vetorUsuariosOfertas.elementAt(i);
				oferta = (Oferta)vetorOferta.ofertas.elementAt(vetorOferta.ofertas.size()-1);//pega a ultima oferta desse cara

				codProdAtual = oferta.codProd();
				
				if (codProdAtual.equals(codProd))
				{
					Double valor = Double.valueOf(oferta.valorOferta());
					valorOfertaAtual = (double)valor.doubleValue();
					if(valorOfertaAtual > valorOferta)
	 				{
	 					valorOferta = valorOfertaAtual;
	 					ofertaMelhor = oferta;
	 				}
				}
				
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no findVetorMaiorOferta da Estrat'egiaCompraPerfilConcorente");
		}
		return ofertaMelhor;
	}
	
	
	
/************************** findNumeroOfertas ********************/
//retorna o n�mero de ofertas que o usu�rio j� deu para esse item
	public int findNumeroOfertas(String nomeConcorrente,Item it)
	{
		String nome = null;
		Oferta oferta=null,ofertaMelhor=null;		
		try
		{
			int numeroOfertas=0;		
			String codProdAtual,codProd = it.vetorCaracteristica.getValorCarac("codigo");
					
			VetorOferta vetorOferta = null;
			double valorOferta=0,valorOfertaAtual=0;
			vetorOferta = findVetorUsuariosOfertas(nomeConcorrente);
			
			if (vetorOferta != null)
			{
				for(int i=0;i<vetorOferta.ofertas.size();i++)
				{
					oferta = (Oferta)vetorOferta.ofertas.elementAt(i);//pega a ultima oferta desse cara
	
					if (codProd.equals(oferta.codProd()))
						numeroOfertas++;
				}
			}
			return numeroOfertas;
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no findVetorMaiorOferta da Estrat'egiaCompraPerfilConcorente");
		}
		return 0;
	
		
	}
	
	
	
			
/*********************** analisaSituacaoItemIndividual ***********************/	
	public double analisaSituacaoItemIndividual(Item it)
	{
		double avaliacao=0;
		AgenteVenda ag = (AgenteVenda)ag();
		try
		{
			Oferta oferta;
			
			
			if (it.vendido())
			{
				ag.appendHistoria("Produto J� vendido"+it.nome()+" para "+it.vetorCaracteristica.getValorCarac("NomeVencedor")+
								"por:"+it.vetorCaracteristica.getValorCarac("ValorVencedor")+
								" com o email:"+it.vetorCaracteristica.getValorCarac("EmailVencedor"));
			
			}				
			
			int numeroOfertasItem = it.vetorOfertas.size();
			
			
			
			
//			System.out.println("nome:"+ag.nome()+"analisaSituacaoItemIndividual nomeProd:"+it.nome());
			if(numeroOfertasItem == 0)
				return 0;
			oferta = (Oferta)it.vetorOfertas.elementAt(numeroOfertasItem - 1);	
			if(oferta == null)
					return 0 ;//ainda n�o houve ofertas
				
			double tempoLeilao = it.tempoLeilao();

			double prazo = ag.vetorCaracteristica.getValorCaracDouble("Prazo");
			
			double valorReserva = it.vetorCaracteristica.getValorCaracDouble("valorReservaTotal");
			if(valorReserva==0)
				valorReserva = ag.vetorCaracteristica.getValorCaracDouble("valorReserva");

			double valorOferta = Enviador.pegaParteDouble(oferta.valorOferta(),0,',');
			
			prazo = prazo/tempoLeilao;
			
			valorOferta = valorOferta/valorReserva;
			
//			System.out.println("prazo+valorOferta:"+ (prazo+valorOferta));
			return prazo+valorOferta;
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no analisaSituacaoItemIndividual da EstrategiaCompraPerfilConcorrente do Agente de compra :"+ag().nome());
		}
		return avaliacao;
	}


	/*********************** verificaFechamentoItem ***********************/	
	public boolean verificaFechamentoItem(Item it)
	{
		try
		{
			AgenteVenda ag = (AgenteVenda)ag();
			Oferta oferta;
			
//			Pagina pag = ag.findPagina(it.pagina().nome());
//			if (pag == null)
//			{
//				System.err.println("P�gina n�o existe no item:"+it.vetorCaracteristica.getValorCarac("codigo")+"  "+it.vetorCaracteristica.getValorCarac("nomeDono"));
//				return false;
//			}

			int numeroOfertasItem = it.vetorOfertas.size();
			oferta = (Oferta)it.vetorOfertas.elementAt(numeroOfertasItem - 1);	
			if(oferta == null)
					return false ;//ainda n�o houve ofertas

//			System.out.println("nome:"+ag.nome()+" verificaFechamentoItem");
			//somente se o cara for leiloeiro que pode chamar retornar um valor diferente de 0
			int pode = it.vetorCaracteristica.getValorCaracInteiro("podeFechar");
			if(pode > it.vetorCaracteristica.getValorCaracInteiro("quantidadeVendedores"))
				ag.fechaLeilao(it);			
			
			int numeroEstrelas = oferta.numeroEstrelas();
			
			double prazo = ag.vetorCaracteristica.getValorCaracDouble("Prazo");//tempo total que o agente deve trabalhar

			double tempoLeilao = it.tempoLeilao();

			int numeroOfertasMinimo = ag.vetorCaracteristica.getValorCaracInteiro("numeroOfertasMinimo");
						
			double fatorEstrelas = ag.vetorCaracteristica.getValorCaracDouble("fatorNumeroEstrelas");
			
			double fatorValorReserva = ag.vetorCaracteristica.getValorCaracDouble("fatorValorReserva");
			
			double fatorPrazo = ag.vetorCaracteristica.getValorCaracDouble("fatorPrazo");
			
			double nivelConcorrencia  = ag.vetorCaracteristica.getValorCaracDouble("nivelConcorrencia");
			
			double valorReserva = it.vetorCaracteristica.getValorCaracDouble("valorReservaTotal");
			if(valorReserva == 0)
				valorReserva = ag.vetorCaracteristica.getValorCaracDouble("valorReserva");

			double valorOferta = Enviador.pegaParteDouble(oferta.valorOferta(),0,',');
//			System.out.println(ag().nome()+" numeroOfertasMinimo:"+numeroOfertasMinimo+" numeroOfertas:"+numeroOfertasItem+" valorReserva:"+valorReserva+ "numeroEstrelas:"+numeroEstrelas);
//			System.out.println("valorOferta:"+valorOferta+" tempoLeilao:"+tempoLeilao+" prazo:"+prazo);
//			System.out.println("numeroOfertasItem:"+numeroOfertasItem+" prazo:"+prazo+ " nivelConcorrencia:"+nivelConcorrencia);			
			
			if( (numeroOfertasMinimo>numeroOfertasItem || valorOferta<(valorReserva+valorReserva*fatorValorReserva) )
			&& ( numeroEstrelas < fatorEstrelas || valorOferta<(valorReserva+valorReserva*fatorValorReserva/2) )
			& (tempoLeilao<(prazo*fatorPrazo-prazo)) || valorOferta<(valorReserva+valorReserva*fatorValorReserva/5) )
				return false;

			if((numeroOfertasItem/prazo)< nivelConcorrencia && valorOferta<(valorReserva*valorReserva))
				return false;//se a quantidade de ofertas por minuto for maior que a pedida ent�o o valor de reserva deve ser o dobro
			//pede para fechar
			

			
			ag.fechaLeilao(it);
			
/*
			if (tempoTrabalho>=tempoOferta && valorOferta>(valorAtual+menorDiferenca) )//se o tempo que j� foi trabalhado at� o momento	for maior que o tempo ideal da oferta, ent�o pode fazer a oferta.		
			{
				buf.append("Vai efetuar a oferta sobre produto:"+it.vetorCaracteristica.getValorCarac("codigo"));
				buf.append(", o valor estimado por mim nesse momento �:"+String.valueOf(valorOferta)+", e o valor minimo para oferta �:"+String.valueOf(valorAtual+menorDiferenca)); 
				buf.append(".  O momento ideal para mim �:"+String.valueOf(tempoOferta)+", e o tempo de trabalho at� agora �:"+String.valueOf(tempoTrabalho));
				ag.appendHistoria(buf.toString());
//				ag.fechaLeilao(it,valorOferta);	
			}
			else
			{
				System.out.println(ag.nome()+" Achou melhor n�o efetuar a oferta sobre produto:"+it.vetorCaracteristica.getValorCarac("codigo"));
			
				buf.append("Achei melhor n�o efetuar a oferta sobre produto:"+it.vetorCaracteristica.getValorCarac("codigo"));
				buf.append(", o valor estimado por mim nesse momento seria:"+String.valueOf(valorOferta)+", e o valor minimo para oferta �:"+String.valueOf(valorAtual+menorDiferenca)); 
				buf.append(".  O momento ideal para mim seria:"+String.valueOf(tempoOferta)+", e o tempo de trabalho at� agora �:"+String.valueOf(tempoTrabalho));
				ag.appendHistoria(buf.toString());
			}*/
		}
		catch(Exception e)
		{
			System.out.println(e+" Erro no verificaFechamentoItem da EstrategiaCompraPerfilConcorrente do agente " + ag().nome());

		}
		return false;	
	}
/************************** analisaSituacaoItens *****************************/	
	public synchronized void analisaSituacaoItens()
	{//aqui que vem o racioc�nio
		try
		{
				
			AgenteVenda ag = (AgenteVenda)ag();	
			Item it= null,itemMelhor=null;
			double avaliacaoAtual,avaliacaoMelhor = 0;

			//for para analisar individualmente todos os itens. depois faz a avaliacao geral.
			for(int i=0;i<ag.listItens.size();i++)
			{
//				System.out.println(ag.nome()+" i:"+i+" Size:"+ag.listItens.size());
				it = (Item)ag.listItens.elementAt(i);

				if(it.vendido())
					continue;
										
				avaliacaoAtual = this.analisaSituacaoItemIndividual(it);
				System.out.println(avaliacaoAtual);
				if(avaliacaoAtual > avaliacaoMelhor)			
					itemMelhor = it;
			}
			if(itemMelhor != null)
				verificaFechamentoItem(itemMelhor);
	
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no analisaSituacaoItens da EstrategiaCompraPerfilConcorrente do agene "+ag().nome());
		}

	}

//agora analisa para ver sobre qual leil�o vai realizar a oferta.  Essa an�lise ser� feita baseada na avalia��o do produto na atualidade.
	/************************** recebeMensagem *****************************/	
	public Mensagem recebeMensagem(Mensagem msg)
	{
		Mensagem mensagem = new Mensagem("","");
		try
		{
		
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no comeca da recebeMensagem EstrategiaCompraPerfilConcorrente do "+ag().nome());
		}
		return mensagem;
	}
}

/*
A estrategia, possui uma lista de VetorOfertas, que indica cada usu�rio e todas as suas ofertas.
Cada VetorOfertas todas as ofertas efetuadas pelo usu�rio aos produtos que o agente est� relacionado

 analisaSitua��o
		verificaRestricaoConfiguracaoOferta
		analisaSituacaoItemIndividual para cada item
			achaMomento
			achaValor
			verificaOponentes
	
		se tiver algum item 
			realizaOfertaItem
				modificaValorOfertaPerfilOponentes
				realiza a oferta mesmo.


*/