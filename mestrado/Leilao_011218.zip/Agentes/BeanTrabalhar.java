//import java.io.*;
//import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;


public class BeanTrabalhar extends BeanGeral
{
	private String trabalhar = "";
	private String mensagem = "";	
	private String mensagemAux = "";
	

	public void setMensagem(String m)
	{
		mensagem = m;
	}
	public String getMensagem()
	{
		return mensagem;
	}

	public void setMensagemAux(String m)
	{
		mensagemAux = m;
	}
	public String getMensagemAux()
	{
		return mensagemAux;
	}
	
	public boolean processa()
	{
		System.out.println("Procesando BeanTrabalhar" );
		Mensagem Msg = new Mensagem("","");
		try
		{
			InetAddress Inet = InetAddress.getLocalHost();
			Msg = new Mensagem(getNomeUsuario(),Inet.getHostAddress());

			//AINDA n�o estou passando o password.
			Msg.setMensagem(mensagem);
			Msg.setReply(false);
			Msg.setMensagemAux(mensagemAux);
			Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,Msg);
			Msg = (Mensagem)Recebedor.RecebeMensagem(Enviador.PortaRecebimentoClienteGerente);			
		
			
			return Msg.mensagemRetorno();
		}
		catch (UnknownHostException e) 
		{
				System.err.println("Trying to connect to unknown host: " + e);
		}
		catch (Exception e) 
		{
			System.err.println("Erro o processa do BeanTrataMensagem Exception:  " + e);
		}
		return true;		
		
	}
}
