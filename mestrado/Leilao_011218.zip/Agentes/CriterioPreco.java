//import java.lang.*;
import java.io.*;

public class CriterioPreco extends Criterio 
{
	private float precoMax,precoMin;
	private float preco;

	
	
	public CriterioPreco(float p)
	{
		super("Menor pre�o entre ");
		precoMin = (float)0;
		precoMax = (float)500;
		preco = p;
	};
		
/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
	
			out.writeFloat(precoMax);
			out.writeFloat(precoMin);
			out.writeFloat(preco);			

			out.flush();
		}	
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do CriterioPreco" );
		}			
	}
	
/****************************** readObject **********************************/		
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			precoMax =  in.readFloat();
			precoMin =  in.readFloat();
			preco 	 = 	in.readFloat();						
		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read do CriterioPreco" );
		 }
	 }
		

	public void setPrecoMax(float p)
	{
		precoMax = p;
	}
	
	public float precoMax()
	{
		return precoMax;
	}

	public void setPrecoMin(float p)
	{
		precoMin = p;
	}
	
	public float precoMin()
	{
		return precoMin;
	}
	

	public Double CalculaCriterio(Item it) 
	{
		Double avaliacao = new Double(1);	  
	
		try
		{
			if(it == null)
				return new Double(0);

			double precoItem = it.vetorCaracteristica.getValorCaracDouble("valorAtual");
			
			if(precoItem < precoMin || precoItem > precoMax)
				avaliacao = new Double(0);
			else		
			if((precoMax - precoMin)>0)
				avaliacao = new Double(1 - ((precoItem - precoMin) / (precoMax - precoMin)));
			System.out.println(precoMax+" "+precoMin+" "+precoItem+" "+avaliacao);
		}
		catch(Exception e)	
		{ 
			System.err.println(e+" Erro no Calcula Crit�rio");
		}
		return avaliacao;
	}
}
