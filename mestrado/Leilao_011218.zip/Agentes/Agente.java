/**classe Abstrata Agente**/
	
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.InetAddress;

//jat
import Abstract.*;
import KQMLLayer.*;
import RouterLayer.AgentClient.*;
//jat


import ClassesGeral.ObjetoEnviado;
import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.Recebedor;
import ClassesGeral.VetorCaracteristica;
import ClassesGeral.Caracteristica;


/**
* Classe abstrate de Agentes.  Encapsula as principais funcionalidades dos agentes
*/
abstract public class Agente extends ObjetoEnviado implements Runnable
{	
	public Agente_Delegate agDelegate,agDelegate_Ping,agDelegate_Pong;
	private String m_nomeUsuario;
	private String m_email;
	protected String m_nomeProduto;
	private String m_nomeUsuarioPagina;
//	private int numMaxItens;//n�mero m�ximo de itens que o agente ter�
	private boolean m_jaRodou;//se j� come�ou a rodar
	private boolean m_jaBuscou;//verifica se j� realizou a busca depois de ser criado e come�ar a trabalhar
	private int m_autonomia;//(0,"N�o configurado");(1,"Total");(2,"Parcial");(3,"Nenhuma")	
	private int m_estagio;
	private int	m_vezes;
	protected Estrategia m_estrategia;
	private Mensagem m_mensagem;
	private boolean m_avisoRelogio;
	private String m_tipo;
	protected boolean m_trabalhando;
	private String m_stringErro;
	protected Vector 	listCriterios;
	protected Vector 	listRestricoes;
	protected Vector listPaginas;
	private StringBuffer m_historia;//cont�m a hist�ria do agentes	
	public Vector listItens;
	VetorCaracteristica vetorCaracteristica;
	
	
	
/**
* Construtor.  O construtor por enquanto j� est� dando a senha e login do lokau
*/
	public Agente(String usu,String n)
	{
		super(n);
		m_nomeUsuario = usu;
//		numMaxItens = 5;
		
		m_estagio = 0;
		m_vezes = 0;
		m_estrategia = null;			
		m_mensagem = null;
		m_avisoRelogio = false;
		
		m_tipo = "sem tipo";
		m_trabalhando = false;
//		m_loginLokau = "romalopes";
//		m_senhaLokau = "joana";
		listCriterios = new Vector();
		listRestricoes = new Vector();
		listPaginas = new Vector();
//		m_listItensVendidos = new Vector();
		m_historia = new StringBuffer();
		listItens = new Vector();
		m_jaRodou = false;
		m_jaBuscou = false;
		m_autonomia = 0;
		setNomeUsuarioPagina(nomeUsuario() + nome());
		vetorCaracteristica = new VetorCaracteristica();

/*		try
		{
			System.out.println("ComecandoAgente");
		    agDelegate_Ping = new Agente_Delegate(this.nome(), "z", Agente_Delegate.localhost, Enviador.PortaJatLite++);    //create pingA
			agDelegate_Ping.setAgente(this);
		    agDelegate_Ping.start();    
		    agDelegate_Pong = new Agente_Delegate("Segundo"+this.nome(), "z", Agente_Delegate.localhost, Enviador.PortaJatLite++);    //create pingA
			agDelegate_Ping.setAgente(this);
		    agDelegate_Pong.start();    

		    agDelegate_Ping.sendKQMLMessage("(tell :sender " + agDelegate_Ping.getName() + " :receiver " +
		                          agDelegate_Pong.getName() + " :content (Beijo))");    //or sendMessage
		    agDelegate_Ping.sleep(6000);

			System.out.println("Saindo");
			
			agDelegate_Ping.disconnect(); //disconnect from Router
			agDelegate_Ping.unregister(); //unregister from Router
			agDelegate_Ping.endAction(); //clean up and stop agent action

			agDelegate_Pong.disconnect(); //disconnect from Router
			agDelegate_Pong.unregister(); //unregister from Router
			agDelegate_Pong.endAction(); //clean up and stop agent action
			
			
		}	
		
		
		catch(Exception e)
		{
			return;
		}
*/		
		
	}
	
	public void finalize()
	{
		try
		{
			agDelegate.disconnect(); //disconnect from Router
			agDelegate.unregister(); //unregister from Router
			agDelegate.endAction(); //clean up and stop agent action
			agDelegate = null;
		}	
		catch(Exception e)
		{
			return;
		}
	}
	
	public void rodaDelegate()
	{
		try
		{
//			System.out.println("ComecandoAgente");
//		    agDelegate = new Agente_Delegate(this.nome(), "z", Agente_Delegate.localhost, Enviador.PortaJatLite++);    //create pingA
//		    agDelegate.start();    
	
		}	
		catch(Exception e)
		{
			return;
		}
		
	}
	
	
	public void init(){}
	
	
/****************************** writeObject **********************************/
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
			out.writeObject(m_email);	
			out.writeObject(m_nomeProduto);	
			out.writeObject(m_tipo);	
			out.writeBoolean(m_trabalhando);	
			out.writeObject(m_stringErro);
//			out.writeInt(numMaxItens);	
			String s = m_historia.toString();
			out.writeObject(s);
			out.writeBoolean(m_jaRodou);
			out.writeBoolean(m_jaBuscou);
			out.writeInt(m_autonomia);
			out.writeObject(m_nomeUsuarioPagina);
			
			out.writeInt(m_estagio);
			out.writeInt(m_vezes);
			
			out.writeObject(m_estrategia);			
//			out.writeObject(m_mensagem);
//			out.writeBooelan(m_avisoRelogio);
			
			out.writeInt(listCriterios.size());	
			int i;
			for(i=0;i<listCriterios.size();i++)
				out.writeObject(listCriterios.elementAt(i));	
			
			out.writeInt(listRestricoes.size());	
			for(i=0;i<listRestricoes.size();i++)
				out.writeObject(listRestricoes.elementAt(i));	
			
			out.writeInt(listPaginas.size());	
			for(i=0;i<listPaginas.size();i++)
				out.writeObject(listPaginas.elementAt(i));
	
			out.writeInt(listItens.size());	
			for(i=0;i<listItens.size();i++)
				out.writeObject(listItens.elementAt(i));

			out.writeInt(vetorCaracteristica.size());
			for(i=0;i<vetorCaracteristica.size();i++)
				out.writeObject(vetorCaracteristica.elementAt(i));	

/*			out.writeInt(m_listItensVendidos.size());	
			for(i=0;i<m_listItensVendidos.size();i++)
				out.writeObject(m_listItensVendidos.elementAt(i));
*/
			out.flush();
		}	
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do Agente" );
		}			
	}
	
/****************************** readObject **********************************/
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_email = (String)in.readObject();
			m_nomeProduto = (String)in.readObject();
			m_tipo = (String)in.readObject();	
			m_trabalhando = in.readBoolean();
			
			m_stringErro = (String)in.readObject();			
			
//			numMaxItens = in.readInt();	
			m_historia = new StringBuffer();
			m_historia.append((String)in.readObject());
			m_jaRodou = in.readBoolean();
			m_jaBuscou = in.readBoolean();
			m_autonomia = in.readInt();
			m_nomeUsuarioPagina = (String)in.readObject();
			m_estagio = in.readInt();
			m_vezes = in.readInt();
			m_estrategia = (Estrategia)in.readObject();			
//			m_mensagem = (Mensagem)in.readObject();
//			m_avisoRelogio = in.readBooelan;
			
			listCriterios = new Vector();
			listCriterios.removeAllElements();
			
			int i,size = in.readInt();
			for(i=0;i<size;i++)
				listCriterios.addElement(in.readObject());	
			
			listRestricoes = new Vector();
			listRestricoes.removeAllElements();
			size = in.readInt();
			for(i=0;i<size;i++)
				listRestricoes.addElement(in.readObject());	
			
			listPaginas = new Vector();
			listPaginas.removeAllElements();
			size = in.readInt();
			for(i=0;i<size;i++)
				listPaginas.addElement(in.readObject());	
				
			listItens = new Vector();
			listItens.removeAllElements();
			size = in.readInt();
			for(i=0;i<size;i++)
				listItens.addElement(in.readObject());	

			vetorCaracteristica = new VetorCaracteristica();
			size = in.readInt();
			for(i=0;i<size;i++)
				vetorCaracteristica.addElement(in.readObject());

			
/*			m_listItensVendidos = new Vector();
			m_listItensVendidos.removeAllElements();
			size = in.readInt();
			for(i=0;i<size;i++)
				m_listItensVendidos.addElement(in.readObject());	
*/				

		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read do Agente" );
		 }
	 }
	
	abstract public	void AdcionaPaginas(String p) throws Exception ;		
	

	public String estagioString()
	{
		return "estagioString n�o poder ser chamado por aqui";
	}
	abstract public void executaEstrategia();

	abstract public void ModificaConfiguracaoMensagem(String mensagem);
	
	abstract public Mensagem recebeMensagem(Mensagem msg);
	

	
	////////////////////////////recebeAvisoRelogio()////////////////
//Recebi o aviso de que se passou um minuto
	public synchronized void recebeAvisoRelogio()
	{
		if(m_trabalhando)
			executaEstrategia();
	}
	


/**************** registrar *****************************
	protected synchronized void registrar()
	{
		try
		{
			boolean todosRegistrados=true;
			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				if(!pag.registrado())
					todosRegistrados = false;
			}
		
			if (todosRegistrados)
			{
				int i = estagio();
				setVezes(0);
				setEstagio(++i);	
				executaEstrategia();
				return;
			}
			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				pag.registraLeilao();
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no comeca a Trabalhar do "+nome());
		}
	}
/**************** registrar *****************************/
	protected synchronized void registrar()
	{
		try
		{
			boolean todosRegistrados=true;
			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				if (!pag.registrado())
				{
					todosRegistrados=false;
					pag.registraLeilao();
				}
			}
		
			if (todosRegistrados && listPaginas.size()>0)
			{
				int i = estagio();
				setVezes(0);
				setEstagio(++i);	
//				executaEstrategia();
				return;
			}
//			for(int i=0;i<listPaginas.size();i++)
//			{
//				Pagina pag = (Pagina)listPaginas.elementAt(i);
//				pag.registraLeilao();
//			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no comeca a Trabalhar do "+nome());
		}
	}
		
	public String nomeUsuario(){return m_nomeUsuario;}
	
	
	
	//VOU deixar por enquanto assim depois tenho que mudar.
//	public String loginLokau()
//	{
//		return m_loginLokau;
//	}
//	//VOU deixar por enquanto assim depois tenho que mudar.
//	public String senhaLokau()
//	{
//		return m_senhaLokau;
//	}


	public boolean jaRodou()
	{
		return m_jaRodou;
	}
	
	public void setNomeUsuarioPagina(String s)
	{
		m_nomeUsuarioPagina = s;
	}
	public String nomeUsuarioPagina()
	{
		return m_nomeUsuarioPagina;
	}


	public void setEmail(String e)
	{
		m_email = e;
	}
	public String email()
	{
		return m_email;
	}
	
	public void setJaRodou(boolean j)
	{
		m_jaRodou = j;
	}
	
	public boolean jaBuscou()
	{
		return m_jaBuscou;
	}
	
	public void setJaBuscou(boolean j)
	{
		m_jaBuscou = j;
	}
	public int autonomia()
	{
		return m_autonomia;
	}
	public String autonomiaString()
	{
		if(m_autonomia == 0)
			return "N�o configurado";
		if(m_autonomia == 1)
			return "Total";	
		if(m_autonomia == 2)
			return "Parcial";	
		if(m_autonomia == 3)
				return "Nenhuma";	
		return "N�o configurado";
			
	}	
	public void setAutonomia(int a)
	{
		m_autonomia = a;
	}
				
		
	public void setNomeProduto(String p)
	{
		m_nomeProduto = p;
	}
	public String nomeProduto()
	{
		return m_nomeProduto;
	}

	public void setStringErro(String s)
	{
		m_stringErro = s;
	}
	public String stringErro()
	{
		return m_stringErro;
	}
	public String historia()
	{
		return m_historia.toString();
	}

	public void appendHistoria(String string)
	{
		String s = string + ";" + Enviador.getStringData(new GregorianCalendar())+";";//calendar.get(Calendar.SECOND)+"/" + calendar.get(Calendar.MINUTE)+"/"+calendar.get(Calendar.HOUR_OF_DAY)+"/"+calendar.get(Calendar.DAY_OF_YEAR)+"/"+ calendar.get(Calendar.YEAR) + ",";
		m_historia.append(s);
	}
	
	public void LimpaHistoria()
	{
		m_historia.delete(0,m_historia.length()-1);
	}

	public void setTipo(String t)
	{
		m_tipo  = t;
	}


	public String tipo()
	{
		return m_tipo;
	}

	public String TrabalhandoString()
	{
		if(m_trabalhando)
			return "Sim";
		return "N�o";
	}
	
	synchronized public void setTrabalhando(boolean t)
	{
		m_trabalhando = t;
	}
	public boolean trabalhando()
	{
		return m_trabalhando;
	}
	
	
/********************* findPagina *******************************/	 	
	public Pagina findPagina(String p) throws Exception 

	{

		Pagina pag;
		for(int i=0;i<listPaginas.size();i++)
		{
			pag = (Pagina)listPaginas.elementAt(i);
			if(p.equalsIgnoreCase(pag.nome() ))
				return pag;
		}

		return null;

	}


/********************* addPagina *******************************/	 
	public Pagina addPagina(String p) throws Exception 

	{
		Pagina pag;
		pag = findPagina(p);

		if(pag != null)//se j� existir uma p�gina ent�o retorna null pois n�o conseguiu adicionar
			return pag;

		if(p.equalsIgnoreCase("LOKAU"))
			pag = new PaginaLokau(this);
		else if(p.equalsIgnoreCase("MLIVRE"))
			pag = new PaginaMLivre(this);
		else if(p.equalsIgnoreCase("ARREMATE"))
			pag = new PaginaArremate(this);
		else  if(p.equalsIgnoreCase("AKRM"))
			pag = new PaginaAKRM(this);
		else  if(p.equalsIgnoreCase("EVENDA"))
				pag = new PaginaEVenda(this);
		listPaginas.addElement(pag);

		return pag;

	}


/********************* addItem *******************************/	 
//Adciona um �nico Item.
	public void addItem(Item item)
	{
		if(findItemID(item.vetorCaracteristica.getValorCarac("codigo"))==null)//,item.vetorCaracteristica.getValorCarac("nomePagina"))== null)
			 listItens.addElement(item);
//		System.out.println(item.printCaracteristicas());	 
	}
	
	public Item findItemNome(String nome)
	{
		try
		{
			Item it;
			for(int i=0;i<listItens.size();i++)
			{	
				it = (Item)listItens.elementAt(i);
//				System.err.println("nomeAtual"+it.nome());
				if(it.nome().equals(nome))
					return it;
			}	
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no findItemNome do agente de compra:"+stringErro());		
		}
		return null;
	}
	public Item findItemID(String codProd)
	{
		try
		{
			Item it;
			String codigo;//,nomePaginaAtual;
			for(int i=0;i<listItens.size();i++)
			{	
				it = (Item)listItens.elementAt(i);
				codigo = it.vetorCaracteristica.getValorCarac("codigo");
				
				if(codigo.equals(codProd))// && nomePaginaAtual.equals(nomePagina) )
					return it;
			}	
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no findItemID do agente de compra:"+stringErro());		
		}
		return null;
	}


	public boolean removeItemID(String s)
	{
		for(int i =0; i<listItens.size();i++)
		{

			Item it = (Item)listItens.elementAt(i);
			if(s.equals(it.vetorCaracteristica.getValorCarac("codigo")))
			{
				listItens.removeElementAt(i);
				return true;
			}
		}
		return false;
	}
	public Item getItemAt(int pos)
	{
		if (listItens.size()>pos)
			return (Item)listItens.elementAt(pos);
		return null;
	}

	
	public void setEstagio(int e)
	{
		m_estagio = e;
	}
	public int estagio()
	{
		return m_estagio;
	}
	public void setVezes(int v)
	{
		m_vezes = v;
	}
	public int vezes()
	{
		return m_vezes;
	}		

	
	public Estrategia estrategia()
	{
		return m_estrategia;
	}
	
	public String tipoEstrategia()
	{
		if (m_estrategia!=null)
		{
			return m_estrategia.tipo();
		}
		return "";
	}


	public synchronized void setMensagem(Mensagem m)
	{
		m_mensagem = m;
		notify();
	}
	public synchronized Mensagem mensagem()
	{
		return m_mensagem;
	}
	
	public synchronized void setAvisoRelogio(boolean b)
	{
		m_avisoRelogio = b;
		notify();
//		Thread t = new Thread (this);			
//			ag.notifyAll();
//		t.notifyAll();			

	}
	public synchronized boolean avisoRelogio()
	{
		return m_avisoRelogio;
	}

/************************** RemoveItensExcedentes *****************************/
//Somente Deixa os que est�o na faixa do permitido(numMaxItens)
//No futuro vai remover os que tiver abaixo da satisfa��o desejada tamb�m.
//deve ser chamado depois da ordena��o.
	public void	RemoveItensExcedentes()
	{
	
	//		this.vetorCaracteristica.getValorCarac("avaliacaoItemMinima");
		for(int i = 0; i<listItens.size();i++)
		{
			Item it = (Item)listItens.elementAt(i);
			
			//se o item for novo e estiver fora dos limites do numero de itens aceitos d� erro.
			if (i>this.vetorCaracteristica.getValorCaracInteiro("numMaxItens") && it.novo())
			{
				listItens.removeElementAt(i);
			}
			else
				it.setNovo(false);
		}
	}

/************************** OrdenaItens *****************************/		
/**O que tem maior avalia��o primeiro*/
	public void OrdenaItens()
	{

		Item itAtual,it;
		int size = listItens.size();
		double avalMelhor;
		int posMelhor;

		//deppois melhoro essa ordena��o		
		for(int i = 0; i<listItens.size();i++)
		{
			itAtual = (Item)listItens.elementAt(i);
			avalMelhor = itAtual.somaAvaliacao();
			posMelhor = i;
			for(int j = i;j<listItens.size();j++)
			{
				it = (Item)listItens.elementAt(j);
				//se o item for maior insere nessa posi��o se n�o vai inserir mais pra baixo
				if (avalMelhor < it.somaAvaliacao())
				{			
					avalMelhor = it.somaAvaliacao();
					posMelhor = j;
				}
			}

			it = (Item)listItens.elementAt(posMelhor);
			listItens.removeElementAt(i);			
			listItens.insertElementAt(it,i);			
			listItens.removeElementAt(posMelhor);			
			listItens.insertElementAt(itAtual,posMelhor);			
		}
	}



/************************** EscolheItens *****************************/
/**de todos os Itens j� pegos nas p�ginas ir� escolher algumas de acorod com os crit�rios e restri��es*/
	public void EscolheItens()
	{
		Item item;
		//para cada Itens verifica a alternativa
		for(int i = 0; i<listItens.size();i++)
		{
			item = getItemAt(i);
			item.removeAllCriterios();
			for(int j = 0;j<listCriterios.size();j++)
			{
				Criterio c = (Criterio)listCriterios.elementAt(j);
				item.addValorCriterio(c.CalculaCriterio(item));
			}
			//soma os crit�rios para depois ordenar
			item.SomaCriterios();
		}
		//passa as restri��es...
		//Ordena
		OrdenaItens();
		//Remove
		RemoveItensExcedentes();
	}


	public int tempoTrabalhando()
	{
		try
		{
			String dataInicio = this.vetorCaracteristica.getValorCarac("dataInicio");
			
			int minutoInicio = (int)Enviador.pegaParteInteiro(dataInicio,0,'/');
			int horaInicio = (int)Enviador.pegaParteInteiro(dataInicio,1,'/');	
			int diaInicio = (int)Enviador.pegaParteInteiro(dataInicio,2,'/');		
			int AnoInicio = (int)Enviador.pegaParteInteiro(dataInicio,3,'/');			
		
			int minutos=0;
			Calendar calendar = new GregorianCalendar();	
			
			minutos = (calendar.get(Calendar.YEAR) - AnoInicio)*365*24*60;
			minutos += (calendar.get(Calendar.DAY_OF_YEAR) - diaInicio)*24*60;
			minutos += (calendar.get(Calendar.HOUR_OF_DAY) - horaInicio)*60;		
			minutos += (calendar.get(Calendar.MINUTE) - minutoInicio);		
			return minutos;
		
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em tempoRestante() de "+stringErro());
		}
		return 0;
	}


	public int tempoRestante()
	{
		try
		{
			String dataInicio = this.vetorCaracteristica.getValorCarac("dataInicio");
			
			int minutoInicio = (int)Enviador.pegaParteInteiro(dataInicio,0,'/');
			int horaInicio = (int)Enviador.pegaParteInteiro(dataInicio,1,'/');	
			int diaInicio = (int)Enviador.pegaParteInteiro(dataInicio,2,'/');		
			int AnoInicio = (int)Enviador.pegaParteInteiro(dataInicio,3,'/');			
		
			int minutos=0;
			Calendar calendar = new GregorianCalendar();	
				
			minutos = (calendar.get(Calendar.YEAR) - AnoInicio)*365*24*60;
			minutos += (calendar.get(Calendar.DAY_OF_YEAR) - diaInicio)*24*60;
			minutos += (calendar.get(Calendar.HOUR_OF_DAY) - horaInicio)*60;		
			minutos += (calendar.get(Calendar.MINUTE) - minutoInicio);		
			
			int prazo = vetorCaracteristica.getValorCaracInteiro("Prazo");
			
			prazo = prazo-minutos;
			
			if(prazo>0)
				return prazo;

		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em tempoRestante() de "+stringErro());
		}
		return 0;
	}

	public synchronized void run() 
	{
		try
		{
			setJaRodou(true);
			m_trabalhando = true;
			this.appendHistoria("Agente "+nome()+" come�ou a Rodar");
//			System.out.println("Agente "+nome()+" come�ou a Rodar");
			executaEstrategia();
			this.vetorCaracteristica.setValorCarac("dataInicio",Enviador.getStringData(new GregorianCalendar()));
			while (true)
			{
			
				rodaDelegate();
			
				while(m_trabalhando)
				{
		
					try
					{
						
						while (mensagem() == null && !avisoRelogio())
						{
							try
							{wait();}
							catch(InterruptedException ex) {return;}
						}
						if (mensagem() != null)
						{
//							System.out.println("\n\n*** "+nome()+" Recebeu uma Mensagem "+mensagem().mensagem()+"***");
							recebeMensagem(mensagem());
							setMensagem(null);
						}
						else
						{
//							System.out.println("\n\n*** "+nome()+" Recebeu Aviso do relogio ***");
							recebeAvisoRelogio();
							setAvisoRelogio(false);
						}
					}
					catch (Exception e) {return;}
//					System.out.println("*** "+nome()+" saiu do wait ***");
				}			
				this.finalize();
				
			}
		}
		catch(Exception e) 
		{

			System.err.println (e+" Erro no run "+stringErro());

		}     
	}		
}

/**************
import java.io.*;
import Abstract.*;
import KQMLLayer.*;
import RouterLayer.AgentClient.*;

public class PingPong extends  RouterClientAction {
    public static String localhost = "192.168.0.12";

    public PingPong(String id, String pw, String host, int port) throws Exception {
        super();    //RouterClientAction constructor

        //id,host,port,type,description
        String s = id+" , "+host+","+port+",MessageRouter,(agent-info :password "+pw+")";
		
		System.out.println("S:"+s);
		
		Address myAddress = new Address(s);
        s = "Router,192.168.0.25,4444,MessageRouter,(MessageRouter)";
        Address routerAddress = new Address(s);
        s = "RouterRegistrar,192.168.0.25,4445,MessageRouter,(MessageRouterRegistrar)";
        Address registrarAddress = new Address(s);

        setMyAddress(myAddress);    //agent address
        setRouterAddress(routerAddress);    //Router address
        setRegistrarAddress(registrarAddress);    //registrar address

        try {
          createServerThread(myAddress.getID(), Thread.NORM_PRIORITY);    //server listener
          register();    //register to Router
          connect();    //connect to Router
        } catch(ConnectionException e) {
            throw new Exception(e.toString());
        }
    }
	public boolean Act(Object o) {    //invoked automatically when a message is received
    
	    String message = (String) o;
		System.out.println(this.getName()+" Act");
        try {
            KQMLmail mail = new KQMLmail(message, 0);    //KQMLmail wrap the KQMLmessage
            _mailQueue.addElement(mail);    //message repository (to delete message after)
            KQMLmessage kqml = mail.getKQMLmessage();    //get KQMLmessage object

            String perf = kqml.getValue("performative");
            String content = kqml.getValue("content");

            if(perf.equals("tell") && content != null) {
                System.out.println(content);
                acknowledge(kqml.getValue("sender"), content);
                addToDeleteBuffer(0);    //send delete message to Router
            }
            else {
                sendErrorMessage(kqml);
                return false;
            }
        } catch (Exception e) {
            return false;
        }

        return true;
    }

    public void processMessage(String command, Object obj)
	{
		System.out.println(this.getName()+" acknowledge");
         System.out.println("ProcessMessage");
	}    
	
	
	protected void acknowledge(String receiver, String toContent) throws Exception {
	
		System.out.println(this.getName()+" acknowledge");
		
        KQMLmessage sendkqml = new KQMLmessage();
        sendkqml.addFieldValuePair("performative", "tell");
        sendkqml.addFieldValuePair("sender", this.getName());
        sendkqml.addFieldValuePair("receiver", receiver);
        //...
        if(toContent.equals("(ping)")) sendkqml.addFieldValuePair("content", "(pong)");
        else sendkqml.addFieldValuePair("content", "(ping)");
        sendMessage(sendkqml);    //send message to Router: throws ConnectionException
    }

    protected void sendErrorMessage(KQMLmessage kqml) throws Exception {
        String msg = "(error :sender " + this.getName() + " :receiver " +
                     kqml.getValue("sender") + " :content (" + kqml.getSendString() + "))";
        sendMessage(msg);    //send Router: throws ConnectionException and ParseException
        addToDeleteBuffer(0);    //send delete message to Router
    }


    public static void main(String argv[]) throws Exception {
		System.out.println("Comecando");
        PingPong pingA = new PingPong("ping", "xyz", localhost, 2222);    //create pingA
        PingPong pongA = new PingPong("pong", "hjk", localhost, 2223);    //create pongA
        pingA.start();    
		pongA.start();    //start agent action
        pingA.sendKQMLMessage("(tell :sender " + pingA.getName() + " :receiver " +
                              pongA.getName() + " :content (ping))");    //or sendMessage
        sleep(6000);
		System.out.println("Saindo");
        pingA.disconnect();    pongA.disconnect();    //disconnect from Router
        pingA.unregister();    pongA.unregister();    //unregister from Router
        pingA.endAction();    pongA.endAction();    //clean up and stop agent action
        System.exit(0);
    }
}
 
	 
******************/
