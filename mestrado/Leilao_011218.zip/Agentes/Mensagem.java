import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;

public class Mensagem extends ObjetoEnviado
{
	private String m_ip;
	private String m_mensagem;
	private String m_mensagemAux;


	public Mensagem () 
	{
	}
	public Mensagem (String nome,String ip) 
	{ 
		super(nome);
		m_ip = ip;
	}
	
	/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
	
			out.writeObject(m_ip);
			out.writeObject(m_mensagem);
			out.writeObject(m_mensagemAux);
			out.flush();
		}	
		catch(IOException e)
		{
			System.out.println(e+ " Erro no write do Mensagem" );
		}			
	}
	
/****************************** readObject **********************************/		
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_ip =  (String)in.readObject();
			m_mensagem =  (String)in.readObject();			
			m_mensagemAux =  (String)in.readObject();
		 }
		 catch(IOException e)
		 {
		 	System.out.println(e+" Erro no read do Mensagem" );
		 }
	 }

		
	public String ip()
	{
		return m_ip;
	}
	
	public String mensagem()
	{
		return m_mensagem;		
	}
	public void setMensagem(String Mensagem)
	{
		m_mensagem = Mensagem;
	}
	public String mensagemAux()
	{
		return m_mensagemAux;
	}
	public void setMensagemAux(String Mensagem)
	{
		m_mensagemAux = Mensagem;
	}
}