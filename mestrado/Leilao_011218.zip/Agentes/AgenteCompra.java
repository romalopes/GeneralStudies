/**classe Final Agente de compra**/

import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;

/*
Classe do agente de compra

Procedimento do Agente Compra
	Configurado Pelo Usu�rio
	Visita Sites de Leil�o
		Verifica Caracter�sticas dos produtos para escolher
	Recebe Oferta de produtos do Leiloeiro
		Analisa a oferta e verifica se o produto est� dentro das prefer�ncia
	Ranqueia os produtos dos leil�es(especiais ou n�o) , ok
	Entra nos leil�es , ok
	Realiza ofertas
		Com base nos outros agentes e no status dos leil�es
	Recebe notifica��es
		Pode desistir de um leil�o
		Ao saber que comprou um produto verifica se deve fechar o leil�o.
	Faz o contato do vendedor com o seu usu�rio
*/

final public class AgenteCompra extends Agente
{
	private double m_precoMin,m_precoMax;
//	private Vector m_listItensComprados;
	
	public AgenteCompra(String usu,String n)
	{
		super(usu,n);
		try
		{	
			StringBuffer string = new StringBuffer(500);
			
			string.append("2,");//autonomia
			string.append("PerfilConcorrente,");			
			string.append("PrecoMax,");
			string.append("0,");
			string.append("PrecoMin,");
			string.append("0,");
			string.append("tempoTrabalho,");
			string.append("0,");
			string.append("detalhes,");
			string.append("sem detalhe ainda,");
			string.append("subTipoEstrategia,");
			string.append("normal,");
//			string.append("site,");
//			string.append("AKRM,");//nomeSite  // � um desse para cada p�gina.			
//			string.append("tipoLeilao,");
//			string.append("Ingles,");	

		
			setTipo("Compra");
			m_precoMin = m_precoMax = 0;
			
			//somente por enquanto, isso vai ser criado de forma externa
//			CriterioPreco c = new CriterioPreco((float)1);
//			listCriterios.addElement(c);	
//			m_listItensComprados = new Vector();

			setStringErro("no Agente de Compra:"+nome());
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro na Cria��o do AgenteCompra:"+nome() );
		}
	}

	

	/****************************** writeObject **********************************/
	private void writeObject(java.io.ObjectOutputStream out)

	     throws IOException

	{
		try

		{
			out.writeDouble(m_precoMin);	
			out.writeDouble(m_precoMax);				
/*			out.writeInt(m_listItensComprados.size());	
			for(int i=0;i<m_listItensComprados.size();i++)
				out.writeObject(m_listItensComprados.elementAt(i));
*/
			out.flush();

		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write "+stringErro() );
		}
	}



/****************************** readObject **********************************/

	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_precoMin = in.readDouble();	
			m_precoMax = in.readDouble();
/*			m_listItensComprados = new Vector();
			m_listItensComprados.removeAllElements();
			size = in.readInt();
			for(i=0;i<size;i++)
				m_listItensComprados.addElement(in.readObject());	
*/				
		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read "+stringErro() );
		 }
	}
	
	public double precoMin()
	{
		return m_precoMin;
	} 
	public void setPrecoMin(double p)
	{
		m_precoMin = p;
	}	
	public double precoMax()
	{
		return m_precoMax;
	} 
	public void setPrecoMax(double p)
	{
		m_precoMax = p;
	}		
	
	//por enquanto est� igual aos outros mas pode ficar diferente
	public void setEstrategia(String tipoEstrategia)
	{
		Estrategia estrategia = null;
		
		if(estrategia() != null)
			if(tipoEstrategia.equals(estrategia().tipo()))
				return;
		if(tipoEstrategia.equalsIgnoreCase("simples"))
			estrategia = new EstrategiaCompraSimples(this);
		else if(tipoEstrategia.equalsIgnoreCase("PerfilConcorrente"))
			estrategia = new EstrategiaCompraPerfilConcorrente(this);
		if(tipoEstrategia.equalsIgnoreCase("TempoValor"))
			estrategia = new EstrategiaCompraTempoValor(this);	
		m_estrategia = estrategia;
	}


/************** ModificaConfiguracaoMensagem *********************/
//primeiro conjunto de configura��es relativos ao agente, depois aos sites.
//Modifica a configura��o com base na mensagem que foi passado pelo usu�rio
	public void ModificaConfiguracaoMensagem(String mensagem)
	{
		try
		{
			this.appendHistoria("Modifica a Configuracao ");//+ mensagem);

			int i = 1;
			setAutonomia(Enviador.pegaParteInteiro(mensagem,1,','));//1
			i++;
			String estrategia = Enviador.pegaParte(mensagem,2,',');//2
			setEstrategia(estrategia);			
			i++;
			
			String nomeProduto = Enviador.pegaParte(mensagem,4,',');
			setNomeProduto(nomeProduto);
	
			String s1,s2;
			while (!Enviador.pegaParte(mensagem,i,',').equals("site") && !Enviador.pegaParte(mensagem,i,',').equals("") )
			{
				s1 = Enviador.pegaParte(mensagem,i,',');
				i++;
				s2 = Enviador.pegaParte(mensagem,i,',');
				this.vetorCaracteristica.setValorCarac(s1,s2);
				i++;
			}
//			System.out.println(mensagem);
			while (Enviador.pegaParte(mensagem,i,',').equals("site"))//pega o site
			{
				i++;
				String site = Enviador.pegaParte(mensagem,i,',');//nome do site
				Pagina pag = addPagina(site);
				System.out.println("site "+site);
//				if(!Enviador.pegaParte(mensagem,i,',').equals("&") && !Enviador.pegaParte(mensagem,i,',').equals("") )
//				{
				
				i++;
				//login
				s2 = Enviador.pegaParte(mensagem,i,',');
//				System.out.println("s2 "+s2);
				if(s2.equals("login"))
				{
					i++;
					s2 = Enviador.pegaParte(mensagem,i,',');
//					System.out.println("login "+s2);
					pag.setLogin(s2);
					i=i+2;
					//senha
					s2 = Enviador.pegaParte(mensagem,i,',');
//					System.out.println("senha "+s2);
					pag.setSenha(s2);
					i++;
				}

				s1 = Enviador.pegaParte(mensagem,i,',');
				i++;
				s2 = Enviador.pegaParte(mensagem,i,',');
				i++;
				pag.vetorCaracteristica.setValorCarac(s1,s2);
//				System.out.println(s1+" "+s2);
					
//				}
			}	
			
		
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no ModificaConfiguracaoMensagem "+stringErro());
		}
	}
	
	 

	



/************************** RemoveItensExcedentes *****************************
//Somente Deixa os que est�o na faixa do permitido(numMaxItens)
//No futuro vai remover os que tiver abaixo da satisfa��o desejada tamb�m.
//deve ser chamado depois da ordena��o.
	public void	RemoveItensExcedentes()
	{
	
	//		this.vetorCaracteristica.getValorCarac("avaliacaoItemMinima");
		for(int i = 0; i<listItens.size();i++)
		{
			Item it = (Item)listItens.elementAt(i);
			
			//se o item for novo e estiver fora dos limites do numero de itens aceitos d� erro.
			if (i>this.vetorCaracteristica.getValorCaracInteiro("numMaxItens") && it.novo())
			{
				listItens.removeElementAt(i);
			}
			else
				it.setNovo(false);
		}
	}


/************************** OrdenaItens *****************************
/**O que tem maior avalia��o primeiro*
	public void OrdenaItens()
	{

		Item itAtual,it;
		int size = listItens.size();
		double avalMelhor;
		int posMelhor;

		//deppois melhoro essa ordena��o		
		for(int i = 0; i<listItens.size();i++)
		{
			itAtual = (Item)listItens.elementAt(i);
			avalMelhor = itAtual.somaAvaliacao();
			posMelhor = i;
			for(int j = i;j<listItens.size();j++)
			{
				it = (Item)listItens.elementAt(j);
				//se o item for maior insere nessa posi��o se n�o vai inserir mais pra baixo
				if (avalMelhor < it.somaAvaliacao())
				{			
					avalMelhor = it.somaAvaliacao();
					posMelhor = j;
				}
			}

			it = (Item)listItens.elementAt(posMelhor);
			listItens.removeElementAt(i);			
			listItens.insertElementAt(it,i);			
			listItens.removeElementAt(posMelhor);			
			listItens.insertElementAt(itAtual,posMelhor);			
		}
	}



/************************** passaRestricoes *****************************/			
	public void	passaRestricoes()
	{
//		this.vetorCaracteristica.getValorCarac("avaliacaoItemMinima");
	};
	
	
/************************** EscolheItens *****************************
/**de todos os Itens j� pegos nas p�ginas ir� escolher algumas de acorod com os crit�rios e restri��es*
	public void EscolheItens()
	{

		if(listItens.size()>0)
			this.appendHistoria("Escolhe os itens depois da busca ");
		else
			this.appendHistoria("N�o h� itens na lista ent�o n�o posso escolher");	
		Item item;
		//para cada Itens verifica a alternativa
		for(int i = 0; i<listItens.size();i++)
		{

			item = (Item)listItens.elementAt(i);
			//tamb�m passas pelos itens que j� foram escolhidos anteriormente.  Isso fica interessante pois a avalia��o ocorre em tempo de execu�ao.					
			item.removeAllCriterios();
			for(int j = 0;j<listCriterios.size();j++)
			{
				Criterio c = (Criterio)listCriterios.elementAt(j);
				item.addValorCriterio(c.CalculaCriterio(item));
			}
			//soma os crit�rios para depois ordenar
			item.SomaCriterios();
		}

		//passa as restri��es...
		passaRestricoes();
			

		//Ordena
		OrdenaItens();


		//Remove
		RemoveItensExcedentes();

	}
/*********************** Adciona P�ginas *****************************/	
/**Verifica se o agente possui alguma configura��o que inviabiliza a opera��o de oferta.
Por exemplo se o agente n�o pode comprar mais de um produto.  Etc.
Por enquanto s� verificaremos se o agente j� est� vencendo em algum.
**/
public boolean	verificaRestricaoConfiguracaoOferta()
{
	try
	{

		Item it;
		//para cada Itens verifica a alternativa
		for(int i = 0; i<listItens.size();i++)
		{

			it = (Item)listItens.elementAt(i);

			int size = it.vetorOfertas.size();
			if (size > 0)
			{
				Oferta oferta = (Oferta)it.vetorOfertas.elementAt(size - 1);	
				if(oferta != null)
					if(nomeUsuarioPagina().equalsIgnoreCase(oferta.nomeUsuario()))
						return false;//o vencedor atual � o pr�prio agente
			}				
		}
		return true;
	}
	catch(Exception e)
	{
		System.err.println(e+" Erro no verificaRestricaoOferta "+stringErro());
	}
	return false;
}
	
	
/*********************** Adciona P�ginas *****************************/	
	public void AdcionaPaginas(String paginas)	throws Exception 
	{
		try
		{
			int i=1;
			String pag = " ";
			while (!pag.equals("") )
			{
				pag = Enviador.pegaParte(paginas,i,',');
				i++;
				addPagina(pag);
			}
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no AdcionaPaginas "+stringErro() );
		}     
	}

//Especial para o site do AKRM
/*********************** RecebeMensagemBusca *****************************/	
//recebe apenas um OK ou erro.
	public Mensagem recebeReplyRegistroAKRM(Mensagem msg) 	throws Exception 
	{
		try
		{
			this.appendHistoria("Reply de Registro AKRM TRUE");
			msg.setReply(false);
			Pagina pag = findPagina("AKRM");
			
			
			//verifica se tem mesmo que mudar de estado, pois no caso de uma oferta de leilao feita por um leiloeiro, esse agente j� pode estar em um estado de negociacao.
			
			if (msg.mensagemRetorno())
			{
				pag.setRegistrado(true);
				int i = estagio();
				setEstagio(1);//para o estagio de busca
				executaEstrategia();
			}
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no recebeReplyRegistroAKRM "+stringErro());
		}     
		
		return msg;	
	}	
	
	
/************************** BuscaProdutosSites *****************************/	
//Raliza a busca pelos itens de acordo com o nome especificado, para o lokau.com
	private String BuscaProdutosSites() 	throws Exception 
	{
		Item item;
		int j=0;
	
		try
		{
		
			System.out.println ("BuscaProdutosSites por "+ nomeProduto());
			this.appendHistoria("Busca por "+ nomeProduto());

			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				
				if(pag.biniciaBusca())
					continue;
									
				pag.IniciaBusca();
				System.out.println ("\nBusca na pagina "+pag.nome());
				do
				{
					j++;
					item = pag.Busca(nomeProduto());
					if(item!=null)
						this.addItem(item);
				}while (item != null );
				pag.finalizaConexao();
				

			}

			if (listItens.size()>0)
			{
				int i = estagio();
				setVezes(++i);
				setEstagio(estagio()+1);
			}

			EscolheItens();

		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no BuscaProdutosSites "+stringErro() );
			return "erro";
		}     
		return "ok";
	}

//Especial para o site do AKRM
/*********************** recebeReplyBuscaProdutos *****************************/	
	public Mensagem recebeReplyBuscaProdutos(Mensagem msg) 	throws Exception 
	{
		Item item;
		try
		{
			String StringItem;
			this.appendHistoria("Reply busca produtos ");
			msg.setMensagemRetorno(false);
			String	mensagemAux = msg.mensagemAux();
			msg.setReply(false);
			int i=0;
			Pagina pag = findPagina("AKRM");
			if (pag == null)
			{
				this.appendHistoria("Inconsistencia na p�ginha AKRM ");
				return msg;
			}
			i=0;
			StringItem = Enviador.pegaParte(mensagemAux,i,',');
			while(!StringItem.equalsIgnoreCase(""))
			{							//nome, agente , p�gina
				item = new Item(Enviador.pegaParte(StringItem,1,'&'),this,pag);
				String palavra;
				item.vetorCaracteristica.setCaracteristicas(StringItem);//aqui pega toda a string e joga no item
				String nomeProd = item.vetorCaracteristica.getValorCarac("nomeProduto");
				if(!nomeProd.equals(""))
					item.setNome(nomeProd);
				
				addItem(item);				
				
				item.vetorCaracteristica.setValorCarac("valorAtual",item.vetorCaracteristica.getValorCarac("valorinicial"));
				item.vetorCaracteristica.setValorCarac("valorVencedor",item.vetorCaracteristica.getValorCarac("valorinicial"));
				i++;
				StringItem = Enviador.pegaParte(mensagemAux,i,',');
			}		
			if (listItens.size()==0)			
			{
				this.appendHistoria("Uma busca com resultado vazio ");
				msg.setMensagemRetorno(true);
				return msg;
			}	
			EscolheItens();
					
						
			i = estagio();
			setVezes(0);
			if(estagio()==1)
				setEstagio(2);	//para o est�gio de negociacao
			executaEstrategia();
			mensagemAux = msg.mensagemAux();
			this.appendHistoria("Retornou da busca com sucesso");//Resultado Busca "+ mensagemAux);
		}
		catch(Exception e) 
		{

			System.err.println (e+" Erro no Busca "+stringErro());
		}     
		msg.setMensagemRetorno(true);

		return msg;
	}

//Especial para o site do AKRM
/*********************** recebeReplyBuscaProdutoIndividual *****************************/	
	public Mensagem recebeReplyBuscaProdutoIndividual(Mensagem msg) 	throws Exception 
	{
		Item item;
		try
		{
			String StringItem;
			msg.setMensagemRetorno(false);
			String	mensagemAux = msg.mensagemAux();
			msg.setReply(false);
			int i=0;
			Pagina pag = findPagina("AKRM");
			if (pag == null)
			{
				this.appendHistoria("Inconsistencia na p�ginha AKRM ");
				return msg;
			}
			i=0;
			StringItem = Enviador.pegaParte(mensagemAux,i,',');

			item = new Item(Enviador.pegaParte(StringItem,1,'&'),this,pag);
//			System.out.println(StringItem);

			String palavra;

			item.vetorCaracteristica.setCaracteristicas(StringItem);//aqui pega toda a string e joga no item
			
			String nomeProd = item.vetorCaracteristica.getValorCarac("nomeProduto");
			if(!nomeProd.equals(""))
				item.setNome(nomeProd);
			addItem(item);
						
			item.vetorCaracteristica.setValorCarac("valorAtual",item.vetorCaracteristica.getValorCarac("valorinicial"));
			item.vetorCaracteristica.setValorCarac("valorVencedor",item.vetorCaracteristica.getValorCarac("valorinicial"));

			System.out.println ("\nPegou prod" + StringItem);

			this.appendHistoria("Reply busca produto de um produto individual "+item.nome()/*printCaracteristicas()*/+"da pagina:"+item.vetorCaracteristica.getValorCarac("nomePagina"));//+item.printCaracteristicas());

			i++;
			StringItem = Enviador.pegaParte(mensagemAux,i,',');
			EscolheItens();
			executaEstrategia();
		}
		catch(Exception e) 
		{

			System.err.println (e+ " Erro no Busca "+stringErro());
		}     
		msg.setMensagemRetorno(true);

		return msg;
	}


/************************** RealizaOfertaItem *****************************/	
//Raliza a busca pelos itens de acordo com o nome especificado, para o lokau.com
	public String realizaOfertaItem(Item it,double valorOferta) //	throws Exception 
	{
		try
		{
			this.appendHistoria("Oferta para "+ it.nome() +"NomePagina: "+it.vetorCaracteristica.getValorCarac("nomePagina")+ "no valor de "+valorOferta);
//			System.out.println(nome()+"fez oferta para "+ it.nome() + "valor:"+valorOferta );
			it.pagina().realizaOfertaItem(it,valorOferta);
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no RealizaOfertaItem "+stringErro());
			return "erro";
		}
		return "ok";
	}

/************************** recebeReplyOferta ***************************/	
	public void recebeReplyOferta(Mensagem msg) 	throws Exception 
	{//Quatro situacoes.  Aceito, Outra Pessoa efetuou oferta, Nao aceito, Leilao Inativo
		try
		{// MensagemAux 0=Agente 1=CodProd 2=Valor  3=Restricao
			String sAgente = Enviador.pegaParte(msg.mensagemAux(),0,',');
			String codProd = Enviador.pegaParte(msg.mensagemAux(),1,',');			
			String valorOferta = Enviador.pegaParte(msg.mensagemAux(),2,',');	
			if (!msg.mensagemRetorno())//4
			{
				String tipoFalha = Enviador.pegaParte(msg.mensagemAux(),3,',');
				if(tipoFalha.equals("fechado"))
				{
//						removeItemID(Enviador.pegaParte(msg.mensagemAux(),1,','));			
						perdiLeilao(codProd);
						this.appendHistoria("Oferta n�o foi aceita sobre o produto "+codProd);
				}
				else
				{
//					System.out.println(" Oferta com restricoes** codProd:"+codProd+" valorAtual:"+valorOferta);
					this.appendHistoria("Oferta n�o foi aceita sobre o produto "+codProd+"o valor atual � "+valorOferta);
					recebeAvisoOfertaLeilaoAKRM(msg);
					executaEstrategia();									
				}
//Oferta nao foi aceita.

			}
			else//oferta aceita
			if(sAgente.equalsIgnoreCase(this.nomeUsuarioPagina()))//1
			{
				this.appendHistoria(nome()+ " Reply oferta AKRM: "+msg.mensagemRetorno()+" para o produto: "+codProd);
//				msg.setMensagemRetorno(false);
				String	mensagemAux = msg.mensagemAux();
				Item it;
				//o item.
				it = findItemID(Enviador.pegaParte(mensagemAux,1,','));//0=nomeOfertante,1=CodProd,2=ValorOferta,3=Estrelas
									
				Oferta oferta = new Oferta(sAgente,Enviador.pegaParte(mensagemAux,2,','));
				oferta.setNumeroEstrelas(Enviador.pegaParteInteiro(mensagemAux,3,','));
							
				oferta.setCodProd(it.vetorCaracteristica.getValorCarac("codigo"));
				oferta.setNomeProd(it.nome());
//				System.out.println(oferta.printCaracteristicas());				
				it.vetorOfertas.addElement(oferta);
				
				int numeroOfertas = it.vetorCaracteristica.getValorCaracInteiro("numeroOfertas");
				numeroOfertas++;
				it.vetorCaracteristica.setValorCarac("numeroOfertas",String.valueOf(numeroOfertas));
				
				
				//2 � o valor.
				int i=0;
//				System.out.println(nome()+" reply de que consegui efetuar oferta*** nomeProd:"+it.vetorCaracteristica.getValorCarac("nomeProduto"));
				this.appendHistoria("Consegui realizar a oferta sobre o produto "+it.nome()/*printCaracteristicas()*/+"da pagina:"+it.vetorCaracteristica.getValorCarac("nomePagina"));//+it.printCaracteristicas());				
			}
			else//2
			{
//				System.out.println(nome()+" Recebe o aviso da oferta de outro*** codigo:"+codProd);
				this.appendHistoria("Avisado de oferta sobre o produto "+ codProd);				
				recebeAvisoOfertaLeilaoAKRM(msg);
//				executaEstrategia();				
				//est� sendo informado que outro agente realizou a oferta.
			}

		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no recebeReplyOferta "+stringErro());
		}
	}

/************************** recebeAvisoOfertaLeilaoAKRM ***************************/	
	private void recebeAvisoOfertaLeilaoAKRM(Mensagem msg) throws Exception 
	{	//msg.mensagemAux = nome+","+nomeProd+","+(pLeiloeiro.ValorAtual()
		try//outro agente efetuou uma oferta
		{
			String nomeOfertante,nomeProd;
			double valorOferta;

//			this.appendHistoria("Avisado de oferta AKRM:");			

			//0=nomeOfertante,1=CodProd,2=ValorOferta,3=Estrelas
			nomeOfertante = Enviador.pegaParte(msg.mensagemAux(),0,',');
			String CodProd = Enviador.pegaParte(msg.mensagemAux(),1,',');
			valorOferta = Enviador.pegaParteDouble(msg.mensagemAux(),2,',');

			
			Item it = findItemID(CodProd);

			this.appendHistoria("Outro usu�rio realizou oferta sobre: "+it.nome()/*printCaracteristicas()*/+"da pagina:"+it.vetorCaracteristica.getValorCarac("nomePagina"));//+it.printCaracteristicas());				
			
			Oferta oferta = new Oferta(nomeOfertante,String.valueOf(valorOferta));
			String codigo = it.vetorCaracteristica.getValorCarac("codigo");

			oferta.setCodProd(codigo);
			
			//aqui coloca o valor correto no valor atual
//			oferta.setNomeProd(it.vetorCaracteristica.getValorCarac("nomeProduto"));				
			oferta.setNomeProd(it.nome());
			String valorAtual = it.vetorCaracteristica.getValorCarac("valorAtual");				
//			System.out.println("valorAtual:"+valorAtual+ "valorOferta:"+valorOferta);
			it.vetorCaracteristica.setValorCarac("valorAtual",String.valueOf(valorOferta));
			valorAtual = it.vetorCaracteristica.getValorCarac("valorAtual");							
			System.out.println("valorAtual:"+valorAtual+ "valorOferta:"+valorOferta);
			it.vetorOfertas.addElement(oferta);				
			
			int numeroOfertas = it.vetorCaracteristica.getValorCaracInteiro("numeroOfertas");
			numeroOfertas++;
			it.vetorCaracteristica.setValorCarac("numeroOfertas",String.valueOf(numeroOfertas));
			
//			msg.setMensagemRetorno(false);
			String	mensagemAux = msg.mensagemAux();
			int i=0;
			Pagina pag = findPagina("AKRM");
			if (pag == null)
			{
				this.appendHistoria("Inconsistencia na p�ginha AKRM ");
				return;
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no recebeAvisoOfertaLeilaoAKRM "+stringErro());
		}
	}


	
/********************** VenciLeilao ***************************/			
	private void venciLeilao(String codigo)
	{
		Item it = findItemID(codigo);			
		
		this.appendHistoria("Venci o leil�o de "+it.nome()/*printCaracteristicas()*/+"da pagina:"+it.vetorCaracteristica.getValorCarac("nomePagina"));//+it.printCaracteristicas());		
		
		this.appendHistoria("Estou esperando contado do vendedor");
		
		it.setComprado(true);
		it.setVendido(true);		
//		removeItemID(it.vetorCaracteristica.getValorCarac("codigo"));//N�o acho interessante fazer s� isso... podemos deixar para considerar raciociando em cima
	}
/********************** perdiLeilao ***************************/			
	private void perdiLeilao(String codigo)
	{
		Item it = findItemID(codigo);			

		this.appendHistoria("Perdi o lei�o de" +it.nome()/*printCaracteristicas()*/+"da pagina:"+it.vetorCaracteristica.getValorCarac("nomePagina"));//+"+it.printCaracteristicas());
				
		it.setComprado(false);				
		it.setVendido(true);
		//coloca no vetor caracteristicas as caracteristicas do vencedor.
	}
/************************** recebeReplyFechaLeilaoAKRM ***************************/		
	private void recebeReplyFechaLeilaoAKRM(Mensagem msg) throws Exception
	{
		try
		{
			String CodProd = Enviador.pegaParte(msg.mensagemAux(),0,',');
			String sAgente = Enviador.pegaParte(msg.mensagemAux(),1,',');					
//			System.out.println(msg.mensagemAux());
			Item it = findItemID(CodProd);			

			if (it == null)
			{
				System.out.println("***********************Erro***********************");
				return;//erro;
			}
			
			this.appendHistoria("Leil�o de "+it.nome()/*printCaracteristicas()*/+"da pagina:"+it.vetorCaracteristica.getValorCarac("nomePagina")+" foi fechado");
			
			if(sAgente.equalsIgnoreCase(this.nomeUsuarioPagina()))
			{
				System.out.println("**************************this:"+nome()+"**************************************"+sAgente+"\n"+it.vetorCaracteristica.getValorCarac("detalhes")+"  Venci em "+it.tempoLeilao()+"\n*****************************");			
				venciLeilao(CodProd);
			}
			else
			{
				System.out.println("**************************this:"+nome()+"**************************************"+sAgente+"\n"+it.vetorCaracteristica.getValorCarac("detalhes")+"  Perdi\n*****************************");						
//				removeItemID(Enviador.pegaParte(msg.mensagemAux(),2,','));//N�o acho interessante fazer s� isso... podemos deixar para considerar raciociando em cima
				perdiLeilao(CodProd);
			}
		
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no recebeReplyFechaLeilaoAKRM "+stringErro());		
		}
	}

/******************** recebeReplyFechaLeilaoAKRM *****************************
	public Mensagem recebeReplyFechaLeilaoAKRM(Mensagem msg) 	throws Exception 
	{
		try
		{
			this.appendHistoria("Reply de recebeReplyFechaLeilaoAKRM resultado:"+msg.mensagemRetorno());
			msg.setReply(false);
			
			if (msg.mensagemRetorno())
			{
				Item it = findItemID(Enviador.pegaParte(msg.mensagemAux(),0,','));
				if(it!=null)
					it.setVendido(true);
				else
					System.out.println("Problema ao setar produto vendido ID:"+msg.mensagemAux());	

				int i = estagio();
				setVezes(0);
				setEstagio(++i);
				executaEstrategia();
			}
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no recebeReplyFechaLeilaoAKRM "+stringErro());
		}
		return msg;	
	}	


	/*********************** recebeConviteLeilao ************************/					
	private void recebeConviteLeilao(Mensagem msg) throws Exception
	{
		try
		{
		
			String idItem = Enviador.pegaParte(msg.mensagemAux(),0,',');//pega o id e verifica no leil�o se o produto � bom mesmo.
			String nomePagina = Enviador.pegaParte(msg.mensagemAux(),1,',');

			this.appendHistoria("Recebe um convite do leiloeiro"+msg.origem()+" idItem:"+idItem+" nomePagina"+nomePagina);
			
			Pagina pag = findPagina(nomePagina);
			if (pag != null)
			{
				pag.buscaProdutoIndividual(idItem);			
			}
			else
			{	
				pag = addPagina(nomePagina);
				pag.buscaProdutoIndividual(idItem);			
				setEstagio(0);	
			}
			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no recebeConviteLeilao "+stringErro());				
		}
	}
	
	/*********************** msgSetEstrategiaCompra ************************/				
	private void msgSetEstrategiaCompra(Mensagem msg)
	{
		String tipoEstrategia = Enviador.pegaParte(msg.mensagemAux(),0,',');
		if (tipoEstrategia.equals("simples") || tipoEstrategia.equals("EstrategiaCompraPerfilConcorrente")
			|| tipoEstrategia.equals("EstrategiaCompraTempoValor"))
		{
			setEstrategia(tipoEstrategia);
		}
	}
	
	/************************** estagioString ***************************/			
	public String estagioString()
	{
		if(estagio() == 0)
			return "Est�gio de Registro";
		else if(estagio() == 1)
			return "Est�gio de Busca por Produtos";
		else if(estagio() == 2)
				return "Est�gio de Ofertas";
	
		return "Est�gio n�o relacionado";
	}
	
/************************** executaEstrategia ***************************/			
//depois de receber o aviso verifica se j� est� trabalhando e continua a estrat�gia.
	public synchronized void executaEstrategia()
	{
		try
		{//por enquanto as estrat�gias s�o individuais.
		
			this.appendHistoria("Verifica estrat�gia. "+estagioString()+" Vezes:"+vezes());
//			System.out.println(nome()+" Executando estrategia. "+estagioString()+" Vezes:"+vezes());
			int i = vezes();
			setVezes(++i);
			if (estagio() == 0)//registrar
			{
				registrar();//tenta registrar em todos as p�ginas, se j� tiver registrado simplesmente n�o se registra.
			}
			else 
			if (estagio() == 1)//busca pelos itens
			{
				BuscaProdutosSites();
			}
			else if (estagio()==2)//analisa situacao dos leiloes
			{
//				if(vezes() < 4)
				if(estrategia() != null)
					estrategia().analisaSituacaoItens();
//				System.out.println("est�gio 2 ainda n�o implementado: "+ nome());
			}
			else if (estagio() == 3)
			{
				System.out.println("est�gio 3 ainda n�o implementado: "+ nome());
			}
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no executaEstrategia "+stringErro());
		}     
	}

	/************************** recebeMensagem *****************************/	
	public Mensagem recebeMensagem(Mensagem msg)
	{
		Mensagem mensagem = new Mensagem("","");
		try
		{
			if (msg.mensagem().equalsIgnoreCase("recebeReplyBuscaProdutos"))
			{
				mensagem = recebeReplyBuscaProdutos(msg);
			}
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyRegistroAKRM"))
			{
				mensagem = recebeReplyRegistroAKRM(msg);
			}
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyOferta"))
			{
				recebeReplyOferta(msg);
				mensagem.setReply(false);
			}
			else if (msg.mensagem().equalsIgnoreCase("recebeAvisoOfertaLeilaoAKRM"))
			{
				recebeAvisoOfertaLeilaoAKRM(msg);
				mensagem.setReply(false);
			}
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyFechaLeilaoAKRM"))
			{
				recebeReplyFechaLeilaoAKRM(msg);
				mensagem.setReply(false);
			}			
			else if (msg.mensagem().equalsIgnoreCase("recebeConviteLeilao"))
			{
				recebeConviteLeilao(msg);
				mensagem.setReply(false);
			}
			else if (msg.mensagem().equalsIgnoreCase("msgSetEstrategiaCompra"))
			{
				msgSetEstrategiaCompra(msg);
				mensagem.setReply(false);
			}			
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyBuscaProdutos"))
			{
				recebeReplyBuscaProdutos(msg);
				mensagem.setReply(false);
			}
			
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyBuscaParticipanteIndividual"))
			{
				if(estrategia() != null)
					estrategia().recebeMensagem(msg);
			}
			else if(msg.mensagem().equalsIgnoreCase("recebeReplyBuscaProdutoIndividual"))
			{
				recebeReplyBuscaProdutoIndividual(msg);
			}
			else
				System.out.println("\nMensagem n�o reconhecida "+nome());			
			
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no comeca a Trabalhar "+stringErro());
		}
		

		return mensagem;
	}




	public void Init(){}
		

}



	/**	

	busca();
	pegaPagina();
	ParsePalavrasChave();
	fazPergunta)seNecessario();
	atualizaFuncaoUtilizadade();
	insereReferenciasValores();//Uma lista de listas tipo www.xxx,valor 1, valor2....
								 que indica onde clicar e quais os valores a inserir. 
								 ex: login, senha.

	Nesse ponto ser� encontrado uma lista de refer�ncias ordenadas pela fun��o utilidade.


	NEGOCIA��O
	selecionaReferencias();
	iniciaNegociacao();
	verificaSePode();
	efetuaOferta();
	**/



/** 
	O valor da fun��o de Utilidade vai de 0 a 10, e n�o pode ser  valores comparativos 
	de acordo com as refer�ncias.  O valor est� relacionado apenascom a satisfa��o. 
	Ela pde ser a princ�pio RUIM, BOM, OTIMA.
	� considerado tamb�m o valor M�ximo dado pelo usu�rio, no momento da configura��o.
	Al�m dos dois deve se considerado o valor inicial, dado pelo leil�o(na refer�ncia).
**/


