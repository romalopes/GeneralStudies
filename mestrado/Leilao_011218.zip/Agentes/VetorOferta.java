/**classe VetorOferta**/

import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

import ClassesGeral.Mensagem;
import ClassesGeral.Enviador;
import ClassesGeral.VetorCaracteristica;
import ClassesGeral.Caracteristica;

/*************************************************************************************/
/*************************************************************************************/
/*************************************************************************************/
	//uma classe dentro da outra, nao sei se 'e permitido me java.
	public class VetorOferta extends Object implements Serializable
	{
			public VetorCaracteristica vetorVetorCaracUsu;//vetor que possui uma lista de VetorCarac de cada usu'ario que efetuar ofertas.
			public Vector ofertas;//vetor com todas as ofertas do usuario
			int m_numOfertas;
		
			public VetorOferta()
			{
				vetorVetorCaracUsu = new VetorCaracteristica();
				ofertas = new Vector();
				m_numOfertas = 0;
			}
		
			/****************************** writeObject **********************************/
			private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
			{
			try
			{	
							
					out.writeObject(vetorVetorCaracUsu);
					out.writeInt(m_numOfertas);
									
					int i;		
					out.writeInt(ofertas.size());
					for(i=0;i<ofertas.size();i++)
					{
						out.writeObject(ofertas.elementAt(i));
					}				
					out.flush();

			}
			catch(IOException e)
			{
				System.err.println(e+ " Erro no write da VetorOferta" );
			}
		}

		/****************************** readObject **********************************/
		 private void readObject(java.io.ObjectInputStream in)  
	 		throws IOException, ClassNotFoundException
		 {
			try
			{
				vetorVetorCaracUsu = (VetorCaracteristica) in.readObject();
				m_numOfertas = in.readInt();
			
				int i;
				ofertas = new Vector();		
				int size = in.readInt();
				for(i=0;i<size;i++)
				{
					int j;		
					ofertas.addElement(in.readObject());
				}
			 }
			 catch(IOException e)
			 {
			 	  System.err.println(e+" Erro no read da VetorOferta" );
			 }
		}
		
		public void insereOferta(Oferta oferta)
		{
			ofertas.addElement(oferta);
			
			vetorVetorCaracUsu.setValorCarac("nome",String.valueOf(oferta.nomeUsuario()));
			vetorVetorCaracUsu.setValorCarac("codigo",String.valueOf(oferta.codProd()));
//			vetorVetorCaracUsu.setValorCarac("valorOferta",String.valueOf(oferta.valorOferta()));			
			vetorVetorCaracUsu.setValorCarac("numeroEstrelas",String.valueOf(oferta.numeroEstrelas()));			

			m_numOfertas++;
//		vetorVetorCaracUsu.setValorCarac("valorOferta",oferta.valorOferta());			
//		vetorVetorCaracUsu.setValorCarac("valorOferta",oferta.valorOferta());			
		}
	}
/*************************************************************************************/
/*************************************************************************************/
/*************************************************************************************/
