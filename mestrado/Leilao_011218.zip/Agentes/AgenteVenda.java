/**classe Final Agente de Venda**/

import java.io.*;    //Package de classes para manipulacao de E/S

import java.util.*;

import java.net.*;

import ClassesGeral.Enviador;
import ClassesGeral.Mensagem;
/*
Procedimento do Agente Vendedor
	Configurado Pelo Usu�rio
	Visita Sites de Leil�o analisando as condi��es, taxas, tipos de leil�es, etc
	Ranqueia os sites
		Escolhe dentre os sites
	Inscreve o produto.
	Recebe notifica��o das ofertas dos agentes e de outros.
		Responde d�vidas.
	Fecha Leil�o
		Faz o contato do comprador com o seu usu�rio criador	
*/

public class AgenteVenda extends Agente
{
	private boolean m_buscando;
	private int m_numeroTotalOfertas;

	public void AdcionaPaginas(String p)	throws Exception 
	{
	}

	public AgenteVenda(String usu,String n)
	{
		super(usu,n);
		setTipo("Venda");
		
		listPaginas = new Vector();
		m_buscando = false;
		
		m_numeroTotalOfertas = 0;
		
		setStringErro("no Agente de Venda:"+nome());

		//somente por enquanto, isso vai ser criado de forma externa
		CriterioPreco c = new CriterioPreco((float)1);
		listCriterios.addElement(c);	
	}

	

	/****************************** writeObject **********************************/

	private void writeObject(java.io.ObjectOutputStream out)

	     throws IOException

	{

		try

		{
			out.writeInt(m_numeroTotalOfertas);
			
			out.writeInt(listPaginas.size());	
			for(int i=0;i<listPaginas.size();i++)
				out.writeObject(listPaginas.elementAt(i));

			out.flush();

		}

		catch(IOException e)

		{

			System.err.println(e+ " Erro no write do AgenteVenda" );

		}

	}



/****************************** readObject **********************************/
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_numeroTotalOfertas = in.readInt();
			listPaginas = new Vector();
			listPaginas.removeAllElements();
			int size = in.readInt();
			for(int i=0;i<size;i++)
				listPaginas.addElement(in.readObject());	
		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read do AgenteVenda" );
		 }
	}

	public int numeroTotalOfertas()
	{
		return m_numeroTotalOfertas;
	}

	public void incrementaNumeroTotalOfertas()
	{
		m_numeroTotalOfertas++;
	}

	public boolean buscando()
	{
		return m_buscando;
	}
	

	public void setBuscando(boolean b)
	{
		m_buscando = b;
	}


	//por enquanto est� igual aos outros mas pode ficar diferente	
	public void setEstrategia(String tipoEstrategia)
	{
		Estrategia estrategia = null;
		
		if(estrategia() != null)
			if(tipoEstrategia.equals(estrategia().tipo()))
				return;
		if(tipoEstrategia.equalsIgnoreCase("simples"));
//			estrategia = new EstrategiaCompraSimples(this);
		else if(tipoEstrategia.equalsIgnoreCase("PerfilConcorrente"))
			estrategia = new EstrategiaVendaPerfilConcorrente(this);
		if(tipoEstrategia.equalsIgnoreCase("TempoValor"));
//			estrategia = new EstrategiaCompraTempoValor(this);	
		m_estrategia = estrategia;
	}


/************************** RemoveItensExcedentes *****************************
//Somente Deixa os que est�o na faixa do permitido(numMaxItens)
//No futuro vai remover os que tiver abaixo da satisfa��o desejada tamb�m.
//deve ser chamado depois da ordena��o.
	public void	RemoveItensExcedentes()
	{
//		this.vetorCaracteristica.getValorCarac("avaliacaoItemMinima");
		for(int i = 0; i<listItens.size();i++)
		{
			Item it = (Item)listItens.elementAt(i);
			
			//se o item for novo e estiver fora dos limites do numero de itens aceitos d� erro.
			if (i>this.vetorCaracteristica.getValorCaracInteiro("numMaxItens") && it.novo())
			{
				listItens.removeElementAt(i);
			}
			else
				it.setNovo(false);
		}
	}

/************************** OrdenaItens *****************************
/**O que tem maior avalia��o primeiro*
	public void OrdenaItens()
	{
		Item itAtual,it;
		int size = listItens.size();
		double avalMelhor;
		int posMelhor;
		
		//deppois melhoro essa ordena��o		
		for(int i = 0; i<listItens.size();i++)
		{
			itAtual = (Item)listItens.elementAt(i);
			avalMelhor = itAtual.somaAvaliacao();
			posMelhor = i;
			for(int j = i;j<listItens.size();j++)
			{
				it = (Item)listItens.elementAt(j);
				//se o item for maior insere nessa posi��o se n�o vai inserir mais pra baixo
				if (avalMelhor < it.somaAvaliacao())
				{			
					avalMelhor = it.somaAvaliacao();
					posMelhor = j;
				}
			}
			it = (Item)listItens.elementAt(posMelhor);
			listItens.removeElementAt(i);			
			listItens.insertElementAt(it,i);			
			listItens.removeElementAt(posMelhor);			
			listItens.insertElementAt(itAtual,posMelhor);			
		}
	}



/************************** EscolheItens *****************************
/**de todos os Itens j� pegos nas p�ginas ir� escolher algumas de acorod com os crit�rios e restri��es*
	public void EscolheItens()
	{
		Item item;
		//para cada Itens verifica a alternativa
		for(int i = 0; i<listItens.size();i++)
		{
			item = getItemAt(i);
			item.removeAllCriterios();
			for(int j = 0;j<listCriterios.size();j++)
			{
				Criterio c = (Criterio)listCriterios.elementAt(j);
				item.addValorCriterio(c.CalculaCriterio(item));
			}
			//soma os crit�rios para depois ordenar
			item.SomaCriterios();
		}
		//passa as restri��es...
		//Ordena
		OrdenaItens();
		//Remove
		RemoveItensExcedentes();
	}

/******************** analisaSituacaoItens *****************************
	public boolean analisaSituacaoItens()
	{
		try
		{
		
			System.out.println("AnalisaSituacaoItens");		
		
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no AnalisaSituacaoItens do Agente de Venda " + nome());
		}
		return false;
	}
	
	
/******************** fechaLeilao *****************************/	
	public synchronized void fechaLeilao(Item it)
	{
		try
		{
			String leilaoProprio = it.vetorCaracteristica.getValorCarac("LeilaoProprio");
			String nomePagina = it.vetorCaracteristica.getValorCarac("pagina");

			if (!leilaoProprio.equals("false"))//se for o pr�prio leilao
			{//como � diferente de false ent�o ele mesmo fecha o leil�o pela sua p�gina
				Pagina pag = findPagina(nomePagina);
				if(pag!=null)
					pag.fechaLeilao();
			}	
			else//sen�o avisa ao leiloeiro que pode fechar.
			{
			
				String nomeAgenteLeiloeiro = it.vetorCaracteristica.getValorCarac("nomeLeiloeiro");
	
				if (it.vendido())
				{
					System.out.println("Item j� vendido "+it.nome());
					return;
				}				
				Mensagem msg = new Mensagem("","");
//				this.appendHistoria("recebeConviteLeilao do agente leiloeiro "+nomeAgenteLeiloeiro+" com as caracteristicas: "+msg.mensagemAux());
				msg.setOrigem(this.nomeUsuarioPagina());
				
//				System.out.println("nomeAgenteLeiloeiro:"+nomeAgenteLeiloeiro);
				msg.setDestino(nomeAgenteLeiloeiro);
				msg.setTipo("Agente");
				msg.setReply(false);
				msg.setMensagem("recebeVendedorFechaLeilao");//comprador			
				msg.setMensagemRetorno(true);
			
				String codigo = it.vetorCaracteristica.getValorCarac("codigo");
				
//				System.out.println("Codigo:"+codigo);
				msg.setMensagemAux(codigo);
//jatLite				
				Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,msg);		
//				msg.setOrigem(this.nome());
//				agDelegate.enviaMensagem(msg);
//jatLite			

			}
			
		}
		catch(Exception e)
		{
			System.err.println("Erro no Fecha Leilao :"+nome()+ e);
		}
	}
/******************** recebeReplyFechaLeilaoAKRM *****************************/	
	public Mensagem recebeReplyFechaLeilaoAKRM(Mensagem msg) 	throws Exception 
	{
		try
		{
			this.appendHistoria("Reply de recebeReplyFechaLeilaoAKRM resultado:"+msg.mensagemRetorno());
			msg.setReply(false);
			
			if (msg.mensagemRetorno())
			{
				Item it = findItemID(Enviador.pegaParte(msg.mensagemAux(),0,','));
				if(it!=null)
				{		
				
//pega o nome e - e-mail do vencedor.				
					System.out.println(msg.mensagemAux());
					it.vetorCaracteristica.setValorCarac("NomeVencedor",Enviador.pegaParte(msg.mensagemAux(),1,','));
					it.vetorCaracteristica.setValorCarac("EmailVencedor",Enviador.pegaParte(msg.mensagemAux(),2,','));
					it.vetorCaracteristica.setValorCarac("ValorVencedor",Enviador.pegaParte(msg.mensagemAux(),3,','));
				
				System.out.println(msg.mensagemAux());
					it.setVendido(true);
					
					this.appendHistoria("Vendeu produto"+it.nome()+" para "+it.vetorCaracteristica.getValorCarac("NomeVencedor")+
										"por:"+it.vetorCaracteristica.getValorCarac("ValorVencedor")+
										" com o email:"+it.vetorCaracteristica.getValorCarac("EmailVencedor"));
										
				}
				else
				{
					System.out.println("Problema ao setar produto vendido ID:"+msg.mensagemAux());		System.out.println("Problema ao setar produto vendido ID:"+msg.mensagemAux());	

					this.appendHistoria("N�o conseguiu vender o produto "+it.nome());
				}
				
				int i = estagio();
				setVezes(0);
				setEstagio(++i);
				executaEstrategia();
			}
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no recebeReplyFechaLeilaoAKRM "+stringErro());
		}
		return msg;	
	}	
/******************** analisaConviteLeilao *****************************/	
//por enquanto ele est� aceitando todos os convites do leiloeiro.
	private boolean analisaConviteLeilao(String mensagemAux)
	{
		try
		{

			//nomeProd,nomeProd, nomeLeiloeiro,nomeLeiloeiro,valorTotal,valorTotal
//	msgAux = "nomeProduto,"+nomeProduto()+",nomeLeiloeiro,"+this.nomeUsuarioPagina()+",valorReservaTotal,"+this.vetorCaracteristica.getValorCarac("valorReserva");//caracteristicaProduto();//idItem+","+it.pagina().nome(); 
			Item item = new Item(Enviador.pegaParte(mensagemAux,1,','),this,new PaginaAKRM(this));
//			System.out.println(mensagemAux);
			item.vetorCaracteristica.setCaracteristicas(mensagemAux);//aqui pega toda a string e joga no item
			item.vetorCaracteristica.setValorCarac("LeilaoProprio","false");
			item.vetorCaracteristica.setValorCarac("nomeLeiloeiro",Enviador.pegaParte(mensagemAux,3,','));
			item.vetorCaracteristica.setValorCarac("valorReservaTotal",Enviador.pegaParte(mensagemAux,5,','));			
			
			addItem(item);
		}
		catch(Exception e) 
		{
			System.err.println (e+" Erro no analisaConviteLeilao "+stringErro());
		}
		return true;	
	}

/******************** recebeConviteLeilao *****************************/	
	private Mensagem recebeConviteLeilao(Mensagem msg) 	throws Exception 
	{
		try
		{
			boolean resultadoConvite;
			String nomeAgenteLeiloeiro;
			
			
			nomeAgenteLeiloeiro = msg.origem();
			
			this.appendHistoria("recebeConviteLeilao do agente leiloeiro "+nomeAgenteLeiloeiro);//+" com as caracteristicas: "+msg.mensagemAux());
		
			resultadoConvite = analisaConviteLeilao(msg.mensagemAux());

			msg.setOrigem(this.nomeUsuarioPagina());
			msg.setDestino(nomeAgenteLeiloeiro);
			msg.setTipo("Agente");
			msg.setReply(false);
			msg.setMensagem("recebeReplyRecebeConviteLeilaoVenda");//comprador			
			msg.setMensagemRetorno(resultadoConvite);
			
//aqui devemos colocar as caracter�sticas. do leil�o para que o agente de venda possa verificar se o leil�o � satisfat�rio.				
			msg.setMensagemAux(Enviador.pegaParte(msg.mensagemAux(),1,','));//
			
//jatLite			
//			msg.setOrigem(this.nome());
//			agDelegate.enviaMensagem(msg);
			Enviador.EnviaMensagem(Enviador.nomeHostGerente,Enviador.PortaRecebimentoServidorGerente,msg);		
//jatLite			
		}
		catch(Exception e) 
		{
			System.err.println ("\nErro no recebeConviteLeilao do Agente de compra " + e);
		}     
		return msg;	
	}	
		
	/**************** recebeAvisoVendedorCriacaoLeilao ******************/	
	public Mensagem recebeAvisoVendedorCriacaoLeilao(Mensagem msg)
	{
		msg.setReply(false);
		
		String mensagemAux = msg.mensagemAux();
		
		//Carro,nomeItem&nome...
		//na ordem teremos na primeira posicao o nome do item, depois todas as suas informa�oes.
		Item it = findItemNome(msg.nome());


//		System.out.println("nome:"+nome()+" nomeLeiloeiro: "+msg.origem()+" mensagemAux:"+mensagemAux);		
		
		if (it == null)
		{
			System.err.println("Erro, pegou item errado");
			return msg;
		}

//		System.out.println(mensagemAux);		
		it.vetorCaracteristica.setCaracteristicas(mensagemAux);
		
		return msg;
		
	}
	
	
/******************** CriaLeiloes *****************************/	
	public synchronized void CriaLeiloes()
	{
		try
		{
			boolean todosCriados=true;
			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				if(!pag.leilaoCriado())
					todosCriados = false;
			}
			if (todosCriados)
			{
				int i = estagio();
				setVezes(0);
				setEstagio(++i);	
				executaEstrategia();
				return;
			}
			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				pag.criaLeilao();
			}

		}
		catch (Exception e)
		{
			System.err.println(e+ " Erro no Cria Leiloes do "+stringErro());
		}
	}
	/******************** recebeReplyCriaLeilaoAKRM *****************************/	
	public Mensagem recebeReplyCriaLeilaoAKRM(Mensagem msg) 	throws Exception 
	{
		try
		{
			this.appendHistoria("Reply de recebeReplyCriaLeilaoAKRM resultado:"+msg.mensagemRetorno());
			msg.setReply(false);
			Pagina pag = findPagina("AKRM");
			
			String stringItem = msg.mensagemAux();			
			Item it;		//nome do produto, this do Agente e ponteiro para a pag.
			it = findItemNome(Enviador.pegaParte(stringItem,3,'&'));
			
			System.out.println(Enviador.pegaParte(stringItem,3,'&'));
			
			if (it == null)
			{
				System.err.println("Erro, pegou item errado");
				return msg;
			}
			
			String palavra;
			it.vetorCaracteristica.setCaracteristicas(stringItem);
			
//			addItem(it);


			if (msg.mensagemRetorno())
			{
//pode fazer alguma coisa
				pag.setLeilaoCriado(true);
				int i= estagio();
				setVezes(0);
				setEstagio(++i);
				executaEstrategia();
			}
		}
		/*
		stringBuffer.append("valorvencedor&"+l.valorVencedor() +"&");//8
		stringBuffer.append("dataInicio&"+l.vetorCaracteristica.getValorCarac("dataInicio") +"&");
		stringBuffer.append("prazo&"+l.vetorCaracteristica.getValorCarac("prazo") +"&");//9
		stringBuffer.append("participanteAtual&"+l.printParticipanteAtual() +"&");
		stringBuffer.append("pagina&AKRM&");			
		stringBuffer.append("numeroEstrelasVendedor&"+this.dono().numeroEstrelas()+"&");
		if(l.printParticipanteAtual()!=null)
			stringBuffer.append("numeroEstrelasVencedor&"+String.valueOf(l.participanteAtual().numeroEstrelas())+"&");
		*/
		
		catch(Exception e) 
		{
			System.err.println ("\nErro no recebeReplyRegistroAKRM do Agente de compra " + e);
		}     
		return msg;	
	}	
	
/******************** insereProdutosPaginas *****************************/	
	public synchronized void insereProdutosPaginas()
	{
		try
		{
			boolean todosInseridos=true;
			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				if(!pag.produtoInserido())
					todosInseridos = false;
			}
			if (todosInseridos)
			{
				int i = estagio();
				setVezes(0);
				setEstagio(++i);	
				executaEstrategia();
				return;
			}
			for(int i=0;i<listPaginas.size();i++)
			{
				Pagina pag = (Pagina)listPaginas.elementAt(i);
				pag.insereProduto();
			}
		}
		catch(Exception e)
		{
			System.err.println(e+"\nErro no comeca a Trabalhar do "+nome());
		}
	}
	
	/******************** recebeReplyInsereProduto *****************************/	
	public Mensagem recebeReplyInsereProduto(Mensagem msg) 	throws Exception 
	{
		try
		{
			this.appendHistoria("Reply de recebeReplyInsereProduto resultado:"+msg.mensagemRetorno());
			msg.setReply(false);

	
			Pagina pag = findPagina(Enviador.pegaParte(msg.mensagemAux(),1,','));
			
			pag.vetorCaracteristica.setValorCarac("codigo",Enviador.pegaParte(msg.mensagemAux(),0,','));
			if (msg.mensagemRetorno())
			{
	//pode fazer alguma coisa
	///////////////////Criar o item*/
				Item item = new Item(this.nomeProduto(),this,pag);
				item.vetorCaracteristica.setValorCarac("nomePagina",Enviador.pegaParte(msg.mensagemAux(),1,','));
				item.vetorCaracteristica.setValorCarac("codigo",Enviador.pegaParte(msg.mensagemAux(),0,','));
				item.vetorCaracteristica.setValorCarac("detalhes",this.vetorCaracteristica.getValorCarac("detalhes"));
				item.vetorCaracteristica.setValorCarac("nomeProduto",this.nomeProduto());
				item.vetorCaracteristica.setValorCarac("tipoLeilao",this.vetorCaracteristica.getValorCarac("tipoLeilao"));
				item.vetorCaracteristica.setValorCarac("menordiferenca",this.vetorCaracteristica.getValorCarac("menordiferenca"));
				item.vetorCaracteristica.setValorCarac("valorInicial",this.vetorCaracteristica.getValorCarac("valorInicial"));
				item.vetorCaracteristica.setValorCarac("valorAtual",this.vetorCaracteristica.getValorCarac("valorAtual"));
				item.vetorCaracteristica.setValorCarac("prazo",this.vetorCaracteristica.getValorCarac("prazo"));
				
				String string = this.vetorCaracteristica.getValorCarac("bValorReserva");
				if (string.equalsIgnoreCase("true"))
				{
					item.vetorCaracteristica.setValorCarac("bValorReserva","true");									
					item.vetorCaracteristica.setValorCarac("ValorReserva",this.vetorCaracteristica.getValorCarac("ValorReserva"));									
				}
				
				addItem(item);


				pag.setProdutoInserido(true);
				int i= estagio();
				setVezes(0);
				setEstagio(++i);
				executaEstrategia();
			}
		}
		catch(Exception e) 
		{
			System.err.println ("\nErro no recebeReplyInsereProduto do Agente de compra " + e);
		}     
		return msg;	
	}	


/******************** recebeReplyRegistroAKRM *****************************/	
	public Mensagem recebeReplyRegistroAKRM(Mensagem msg) 	throws Exception 
	{
		try
		{
			this.appendHistoria("Reply de Registro AKRM TRUE");
			msg.setReply(false);
			Pagina pag = findPagina("AKRM");
			if (msg.mensagemRetorno())
			{
				pag.setRegistrado(true);
				int i= estagio();
				setEstagio(++i);
				executaEstrategia();
			}
		}
		catch(Exception e) 
		{
			System.err.println ("\nErro no recebeReplyRegistroAKRM do Agente de compra " + e);
		}     
		return msg;	
	}	


/************************** recebeReplyOferta ***************************/	
//Recebe a informa��o de que houve uma oferta.
	public void recebeReplyOferta(Mensagem msg) 	throws Exception 
	{//Quatro situacoes.  1 - Aceito, 2 - Outra Pessoa efetuou oferta, 3 - Nao aceito, 4- Leilao Inativo
		try
		{// MensagemAux 0=Agente 1=codProd 2=ValorOferta  3=Restricao/estrelas
			String sAgente = Enviador.pegaParte(msg.mensagemAux(),0,',');
			String codProd = Enviador.pegaParte(msg.mensagemAux(),1,',');			
	
//			System.out.println("Mensagem Retorno:"+msg.mensagemRetorno());
			if (msg.mensagemRetorno())//4
			{
//				msg.setMensagemRetorno(false);
				String	mensagemAux = msg.mensagemAux();
				Item it;
				//o item.
				it = findItemID(codProd);

				if (it == null)
				{
					System.out.println("N�o encontrou o produto "+codProd+ " "+stringErro());
				}

				if (it.vendido())
				{

					this.appendHistoria("Recebi oferta, mas j� vendi o produto"+it.nome()+" para "+it.vetorCaracteristica.getValorCarac("NomeVencedor")+
									"por:"+it.vetorCaracteristica.getValorCarac("ValorVencedor")+
									" com o email:"+it.vetorCaracteristica.getValorCarac("EmailVencedor"));

					return;
				}								

									
//				System.out.println(sAgente+"codProd:"+codProd+" "+it);					
				Oferta oferta = new Oferta(sAgente,Enviador.pegaParte(mensagemAux,2,','));
				oferta.setNumeroEstrelas(Enviador.pegaParteInteiro(mensagemAux,3,','));
							
				oferta.setCodProd(it.vetorCaracteristica.getValorCarac("codigo"));
				oferta.setNomeProd(it.nome());

				it.vetorOfertas.addElement(oferta);
				
				int numeroOfertas = it.vetorCaracteristica.getValorCaracInteiro("numeroOfertas");
				numeroOfertas++;
				it.vetorCaracteristica.setValorCarac("numeroOfertas",String.valueOf(numeroOfertas));
				
				
				//2 � o valor.
				int i=0;
//				Pagina pag = findPagina("AKRM");
//				if (pag == null)
//				{
//					this.appendHistoria("Inconsistencia na p�ginha AKRM ");
//					return;
//				}
//				System.out.println("Agente Recebeu informa��o de Oferta ao produto "+ codProd +" "+it.nome());
				this.appendHistoria("Agente Recebeu informa��o de Oferta ao produto "+ codProd +" "+it.nome());				

				incrementaNumeroTotalOfertas();
				
//				fechaLeilao(it);									
				
				
				executaEstrategia();							
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no recebeReplyOferta "+stringErro());
		}
	}

	/************************** estagioString ***************************/			
	public String estagioString()
	{
		if(estagio() == 0)
			return "Est�gio de Registro";
		else if(estagio() == 1)
			return "Est�gio de Insers�o de Produto nas p�ginas";
		else if(estagio() == 2)
				return "Est�gio de cria��o os Leil�es";
		else if(estagio() == 3)
				return "Est�gio de an�lise das ofertas";
		return "Est�gio n�o relacionado";
	}

/************************** executaEstrategia ***************************/			
//depois de receber o aviso verifica se j� est� trabalhando e continua a estrat�gia.
	public synchronized void executaEstrategia()
	{
		try
		{//por enquanto as estrat�gias s�o individuais.
		
			this.appendHistoria(nome()+" Verifica estrat�gia. Estagio:"+estagioString()+" Vezes:"+vezes());
//			System.out.println(nome()+"Executando estrategia. estagio:"+estagioString()+" Vezes:"+vezes());
			
			int i = vezes();
			setVezes(++i);
			if (estagio() == 0)//registrar
				registrar();
			else if (estagio() == 1)//InsereProdutosPaginas
				insereProdutosPaginas();
			else if (estagio()==2)
				CriaLeiloes();			
//			else if (estagio() == 3)
//			{//verificar se j� pode fechar os leil�es.
//				if(estrategia() != null)
//					estrategia().analisaSituacaoItens();

//			}
			else if (estagio()== 4)
			{
				System.out.println("est�gio 4 ainda n�o implementado "+nome());			
			}			
			if(estrategia() != null)
				estrategia().analisaSituacaoItens();
			
			
/*			int size = listItens.size();
			Item it;
			for(int j = 0;j<size;j++)
			{
				it = (Item)listItens.elementAt(j);
			}
			int j=0;*/
		}
		catch(Exception e) 
		{
			System.err.println (e+"\nErro no executaEstrategia de:"+nome());
		}     
	}
	
	
	/************************** recebeMensagem *****************************/	
	public Mensagem recebeMensagem(Mensagem msg)
	{
		Mensagem mensagem = new Mensagem("","");
		try
		{
		
//			System.out.println (nome()+" Recebi a mensagem "+msg.mensagem()+" retorno:"+msg.mensagemRetorno());
			if (msg.mensagem().equalsIgnoreCase("recebeReplyRegistroAKRM"))
			{
				mensagem = recebeReplyRegistroAKRM(msg);
				mensagem.setReply(false);	
			}
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyInsereProduto"))
			{
				mensagem = recebeReplyInsereProduto(msg);
				mensagem.setReply(false);	
			}
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyCriaLeilaoAKRM"))
			{
				mensagem = recebeReplyCriaLeilaoAKRM(msg);				
				mensagem.setReply(false);	
			}
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyFechaLeilaoAKRM"))
			{
				mensagem = recebeReplyFechaLeilaoAKRM(msg);
				mensagem.setReply(false);					
			}
			else if (msg.mensagem().equalsIgnoreCase("recebeReplyOferta"))
			{
				recebeReplyOferta(msg);
				mensagem.setReply(false);					
			}			
			else if (msg.mensagem().equalsIgnoreCase("recebeConviteLeilao"))
			{
				mensagem = recebeConviteLeilao(msg);	
				mensagem.setReply(false);					
			}
			else if (msg.mensagem().equalsIgnoreCase("recebeAvisoVendedorCriacaoLeilao"))
			{
				mensagem = recebeAvisoVendedorCriacaoLeilao(msg);	
			}
			else
				System.out.println("\nMensagem n�o reconhecida "+nome());


		}
		catch(Exception e)
		{
			System.err.println(e+"\nErro no comeca a Trabalhar do "+nome());
		}
		

		return mensagem;
	}

/************** ModificaConfiguracaoMensagem *********************/
//nome,autonomia,"sites,",arremate,tipoLeilao,*,mlivre,tipos,*,akrmtipos,*,&,precoInicial,precoMax,
//Modifica a configura��o com base na mensagem que foi passado pelo usu�rio
//("2,");//autonomia,("valorInicial,")("50,");("Prazo,")("10,")
//("bValorReserva,")("true,"),("ValorReserva,"),("800,"),("MenorDiferenca,"),("10,"),
//("detalhes,"),("carro que tamb�m funciona,"),("site,")("AKRM,");//nomeSite  // � um desse para cada p�gina.			
//string.append("tipoLeilao,"),("Ingles,")
	public void ModificaConfiguracaoMensagem(String mensagem)
	{
		try
		{
			this.appendHistoria("Modifica a Configuracao do Agente "+ this.nome());
			Integer valor;
			int i = 1;
			setAutonomia(Enviador.pegaParteInteiro(mensagem,i,','));//1
			i++;
			
			String estrategia = Enviador.pegaParte(mensagem,2,',');
			setEstrategia(estrategia);			
			i++;
			String nomeProduto = Enviador.pegaParte(mensagem,4,',');
			setNomeProduto(nomeProduto);
//			System.out.println(nomeProduto);			
			
			String s1,s2;
			while (!Enviador.pegaParte(mensagem,i,',').equals("site") && !Enviador.pegaParte(mensagem,i,',').equals("") )
			{
				s1 = Enviador.pegaParte(mensagem,i,',');
				i++;
				s2 = Enviador.pegaParte(mensagem,i,',');
				this.vetorCaracteristica.setValorCarac(s1,s2);
				i++;
			}
//			System.out.println(mensagem);
			while (Enviador.pegaParte(mensagem,i,',').equals("site"))//pega o site
			{
				i++;
				String site = Enviador.pegaParte(mensagem,i,',');//nome do site
				Pagina pag = addPagina(site);
				System.out.println("site "+site);
				
				i++;
				//login
				s2 = Enviador.pegaParte(mensagem,i,',');
				System.out.println("s2 "+s2);
				if(s2.equals("login"))
				{
					i++;
					s2 = Enviador.pegaParte(mensagem,i,',');
					System.out.println("login "+s2);
					pag.setLogin(s2);
					i=i+2;
					//senha
					s2 = Enviador.pegaParte(mensagem,i,',');
					System.out.println("senha "+s2);
					pag.setSenha(s2);
					i++;
				}

				s1 = Enviador.pegaParte(mensagem,i,',');
				i++;
				s2 = Enviador.pegaParte(mensagem,i,',');
				i++;
				pag.vetorCaracteristica.setValorCarac(s1,s2);
				System.out.println(s1+" "+s2);
					
			}	
			
		}
		catch(Exception e)
		{
			System.err.println(e+"Erro no ModificaConfiguracaoMensagem");
		}
	}
	


	

	public void Init(){}



}

	/**	

	busca();

	pegaPagina();

	ParsePalavrasChave();

	fazPergunta)seNecessario();

	atualizaFuncaoUtilizadade();

	insereReferenciasValores();//Uma lista de listas tipo www.xxx,valor 1, valor2....

								 que indica onde clicar e quais os valores a inserir. 

								 ex: login, senha.

	Nesse ponto ser� encontrado uma lista de refer�ncias ordenadas pela fun��o utilidade.



	NEGOCIA��O



	selecionaReferencias();

	iniciaNegociacao();

	verificaSePode();

	efetuaOferta();

	**/



/** 

	O valor da fun��o de Utilidade vai de 0 a 10, e n�o pode ser  valores comparativos 

	de acordo com as refer�ncias.  O valor est� relacionado apenascom a satisfa��o. 

	Ela pde ser a princ�pio RUIM, BOM, OTIMA.

	� considerado tamb�m o valor M�ximo dado pelo usu�rio, no momento da configura��o.

	Al�m dos dois deve se considerado o valor inicial, dado pelo leil�o(na refer�ncia).

**/

