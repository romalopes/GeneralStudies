import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;

/*A fun��o desse rel�gio � avisar aos agentes que passou um minuto.
  Ele fica rodanto eternamente*/


public class RelogioAgente extends Thread implements Serializable
{
	Gerente m_gerente;
	boolean m_bRodando;

	public RelogioAgente(Gerente g)
	{
		m_gerente = g;
	}

	public Gerente gerente()
	{
		return m_gerente;
	}
	public boolean isRodando()
	{
		return m_bRodando;
	}

	public void SetRodando(boolean r)
	{
		m_bRodando = r;
	}


	public synchronized void termina()
	{
		m_bRodando = false;
		notifyAll();
	}

	public synchronized void run()
	{
		long i;

		System.out.println("\nRelogio comecou a rodar ");

		m_bRodando = true;
//o relogio vai ficar no for enquanto o leiloeiro estiver na atividade.
		while(m_bRodando )
		{
			try{
				wait(30000);//espera meio minuto	
			}catch (InterruptedException e) {return;}
			
			if(!m_bRodando)
			{	
				System.out.println("\nMandaram o relogio parar de rodar ");
			}
			else//aviso de que se passaram 60 segundos.
			{
				m_gerente.recebeAvisoRelogio();
				notifyAll();
			}

		}
		System.out.println("Relogio finaliza execucao ");
	}


	public void Init(){}
}

