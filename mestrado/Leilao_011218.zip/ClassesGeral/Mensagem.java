package ClassesGeral;

import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;

public class Mensagem extends ObjetoEnviado
{
	private String m_ip;
	private String m_mensagem;
	private String m_mensagemAux;
	private String m_origem;
	private String m_destino;
	private String m_tipo;
	private boolean m_reply;
	private boolean m_mensagemRetorno;
	public Mensagem () 
	{
		m_ip = "";
		m_mensagem = "";
		m_mensagemAux = "";
		m_origem = "site";
		m_destino = "site";
		m_tipo = "site";
		m_reply = true;
		m_mensagemRetorno = false;
	}
	public Mensagem (String nome,String ip) 
	{ 
		super(nome);
		m_ip = ip;
		m_mensagem = "";
		m_mensagemAux = "";
		m_origem = "site";
		m_destino = "site";
		m_tipo = "site";
		m_reply = true;
		m_mensagemRetorno = false;
		
	}
	
	public String printCaracteristicas()
	{
		return "Caracteristicas : nome:"+nome() + " m_mensagem:"+m_mensagem+ "m_reply:"+m_reply +" m_mensagemRetorno:"+m_mensagemRetorno+ " m_mensagemAux:"+m_mensagemAux+ "\n m_tipo:"+m_tipo + " m_origem:"+m_origem + " m_destino:"+m_destino + " m_ip:"+m_ip;
	}
	
	/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
	
			out.writeObject(m_ip);
			out.writeObject(m_mensagem);
			out.writeObject(m_mensagemAux);
			out.writeObject(m_origem);
			out.writeObject(m_destino);
			out.writeBoolean(m_reply);		
			out.writeBoolean(m_mensagemRetorno);					
			out.writeObject(m_tipo);			
			out.flush();
		}	
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do Mensagem" );
		}			
	}
	
/****************************** readObject **********************************/		
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			m_ip =  (String)in.readObject();
			m_mensagem =  (String)in.readObject();			
			m_mensagemAux =  (String)in.readObject();
			m_origem =  (String)in.readObject();
			m_destino =  (String)in.readObject();
			m_reply = in.readBoolean();
			m_mensagemRetorno = in.readBoolean();
			m_tipo =  (String)in.readObject();			
		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read do Mensagem" );
		 }
	 }

	public String codificaMensagem()
	{
		String mensagem;
		
		mensagem = nome()+"#";
		mensagem = m_ip+"#";
		mensagem = m_mensagem+"#";
		mensagem = m_mensagemAux+"#";
		mensagem = m_origem+"#";
		mensagem = m_destino+"#";
		mensagem = String.valueOf(m_reply)+"#";
		mensagem = String.valueOf(m_mensagemRetorno)+"#";
		mensagem = m_tipo;
		return mensagem;
	}

	public void deCodificaMensagem(String mensagem)
	{
		try
		{
		
			if(mensagem == null)
				return;

			setNome(Enviador.pegaParte(mensagem,0,'#'));
			m_ip = Enviador.pegaParte(mensagem,1,'#');
			m_mensagem = Enviador.pegaParte(mensagem,2,'#');
			m_mensagemAux = Enviador.pegaParte(mensagem,3,'#');
			m_origem = Enviador.pegaParte(mensagem,4,'#');
			m_destino = Enviador.pegaParte(mensagem,5,'#');
			if(Enviador.pegaParte(mensagem,6,'#').equalsIgnoreCase("true"))
				m_reply = true;
			else
				m_reply = false;
			if(Enviador.pegaParte(mensagem,7,'#').equalsIgnoreCase("true"))
				m_mensagemRetorno = true;
			else
				m_mensagemRetorno = false;
				
			m_tipo = Enviador.pegaParte(mensagem,8,'#');
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro em deCodificaMensagem da mensagem");
		}
	}
	public String ip()
	{
		return m_ip;
	}

	public void setMensagem(String Mensagem)
	{
		m_mensagem = Mensagem;
	}
	
	public String mensagem()
	{
		return m_mensagem;
	}
	public void setMensagemRetorno(boolean Mensagem)
	{
		m_mensagemRetorno = Mensagem;
	}
	
	public boolean mensagemRetorno()
	{
		return m_mensagemRetorno;
	}
		
	
	public String mensagemAux()
	{
		return m_mensagemAux;
	}
	public void setMensagemAux(String Mensagem)
	{
		m_mensagemAux = Mensagem;
	}

	public void setOrigem(String s)
	{
		m_origem = s;
	}	
	public String origem()//nome da origem
	{
		return m_origem;
	}
	
	public void setDestino(String s)
	{
		m_destino = s;
	}	
	public String destino()//nome do destino
	{
		return m_destino;
	}
	
	public void setReply(boolean r)
	{
		m_reply = r;
	}
	 
	public boolean reply()
	{
		return m_reply;
	}
	public void setTipo(String t)
	{
		m_tipo = t;
	}
	 
	public String tipo()//Ingles,Holandes
	{
		return m_tipo;
	}	
	
}