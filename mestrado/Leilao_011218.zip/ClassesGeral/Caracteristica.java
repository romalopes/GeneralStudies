package ClassesGeral;
/**classe Abstrata Agente**/
	
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;


public class Caracteristica extends Object implements Serializable
{	
	private String m_nomeCarac;
	private String m_valorCarac;
	

	/****************************** writeObject **********************************/		
	private void writeObject(java.io.ObjectOutputStream out)
	     throws IOException
	{
		try
		{	
			out.writeObject(m_nomeCarac);
			out.writeObject(m_valorCarac);
			out.flush();
		}	
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write do Oferta" );
		}			
	}
	
/****************************** readObject **********************************/		
	private void readObject(java.io.ObjectInputStream in)  
		throws IOException, ClassNotFoundException
	{
		try
		{
			m_nomeCarac = (String)in.readObject();
			m_valorCarac = (String)in.readObject();
		}
		catch(IOException e)
		{
			System.err.println(e+" Erro no read do Oferta" );
		}
	}
	 
	

	public Caracteristica()
	{
		m_nomeCarac = "";
		m_valorCarac = "";
	}
	public Caracteristica(String c)
	{
		m_nomeCarac = c;
		m_valorCarac = "";
	}
	public Caracteristica(String c,String v)
	{
		m_nomeCarac = c;
		m_valorCarac = v;
	}	
	public String nomeCarac()
	{
		return m_nomeCarac;
	}
	
	public String valorCarac()
	{
		return m_valorCarac;
	}
	
	public void setNomeCarac(String n)
	{
		m_nomeCarac = n;
	}
	
	public void setValorCarac(String v)
	{
		m_valorCarac = v;
	}
	
	public void init(){}

}