package ClassesGeral;

import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

public class Enviador
{
	public Enviador(){};

	static public int PortaJatLite = 2221;
//	Portas de recebimento do gerente
	final static public int PortaRecebimentoServidorGerente = 8182;
	final static public int PortaRecebimentoClienteGerente = 8181;
//	final static public String nomeHostGerente = "192.168.0.12";	
	static public String nomeHostGerente = "192.168.0.25";	

//Portas de recebimento do Processador
	final static public int PortaRecebimentoServidorProcessador = 8184;
	final static public int PortaRecebimentoClienteProcessador = 8183;
//	final static public String nomeHostProcessador = "192.168.0.12";
	static public String nomeHostProcessador = "192.168.0.25";

	static public void EnviaMensagem(String nomeHost,int portaEnvio,ObjetoEnviado Msg)
	{
	
/***************A partir daqui vai enviar pra alguem.  ***************/
		final String msgErroHost = "\nHost nao encontrado!\n";
		final String msgErroConexao = "\nConexao com Host nao pode ser estabelecida.\n";

		// ---declaracao dos objetos utilizados--- *
//		nomeHost = "192.168.0.12";			//Nome do host para conexao, como estou trabalhando na minha m�quina nem preciso pegar o valor do parametro
	
		Socket SimplesSocket = null;			//Declaracao de objeto da classe Socket 

        ServerSocket socketServidor = null;
        Socket ClienteSocket = null;
		OutputStream os = null;
		ObjectOutputStream dos = null;
		ObjectInputStream is = null;

		PrintWriter saida = null;		//Fluxo de saida
		BufferedReader entrada = null;		//Fluxo de entrada

		try {
	   		SimplesSocket = new Socket(nomeHost, portaEnvio); 
					//Objeto sock criado atraves do construtor Socket
					//adequado a uma conexao TCP confiavel (stream).
					//Corresponde as instrucoes socket() e connect() 

		}
		catch(UnknownHostException e) 
		{		//Excecao: host nao e' encontrado
			System.err.println(msgErroHost);
//			System.exit(1);
		}
		catch(java.io.IOException e) 
		{		//Excecao: conexao nao pode ser estabelecida
			System.out.println(SimplesSocket + "  " +Msg.printCaracteristicas());
			System.err.println("\n***************************\n*******************"+msgErroConexao+" NomeHost="+nomeHost+" PortaEnvio="+portaEnvio+"\n***************************\n*******************");
			EnviaMensagem(nomeHost,portaEnvio,Msg);			
//   			System.exit(1); 
			return;
		}

   
		try 
		{
			os = SimplesSocket.getOutputStream();
			dos = new ObjectOutputStream (os);
			is = new ObjectInputStream(SimplesSocket.getInputStream());

			if(Msg != null)
				System.out.println (nomeHost+" "+portaEnvio+" A ser enviado:"+ Msg.printCaracteristicas());
			else
				System.out.println ("A ser enviado... tipo:"+ Msg );
			
			dos.writeObject (Msg);

			dos.flush();
			dos.close();
			os.close();
			is.close();
			SimplesSocket.close();
	    }
   		catch (UnknownHostException e) 
		{
			System.out.println(Msg.printCaracteristicas());
    		System.err.println("Trying to connect to unknown host: " + e);
			EnviaMensagem(nomeHost,portaEnvio,Msg);			
			return;			
		}
		catch (Exception e) 
		{
			System.out.println(Msg.printCaracteristicas());
			System.err.println("***************************\n*******************\n*******************\nErro no Enviador Exception:  NomeHost="+nomeHost+" PortaEnvio="+portaEnvio + e+"\n***************************\n*******************\n*******************");
			EnviaMensagem(nomeHost,portaEnvio,Msg);
			return;			
		}
		
	}
		
	static public String pegaParte(String palavra, int pos,char caracter) 
	{
		if(palavra == null)
			return "";
		int index=0,posParte=0,posIndex,i;
		String Parte =  new String();
		try
		{
			for(i = 0;i<=pos;i++)
			{
			    posIndex = palavra.indexOf(caracter,index);
				if (posIndex == -1)//se n�o tiver mais o caracter pega a �ltima parte
				{
					Parte = palavra.substring(index,palavra.length());
					break;
				}
				else
				{
					Parte = palavra.substring(index,posIndex);				
					if(i == pos)
						return Parte;
					
				}
				index = posIndex+1;
			}
			if(i == pos)
				return Parte;
			
		}	
		catch (Exception e) {
					System.err.println ("\nErro no PegaParte pos:"+pos+" "+palavra);
		}     
		return "";	 
		
	}

	static public int pegaParteInteiro(String palavra, int pos,char caracter) 
	{
		int i=0;
		try
		{
			String Parte = Enviador.pegaParte(palavra,pos,caracter);
			Integer valor = new Integer(Integer.parseInt(Parte, 10));
			i = (int)valor.intValue();
		}
		catch(Exception e)
		{
			System.err.println ("\nErro no PegaParteInteiro pos:"+pos+" palavra:"+palavra);
			i = 0;
		}
		return i;
	}

	static public double pegaParteDouble(String palavra, int pos,char caracter) 
	{
		double i=0;
		try
		{
			String Parte = Enviador.pegaParte(palavra,pos,caracter);
			Double valor = Double.valueOf(Parte);
			i = (double)valor.doubleValue();
		}
		catch(Exception e)
		{
			System.err.println ("\nErro no PegaParteDouble pos:"+pos+" "+palavra);
			i = (double)0;
		}
		return i;
	}
	
/************************* encontraRelacaoPalavras *********************/
//tenta encontra a string1 dentro da string2
	static public boolean encontraRelacaoPalavras(String string1,String string2)
	{
		try
		{
			int index;
			string1 = string1.toLowerCase();
			string2 = string2.toLowerCase();

			index = string2.indexOf(string1,0);
			if(index>=0)
				return true;		
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no encontraRelacaoPalavras"+string1+" "+string2);
		}
		return false;
	}
	


/************************* transformaNumeroVirgulaNumeroPonto *********************/
	static public String transformaNumeroVirgulaNumeroPonto(String string)
	{
		String numero = "";
		try
		{
			int index;
			numero = string;
			index = string.indexOf(",",0);
			if (index>0)
			{
				numero =  string.substring(0,index);
				index++;
				numero = numero + "." + string.substring(index,string.length());
			}
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no transformaNumeroVirgulaNumeroPonto "+string);
		}
		return numero;
	}
/************************* transformaNumeroVirgulaNumeroPonto *********************/
	static public String transformaNumeroPontoNumeroVirgula(String string)
	{
		String numero = "";
		try
		{
			int index;

			index = string.indexOf(".",0);
			numero =  string.substring(0,index);
			index++;
			
			numero = numero + "," + string.substring(index,index+2);
		}
		catch(Exception e)
		{
			System.err.println(e+" Erro no transformaNumeroVirgulaNumeroPonto "+string);
		}
		return numero;
	}
	
	static public String getStringData(	Calendar calendar)
	{
		String s = calendar.get(Calendar.MINUTE)+"/"+calendar.get(Calendar.HOUR_OF_DAY)+"/"+calendar.get(Calendar.DAY_OF_YEAR)+"/"+calendar.get(Calendar.YEAR);
		return s;
	}

	static public String CalculaDataMinutos(String dataInicio,String dataFim)
	{
//		String s = calendar.get(Calendar.MINUTE)+"/"+calendar.get(Calendar.HOUR_OF_DAY)+"/"+calendar.get(Calendar.DAY_OF_YEAR)+"/"+calendar.get(Calendar.YEAR);
//		minuto/hora/dia/ano
//		return s;

		int minutoInicio,horaInicio,diaInicio,anoInicio,minutosInicio;
		minutoInicio = Enviador.pegaParteInteiro(dataInicio,0,'/');
		horaInicio = Enviador.pegaParteInteiro(dataInicio,1,'/');
		diaInicio = Enviador.pegaParteInteiro(dataInicio,2,'/');
		anoInicio = Enviador.pegaParteInteiro(dataInicio,3,'/');
		minutosInicio = minutoInicio+horaInicio*60+diaInicio*24*60;

		int minutoFim,horaFim,diaFim,anoFim,minutosFim;		
		minutoFim = Enviador.pegaParteInteiro(dataFim,0,'/');
		horaFim = Enviador.pegaParteInteiro(dataFim,1,'/');
		diaFim = Enviador.pegaParteInteiro(dataFim,2,'/');
		anoFim = Enviador.pegaParteInteiro(dataFim,3,'/');
		minutosFim = minutoFim+horaFim*60+diaFim*24*60;		
		
		anoFim = anoFim-anoInicio;
		
		minutosFim = (minutosFim+anoFim*60*24*365)-minutosInicio;
		
		return String.valueOf(minutosFim);		
	}
	
	
/*****************************/
}