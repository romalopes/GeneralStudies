package ClassesGeral;

import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;
import java.net.*;

public class Recebedor
{
	public Recebedor(){};

  
	static public synchronized ObjetoEnviado RecebeMensagem(int portaDefault)
	{
		ObjetoEnviado Msg = null ;
        /* --- constante --- */

//        final int portaDefault = 8082;    // porta inicial default
         /* --- variaveis --- */
        int backlog = 1000;                 // tamanho da fila de requisicoes

       
        /* --- objetos sockets --- */

		ServerSocket socketServidor = null;
		Socket clienteSocket = null;
		OutputStream os = null;
		ObjectOutputStream dos = null;
		ObjectInputStream is = null;

        /* --- associacao da porta utilizada pelo servidor --- */
		try
		{
        	socketServidor = new ServerSocket(portaDefault, backlog);
       
        	System.out.println ("\nObjeto ativado. " + 
                            "Aguardando mensagens na porta " + portaDefault + "..."+
								socketServidor.getLocalPort());
		}
		catch(Exception e) 
		{
			System.err.println ("\nPorta n�o pode ser liberada\n"+ portaDefault + e);
		}
		
        clienteSocket = null;
        try 
        {
	 	        System.out.println ("Objeto Espera alguma coisa...\n");
                clienteSocket = socketServidor.accept();  // listen() + accept()
        } 
        catch (IOException e) 
        {
			System.err.println ("\n***Objeto nao recebeu direito***\n");
			System.err.println("Erro de E/S " + e);
//			System.exit(1);
		}     
		try 
		{
			System.out.println ("\nServidor Recebe alguma coisa...");
			os = clienteSocket.getOutputStream();
		    dos = new ObjectOutputStream (os);
		    is = new ObjectInputStream(clienteSocket.getInputStream());
		    Msg = (ObjetoEnviado)is.readObject(); 

			if(Msg!=null)
				System.out.println ("ObjetoRecebido: "+Msg.printCaracteristicas());
			
		    dos.flush();	

		}
		catch (Exception e) 
	  	{
	  		System.err.println(e+ " Erro no Recebedor "); 
	  	}
		try
		{
		  	os.flush();           
		  	dos.close();
		  	os.close();
		  	is.close();
		  	clienteSocket.close();
		  	socketServidor.close();
		}	  	
		catch (Exception e) 
		{
			System.err.println(e+" Erro no Recebedor 2 "); 
		}
		
	  	return Msg;
	}
}	  	