package ClassesGeral;
/**classe Abstrata Agente**/
	
import java.io.*;    //Package de classes para manipulacao de E/S
import java.util.*;


public class VetorCaracteristica extends Vector implements Serializable
{	
	public VetorCaracteristica(){	}
	
	/****************************** writeObject **********************************/
	private void writeObject(java.io.ObjectOutputStream out)

	     throws IOException

	{
		try

		{
			int i;		
			out.writeInt(this.size());
			for(i=0;i<this.size();i++)
			{
				out.writeObject(this.elementAt(i));
			}
			out.flush();

		}
		catch(IOException e)
		{
			System.err.println(e+ " Erro no write da VetorCaracteristica" );
		}
	}



/****************************** readObject **********************************/
	 private void readObject(java.io.ObjectInputStream in)  
	 	throws IOException, ClassNotFoundException
	 {
		try
		{
			int i,size = in.readInt();
			for(i=0;i<size;i++)
			{
				this.addElement(in.readObject());
			}
		 }
		 catch(IOException e)
		 {
		 	System.err.println(e+" Erro no read da VetorCaracteristica" );
		 }
	}
	
	
	
	//Caracteristicas
	public void addCaracteristica(Caracteristica c)
	{
		if(getCaracteristica(c.nomeCarac())==null)
			this.addElement(c);
		else
		{
			System.out.println("*********************************\nN�o conseguiu inserir uma nova caracteristica pois essa j� existe\n ***************************\n*******************"+c.nomeCarac());
		}		
	}
	public void addCaracteristica(String nome,String valor)
	{
		Caracteristica carac = new Caracteristica(nome,valor);
		this.addElement(carac);
	}
	
	public void removeCarac(String nome)
	{
		Caracteristica caracAtual;	
		for(int i=0;i<this.size();i++)
		{
			caracAtual = (Caracteristica)elementAt(i);
			if(caracAtual.nomeCarac().equalsIgnoreCase(nome))
				this.removeElementAt(i);
		}
		return;
	}

	
	public Caracteristica getCaracteristica(int i)
	{
		if(i<this.size())
			return (Caracteristica)this.elementAt(i);
		return null;	
	}
	
	public String printCaracteristicas()
	{
		StringBuffer buffer = new StringBuffer(1000);
		Caracteristica carac;
		int i=0;
		do
		{
			carac = getCaracteristica(i);
			if (carac != null)
			{
				buffer.append(".  ");
				buffer.append(carac.nomeCarac());
				buffer.append("=");
				buffer.append(carac.valorCarac());
			}
			i++;
		}
		while(carac != null);
		return buffer.toString();
	}
	
	
	public Caracteristica getCaracteristica(String nome)
	{
		Caracteristica caracAtual;	
		for(int i=0;i<this.size();i++)
		{
			caracAtual = (Caracteristica)elementAt(i);
			if(caracAtual.nomeCarac().equalsIgnoreCase(nome))
				return caracAtual;
		}
		return null;
	}
	
	
	public int getIndiceCaracteristica(String sCarac)
	{
		int i=0;
		Caracteristica caracAtual;
		for(i=0;i<this.size();i++)
		{ 
			caracAtual = (Caracteristica)this.elementAt(i);
			if(sCarac.equalsIgnoreCase(caracAtual.nomeCarac()))
				return i;
		}
		return -1;	
	}	
	
	
	public String getValorCaracteristicaNome(String c)
	{
		int i = getIndiceCaracteristica(c);
		return getValorCaracteristica(i);
	}	
	
	public int getSize()
	{
		return size();
	}
	public String getValorCaracteristica(int i)
	{
	
		Caracteristica carac = (Caracteristica)this.elementAt(i);
		if (carac!=null)
		{
			return carac.valorCarac();
		}
		return null;
	}	


	public String getValorCarac(String nome)
	{
		Caracteristica carac = getCaracteristica(nome);
		if (carac!=null)
		{
			return carac.valorCarac();
		}
		return "";
	}	
	
	public int getValorCaracInteiro(String nome) 
	{
		int i=0;
		try
		{
		
			Caracteristica carac = getCaracteristica(nome);
			if (carac!=null)
			{
				Integer valor = new Integer(Integer.parseInt(carac.valorCarac(), 10));
				i = (int)valor.intValue();
				return i;
			}
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no getValorCaracInteiro para "+nome);
			i = 0;
		}
		return i;
	}

	public double getValorCaracDouble(String nome) 
	{
		double i=0;
		try
		{
		
			Caracteristica carac = getCaracteristica(nome);
			if (carac!=null)
			{
				Double valor = Double.valueOf(carac.valorCarac());
				i = (double)valor.doubleValue();
	
				return i;
			}
		}
		catch(Exception e)
		{
			System.err.println (e+" Erro no getValorCaracDouble para "+nome);
			i = 0;
		}
		return i;
	}


	public void setValorCarac(String n,String valor)
	{
		Caracteristica carac;
		carac = getCaracteristica(n);
		if (carac != null)
			carac.setValorCarac(valor);
		else
		{
		
			System.out.println("*************************************Inserindo uma caracteristica:"+n+ " Valor:"+valor);
			carac = new Caracteristica(n,valor);	
			addCaracteristica(carac);
		}
	}
	
	
	public void setCaracteristicas(String frase)
	{
		
		int i=0;
		String StringItem1 = Enviador.pegaParte(frase,i,'&');
		String StringItem2;
		Caracteristica carac = new Caracteristica("","");;
		while(!StringItem1.equalsIgnoreCase(""))
		{
			i++;
			StringItem2 = Enviador.pegaParte(frase,i,'&');
			this.setValorCarac(StringItem1,StringItem2);
			i++;
			StringItem1 = Enviador.pegaParte(frase,i,'&');
		}		
	}
	
	
	public String getBufferCaracteristica()
	{
		StringBuffer stringbuffer = new StringBuffer(500);
		Caracteristica caracAtual;
		
		if (this.size()==0)
			return "";
			
		
		caracAtual = (Caracteristica)this.elementAt(0);
		stringbuffer.append(caracAtual.nomeCarac());
		stringbuffer.append("&"+caracAtual.valorCarac());

		for(int i=1;i<this.size();i++)
		{ 
			caracAtual = (Caracteristica)this.elementAt(i);
			stringbuffer.append("&"+caracAtual.nomeCarac());
			stringbuffer.append("&"+caracAtual.valorCarac());
		}
		
		return stringbuffer.toString();

	}

	public void init(){}

}